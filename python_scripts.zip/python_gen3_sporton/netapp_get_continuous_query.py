
import sys
import time
import TICore
import configurations as conf
import string
import options
import struct


def netapp_get(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    core.InvokeSLCommand("NETAPP", "NETAPPGET",2, 0, 4, 1, 0)

    retVal,Data = core.waitEvent("cc_NETAPP_NETAPPGETRESPONSE",[],5000)
    print("retVal: {0} ; Data: {1}".format(retVal,Data))

    print("Satus %d \n  "%( int(Data[4])))

    BufferStr = Data[8]

    QeryName = BufferStr[0:Data[7]]



    print("QeryName %s \n "%(QeryName))

    core.close()
    sys.exit("NETAPPGET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_get(Opts)