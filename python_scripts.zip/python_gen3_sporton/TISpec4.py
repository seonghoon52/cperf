import sys
from xml.etree import ElementTree
from collections import namedtuple, OrderedDict
import struct
import re
from configurations import SERILA_TX_SYNC_PATTERN

class SaferEvalError(Exception):
    pass


def saferEval(expr, locs=None):
     attribAccess = re.compile(r"\.[ \t]*[a-zA-Z_]+")
     forLoops = re.compile(r"[ \t]+for[ \t]+")

     if not isinstance(expr, str):
         raise SaferEvalError("expr must be of type str")

     if attribAccess.findall(expr):
         raise SaferEvalError("Cannot use attribute access")

     if forLoops.findall(expr):
         raise SaferEvalError("Cannot use list comprehensions or generator expressions")

     return eval(expr, {"__builtins__": None}, locs)


class TIParam(namedtuple("TIParam", "kind, size, label, name, default, desc, value, cond, params")):
    _typesMap = {
            ("o", "2"): "H",
            ("u", "1"): "B",
            ("u", "2"): "H",
            ("u", "4"): "I",
            ("u", "8"): "Q",
            ("d", "1"): "b",
            ("d", "2"): "h",
            ("d", "4"): "i"
           }

    _skipableTypes = ("R",)

    def convert(self, value):
        fmt = ""

        if self.kind == "o":
##            if self.hasDefault:
##                value = int(str(saferEval(self.default)), 0)
##            else:
##                value = 0

            fmt = "H"

        elif self.kind == "s":
            value = str(value)

            if self.size == "input":
                fmt = str(len(value)) + "s"
            else:
                fmt = str(self.size) + "s"

        elif self.kind == "x":
                if self.label != "data":
                    try:
                        value = "".join([chr(int(num, 16)) for num in value.split(":")])
                    except:
                        value = (0,)

                if self.size == "input":
                    fmt = str(len(value)) + "s"
                else:
                    fmt = str(self.size) + "s"
        else:
            value = int(str(value), 0)
            fmt = self._typesMap[(self.kind, self.size)]

        return fmt, value


    @property
    def isSkipable(self):
        return self.kind in self._skipableTypes

    @property
    def isOpcode(self):
        return self.kind == "o"

    @property
    def isEvent(self):
        return self.kind == "R"

    @property
    def isCondition(self):
        return self.cond is not None

    @property
    def hasValue(self):
        return self.value is not None

    @property
    def hasLabel(self):
        return self.label is not None

    @property
    def hasDefault(self):
        return self.default is not None


class TIParams(object):
    def __init__(self, name, opcode, kind, params=None):
        if params is None:
            self._params = []
        else:
            self._params = params

        self._name = name
        self._opcode = opcode
        self._kind = kind

    def _addParam(self, param, **kw):
        if not kw:
            self._params.append(param)
        else:
            self._params.append(TIParam(**kw))


    def _eval(self, expr, locs):
        expr = expr.replace("!", " not ")
        expr = expr.replace("&&", " and ")
        expr = expr.replace("||", " or ")
        locs["size"] = len       # size() == len()

        return saferEval(expr, locs)


    def _evalValues(self, data, params=None):
        if params is None:
            params = self._params

        data = list(data)

        nameSpace = {}

        for item, param in zip(data, params):
            if param.isSkipable:
                continue

            if param.hasLabel:
                nameSpace[param.label] = item


        for (i, item), param in zip(enumerate(data), params):
            if param.hasValue:
                try:
                    data[i] = self._eval(param.value, nameSpace)
                    nameSpace[param.label] = data[i]

                except NameError:
                    pass

                except Exception as ex:
                    print("Exception: {0}".format(ex))
                    #raise ex

        return data, nameSpace

    def _evalAll(self, data, params=None, matchValues=False):
        if params is None:
            params = self._params

        valuesMatch = True

        data = list(data)
        nameSpace = {}

        for item, param in zip(data, params):
            if param.isSkipable:
                continue

            if param.hasLabel:
                nameSpace[param.label] = item

        newParams = []
        for i, param in enumerate(params):
            try:
                if param.size is not None:
                    newSize = str(self._eval(param.size, nameSpace))
            except NameError:
                newSize = param.size


            if str(newSize) == param.size:
                newParams.append(param)
            else:
                newParams.append(param._replace(size=newSize))

            if i < len(data):
                if param.hasValue:
                    #data[i] = self._eval(param.value, nameSpace)
                    value = self._eval(param.value, nameSpace)
                    if not matchValues or value == data[i]:
                        data[i] = value
                        nameSpace[param.label] = value
                    elif matchValues and value != data[i]:
                        valuesMatch = False
                        break
                elif not param.hasValue and param.isOpcode:
                    if matchValues:
                        valuesMatch = False
                        break

        return data, newParams, nameSpace, valuesMatch


    def _build(self, data, params=None, matchValues=False):
        if params is None:
            params = self._params

        #complete = False
        complete = True

        while True:
            newParams = []
            newData = []
            hasCond = False
            moreCond = False

            dataIndex = 0

            data, params, nameSpace, valuesMatched = self._evalAll(data, params, matchValues)
            if not valuesMatched:
                break

            for i, param in enumerate(params):
                if param.isSkipable:
                    continue

                if not param.isCondition and len(data) <= dataIndex:
                    newParams.extend(params[i:])

                    try:
                        size = int(param.size, 0)
                    except ValueError:
                        size = -1

                    if i == len(params) - 1 and size == 0:
                        complete = True
                    else:
                        complete = False

                    break

                if not param.isCondition or hasCond:
                    newParams.append(param)

                    if not param.isCondition:
                        newData.append(data[dataIndex])
                        dataIndex += 1

                    if hasCond:
                        moreCond = True
                else:
                    ret = False

                    try:
                        ret = self._eval(param.cond, nameSpace)

                    except NameError:
                        pass

                    except Exception as ex:
                        print("Exception: {0}".format(ex))
                        #raise ex

                    if ret:
                        newParams.extend(param.params)

                        hasCond = True
                        for j in xrange(len(param.params)):
                            if len(data) <= dataIndex:
                                complete = False
                                break

                            newData.append(data[dataIndex])
                            dataIndex += 1

                        if not complete:
                            break

            if moreCond:
                params = newParams
                data = newData
                complete = False
            else:
                #complete = True
                break

        if hasCond:
            #data, nameSpace = self._evalValues(newData, newParams)
            data, params, nameSpace, valuesMatched = self._evalAll(newData, newParams, matchValues)
        else:
            data = newData

        return complete, data, newParams, valuesMatched


    def parse(self, data):
        params = self._params

        #tempData = data[:]
        start = 0

        newData = []
        #totalSize = 0
        complete = False
        valuesMatched = False
        i = 0
        while True:


            for retry in xrange(2):
                try:
                    size = int(params[i].size, 0)
                except ValueError:
                    if retry == 1:
                        raise
                    newData, params, nameSpace, valuesMatch = self._evalAll(newData, params)

            #value = tempData[: size]
            value = data[start: start + size]
            start += size

            if len(value) < size:
                break

            #totalSize += size
            #tempData = tempData[size:]
            fmt, _ = params[i].convert(0)

            value = struct.unpack("=" + fmt, value)[0]
            newData.append(value)

            complete, newData, params, valuesMatched = self._build(newData, matchValues=True)

            #if complete or not tempData or not valuesMatched:
            if complete or len(data) == start or not valuesMatched:
                break

            i += 1


        #return complete, newData, params, valuesMatched, totalSize
        return complete, newData, params, valuesMatched, start



class TICommand(TIParams):

    def produce(self, data):
        complete, data, params, valuesMatched = self._build(data)
        sync = SERILA_TX_SYNC_PATTERN

        newFmt = []
        newData = []

        for value, param in zip(data, params):
            fmt, value = param.convert(value)
            newFmt.append(fmt)
            newData.append(value)


        fmt = "".join(newFmt)
        fmt = "=BBBBBBB{0}H{1}".format(fmt[:1], fmt[1:])      # Format: [Start Byte][Opcode][Payload Size][Payload]
        newData = [0xFF, 0xFF,0xFF,ord(sync[0]), ord(sync[1]), ord(sync[2]), ord(sync[3])] + newData
        
        newsize = struct.calcsize(fmt) - 11
        newData.insert(8, newsize)
#        print "size = ", newsize

        return newsize, struct.pack(fmt, *newData)


class TIPacket(TIParams):
    @property
    def isCustomEvent(self):
        return self._kind == "ce"


class TISpec(object):
    def __init__(self, fileName=None):
        if fileName is not None:
            self.loadXml(fileName)

    def loadXml(self, fileName):
        try:
            self._domDoc = ElementTree.parse(fileName)
        except Exception as ex:
            print(ex)
            sys.exit(1)

        self._getCommands()
        self._getPackets()
        self._getEvents()

        self._domDoc = None

    def _getCommands(self):
        commands = OrderedDict()
        currentGroup = None

        for commandNode in self._domDoc.getroot().findall("Command"):
            if commandNode.attrib.get("type") == "gb":
                name = commandNode.attrib.get("name")
                commands[name] = OrderedDict()
                currentGroup = name
            else:
                commandName = commandNode.attrib.get("name")
                opcode = commandNode.attrib.get("opcode")
                kind = commandNode.attrib.get("type")
                params = []

                for paramNode in commandNode.findall("Param"):
                    params.append(self._getParam(paramNode))

                params = tuple(params)

                if currentGroup is None:
                    commands[commandName] = TICommand(commandName, params)
                else:
                    commands[currentGroup][commandName] = TICommand(commandName, opcode, kind, tuple(params))

        self._commands = commands

    def _getPackets(self):
        packets = OrderedDict()

        for packetNode in self._domDoc.getroot().findall("Packet"):
            packetName = packetNode.attrib.get("name")
            opcode = packetNode.attrib.get("opcode")
            kind = packetNode.attrib.get("type")

            params = []

            for paramNode in packetNode.findall("Param"):
                params.append(self._getParam(paramNode))

            packets[packetName] = TIPacket(packetName, opcode, kind, tuple(params))

        self._packets = packets

    def _getEvents(self):
        events = OrderedDict()

        for name, packet in self._packets.iteritems():
            if packet.isCustomEvent:
                events[name] = packet
                #if packet._opcode:
                #    events[int(packet._opcode, 0)] = packet
                #else:
                #    events[name] = packet


        for event in events.keys()[:]:
            for name, packet in self._packets.iteritems():
                if packet._kind == event:
                    events[name] = packet

            for groupName, group in self._commands.iteritems():
                for name, command in group.iteritems():
                    if command._kind == event:
                        events[name] = command

        self._events = events

    def _getParam(self, paramNode):
        kind = paramNode.attrib.get("type")
        size = paramNode.attrib.get("size")
        label = paramNode.attrib.get("label")

        node = paramNode.find("Name")
        name = node.text if node is not None else None

        node = paramNode.find("Default")
        default = node.text if node is not None else None

        node = paramNode.find("Desc")
        desc = node.text if node is not None else None

        node = paramNode.find("Value")
        value = node.text if node is not None else None

        params = None
        cond = paramNode.attrib.get("cond")
        if cond is not None:
            params = []
            for condNode in paramNode.findall("Param"):
                params.append(self._getParam(condNode))

            params = tuple(params)

        return TIParam(kind, size, label, name, default, desc, value, cond, params)


    def _getCommand(self, groupName, commandName):
        try:
            if groupName is None:
                return self._commands[commandName]
            else:
                return self._commands[groupName][commandName]
        except KeyError:
            return None

    def _getEvent(self, opcode):
        return self._events.get(opcode)


    @property
    def groups(self):
        return self._commands.keys()

