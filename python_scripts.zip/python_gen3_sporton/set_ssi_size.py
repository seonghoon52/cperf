
import sys
import time
import TICore
import configurations as conf
import string
import options
import utils

DEFAULT_CMD_INVOKE_TIMEOUT              = 2000
DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT       = 10000

def set_ssi_size(Opts=None):
    if (None == Opts):
        Opts = StellarisSsiOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    SizeInBytes = int(Opts.GetVal('SizeInBytes'))
    core.InvokeSLCommand("HOST", "SSI_SET_SIZE", DEFAULT_CMD_INVOKE_TIMEOUT, SizeInBytes)
    core.waitEvent("cc_SSI_SET_SIZE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.StellarisSsiOptions(OptsStr)
    set_ssi_size(Opts)

