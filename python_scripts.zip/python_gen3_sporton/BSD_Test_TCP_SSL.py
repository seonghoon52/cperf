#-------------------------------------------------------------------------------
# Name:        test_cmd_self.slBsdHandle.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import BsdUtils
import BSD_Test_configurations as slConf
import BSD_Test_base
import socket
import select
import ssl
import os
import subprocess
import struct
from OpenSSL import SSL

SYNCFILE = os.getcwd()+"\syncSSLTest.txt"
ServerCertificate = os.getcwd() + "\cert\server-cert.pem"
ServerPrivateKey  = os.getcwd() + "\cert\server-key.pem"
ServerCA          = os.getcwd() + "\cert\ca-cert.pem"
ClientKey          = os.getcwd() + "\cert\client-key.pem"
ClientCertificate   = os.getcwd() + "\cert\client-cert.pem"
ServerDH            =  os.getcwd() + "\cert\dh2048.pem"
ClientCA            = ClientCertificate

SLINK_FILE_PRIVATE_KEY =  97   # 151 cert\server-key.der  1400 bytes
SLINK_FILE_SERVER_CERT =  98   # 152 cert\server-cert.der 1024 bytes
SLINK_FILE_CA_CERT    =   99   # 153 cert\ca-cert.der      1300 bytes

SLINK_FILE_CLIENT_CERT =          90 # 144 cer\client_cert.der   1400 bytes
SLINK_FILE_CLIENT_PRIVATE_KEY =   91 # 145 cer\client_key.der  1700 bytes
SLINK_FILE_DH_SERVER   =          92 # 146 cer\dh2048.der     800 bytes


SL_SECURITY_ANY       =   100

SSL_DELAY = 1  # no accelarator should be big








class BsdTestClientSSLCloseSSLandContinueRegularTCP(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestClientSSLCloseSSLandContinueRegularTCP", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data1_750 )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != self.data1_750:
            sslprivate.close()
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        sslprivate.send( "*" )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != "*":
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        sslprivate.unwrap()


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        privateSd.send( self.data_2 )

        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.sync3) == -1:
            sd.close()
            self.log(self.getline(), self.failed )


        # Third test 2 buffer from differnet source port  < payload
        privateSd.send(self.data_3_0 )
        privateSd.send(self.data_3_1)



        # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  max paylaod 750 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_750) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_750:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len("*") or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != "*":
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
            
        # recv return change to unsecured , continue unsecured data
        ret = self.slBsdHandle.Recv( sd, 100, 0 )
        if ret[1] != BsdUtils.BSD_ESECCLOSED or ret[2] != sd:
            self.log(self.getline(), self.failed )
            

        # second test buuffer recive < payload read 3 iteration

        # read only 2 bytes
        ret = self.slBsdHandle.Recv( sd, 2, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 2 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[0:2]:
            self.log(self.getline(), self.failed )
        # read only 3 bytes
        ret = self.slBsdHandle.Recv( sd, 3, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[2:5]:
            self.log(self.getline(), self.failed )

        # read the exactly the rest
        ret = self.slBsdHandle.Recv( sd, len(self.data_2) - 5, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_2) - 5) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[5:]:
            self.log(self.getline(), self.failed )

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync3), 0, self.sync3)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(3)


        # Third test 2 buffer from differnet source port  < payload 2 reads 3

        # first packet from pc mng prot

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_3_0) +  len(self.data_3_1 )) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != (self.data_3_0 + self.data_3_1):
            self.log(self.getline(), self.failed )



        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()






######################
class BsdTestTcpRecvSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecvSSL", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data1_750 )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != self.data1_750:
            sslprivate.close()
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        sslprivate.send( "*" )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != "*":
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        sslprivate.send( self.data_2 )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.sync3) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # Third test 2 buffer from differnet source port  < payload
        sslprivate.send(self.data_3_0 )
        sslprivate.send(self.data_3_1)



        # wait to end of test msg
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECSNOVERIFY:
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  max paylaod 750 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_750) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_750:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len("*") or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != "*":
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # second test buuffer recive < payload read 3 iteration

        # read only 2 bytes
        ret = self.slBsdHandle.Recv( sd, 2, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 2 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[0:2]:
            self.log(self.getline(), self.failed )
        # read only 3 bytes
        ret = self.slBsdHandle.Recv( sd, 3, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[2:5]:
            self.log(self.getline(), self.failed )

        # read the exactly the rest
        ret = self.slBsdHandle.Recv( sd, len(self.data_2) - 5, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_2) - 5) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[5:]:
            self.log(self.getline(), self.failed )

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync3), 0, self.sync3)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # Third test 2 buffer from differnet source port  < payload 2 reads 3

        # first packet from pc mng prot

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_3_0) +  len(self.data_3_1 )) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != (self.data_3_0 + self.data_3_1):
            self.log(self.getline(), self.failed )



        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



class BsdTestTcpRecvNonBlockingSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecvNonBlockingSSL", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync1)
        if rdata.find(self.sync1) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data1_750 )


        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        sslprivate.send( self.data_2 )

        # wait to end of test msg
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  call rev with no wait flag
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, BsdUtils.MSG_DONTWAIT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )

        # sync
        ret = self.slBsdHandle.Send( sd, len(self.sync1), 0, self.sync1 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_750) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_750:
            self.log(self.getline(), self.failed )


        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # test  call rev no data , should return
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )


        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()





class BsdTestTcpRecvTimeOutSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecvTimeOutSSL", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )


        # now pc and sl are sync
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync1)
        if rdata.find(self.sync1) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data1_750 )

        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        time.sleep(11)

        sslprivate.send( self.data_2 )

        # wait to end of test msg
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY  )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVTIMEO, 8, utils.convert_to_propriety_long(20) + ":" +  utils.convert_to_propriety_long(0)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # now pc and sl are sync by tcp connection
        # first test  call rev with no wait flag
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )

        # sync
        ret = self.slBsdHandle.Send( sd, len(self.sync1), 0, self.sync1 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_750) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_750:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()





class BsdTestTcpServerCloseWithSelectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpServerCloseWithSelectSSL", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data_2 )
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)


        # First time data should recv althouh server already close connection
        # first test  max paylaod 750 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



NUM_PACKETS_TO_SEND_BEFORE_EXIT = (30 * SSL_DELAY)  # 150 no accelerators



class BsdTestTcpNonBlockingConnectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpNonBlockingConnectSSL", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
            if udpSd in rlist:
                rdata = udpSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            else: # timeout
                udpSd.close()
                self.log(self.getline(), self.failed )

            udpSd.close()
            # data recv ready to load tcp server
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            s.listen(4)
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e

            try:
                sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate,keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
            except Exception, e:
                print e
                self.log(self.getline(), self.failed )
            ret = sslprivate.cipher()
            if ret != None:
                print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            else:
                self.log(self.getline(), self.failed )

            # now client is connected
            loop = True
            index = 0
            while loop:
                rlist, xlist, xlist = select.select([sslprivate], [],[], 20 ) #timeout 1 seconds
                if sslprivate in rlist:
                    rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        loop = False
                    else:
                        sslprivate.send( rdata )
                else: # timeout
                     index = index + 1
                     if index > 10: # wait to connect up to 10 seconds
                         s.close()
                         privateSd.close()
                         self.log(self.getline(), self.failed )

            sslprivate.close()
            s.close()
            privateSd.close()
            self.log(self.getline(), self.success )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        #try to connect to non exist server - should failure after timeout
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] == BsdUtils.BSD_ESECGENERAL:
            print "SECURE FAILURE !!!!"
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY:
            self.log(self.getline(), self.failed )

        # udp for sync in order server up
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"

        time.sleep(1)

        loop = True
        i = 1
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            #self.log(self.getline(), self.info, str(ret[1]) )
            if ret[1] == 0:
                loop = False
            if i > 15:
                self.log(self.getline(),self.failed, str(sd) )
            time.sleep(0.2)
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            time.sleep(1)
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.3)


        #connected send data on tcp socket+ wait to reply
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( sd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        time.sleep(1)
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            #print ret
            if sd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )

        #send end of test
        time.sleep(0.3)
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()




class BsdTestTcpNonBlockingConnectWithSelectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpNonBlockingConnectWithSelectSSL", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
            if udpSd in rlist:
                rdata = udpSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            else: # timeout
                udpSd.close()
                self.log(self.getline(), self.failed )

            udpSd.close()
            time.sleep(1)
            # data recv ready to load tcp server
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            s.listen(4)
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            try:
                sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate,keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
            except Exception, e:
                print e
                self.log(self.getline(), self.failed )

            ret = sslprivate.cipher()
            if ret != None:
                print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            else:
                self.log(self.getline(), self.failed )


            # now client is connected
            loop = True
            index = 0
            while loop:
                rlist, xlist, xlist = select.select([sslprivate], [],[], 1 ) #timeout 1 seconds
                if sslprivate in rlist:
                    rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        loop = False
                    else:
                        sslprivate.send( rdata )
                else: # timeout
                     index = index + 1
                     if index > 10: # wait to connect up to 10 seconds
                         s.close()
                         sslprivate.close()
                         self.log(self.getline(), self.failed )
            sslprivate.close()
            s.close()
            privateSd.close()
            self.log(self.getline(), self.success )
            s.close()

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # udp for sync in order server up
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"


        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] == BsdUtils.BSD_ESECGENERAL:
            print "SECURE FAILURE !!!!"
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY: # must return with try again ...
            self.log(self.getline(), self.failed )

        #No server, wait on select, select should return with sd , when pollong again should (connect) should return with ERROR

        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        time.sleep(1)
        ret = ret = self.slBsdHandle.Select(sd + 1, 9,0, 1, fdset,  0, 0, 0, 3 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[5] )
            if status == 1:

                # check errno
                ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                ret = utils.unpackUSHORT( ret[4][:2] )
                print ret
                if ret != BsdUtils.BSD_ECONNREFUSED:
                    self.log(self.getline(), self.failed )

                ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                   print "SECURE FAILURE !!!!"
                   self.log(self.getline(), self.failed )
                if ret[1] != BsdUtils.BSD_ECONNREFUSED: # Must retunr with ERROR
                    self.log(self.getline(), self.failed )

                # check errno
                ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                ret = utils.unpackUSHORT( ret[4][:2] )
                print ret
                if ret != BsdUtils.BSD_ECONNREFUSED:
                    self.log(self.getline(), self.failed )

        else:
            self.log(self.getline(), self.failed )

        i = 0
        #send data in order to load server
        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.1)

        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        time.sleep(0.1)

        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(1)

        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] == BsdUtils.BSD_ESECGENERAL:
            print "SECURE FAILURE !!!!"
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY: # get pool again , server is still not up
            self.log(self.getline(), self.failed )
        i = 0
        while i < 5:
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            time.sleep(0.5)
            i = i + 1


        #self.log(self.getline(),self.info, str(ret[1]) )
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 9,0, 1, fdset,  0, 0, 0, 1000 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[5] )
            if status == 1:

                # check errno == 0
                ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                ret = utils.unpackUSHORT( ret[4][:2] )
                print ret
                if ret !=  0:
                    self.log(self.getline(), self.failed )

                ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[1] != 0: # connected !!!
                    self.log(self.getline(), self.failed )

                    # check errno  = BSD_EISCONN
                    ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    ret = utils.unpackUSHORT( ret[4][:2] )
                    print ret
                    if ret != 0:
                        self.log(self.getline(), self.failed )


        else: # timeout
            self.log(self.getline(), self.failed )


        #connected send data on tcp socket+ wait to reply
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( sd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        time.sleep(1)
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            #print ret
            if sd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )

        #send end of test
        time.sleep(0.3)
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


##########


TestCipher = [  # test name | SL method | SL Cipher | Python metod | Python Cipher set + get, | Python method get | python key lenggh get | run python or yassl \
                [  "SSLv3 RSA_WITH_RC4_128_SHA",  BsdUtils.SO_SECMETHOD_SSLV3, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA, SSL.SSLv3_METHOD, "RC4-SHA", "TLSv1/SSLv3", 128, "PYTHON" ],  # MANDATORY - pass\
                [  "TLSv1 RSA_WITH_RC4_128_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA, SSL.TLSv1_METHOD, "RC4-SHA", "TLSv1/SSLv3", 128, "PYTHON" ],  # MANDATORY - pass\
                [  "SSLv3 RSA_WITH_RC4_128_MD5",  BsdUtils.SO_SECMETHOD_SSLV3, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5, SSL.SSLv3_METHOD, "RC4-MD5", "TLSv1/SSLv3", 128, "PYTHON" ],  # Nice to Have - pass\
                [  "TLSv1 RSA_WITH_RC4_128_MD5",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5, SSL.TLSv1_METHOD, "RC4-MD5", "TLSv1/SSLv3", 128 ,"PYTHON" ],  # Nice to Have - pass\
                [  "TLSv1 RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA, SSL.SSLv23_METHOD, "AES256-SHA", "TLSv1/SSLv3", 256, "PYTHON"  ],  # Nice to Have - pass\
                [  "TLSv1 DHE_RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_TLS_DHE_RSA_WITH_AES_256_CBC_SHA, SSL.SSLv23_METHOD, "DHE-RSA-AES256-SHA", "TLSv1/SSLv3", 128, "PYTHON" ],  # Failed\
                [  "TLSv1 ECDHE_RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA, SSL.SSLv23_METHOD, "ECDHE-RSA-AES256-SHA", "TLSv1/SSLv3", 256, "PYTHON" ],
                [  "TLSv1 ECDHE_RSA_WITH_RC4_128_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_TLS_ECDHE_RSA_WITH_RC4_128_SHA, SSL.SSLv23_METHOD, "ECDHE-RSA-RC4-SHA", "TLSv1/SSLv3", 128, "PYTHON" ],
               [  "TLSv1 RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1_1, BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA, SSL.SSLv23_METHOD, "AES256-SHA", "TLSv1/SSLv3", 256, "PYTHON"  ],  # Nice to Have - pass\
               [  "TLSv1 RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1_2, BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA, SSL.SSLv23_METHOD, "AES256-SHA", "TLSv1/SSLv3", 256, "PYTHON"  ],  # Nice to Have - pass\
               [  "TLSv1 RSA_WITH_AES_128_GCM_SHA256",BsdUtils.SO_SECMETHOD_TLSV1_2,BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_128_GCM_SHA256,SSL.SSLv23_METHOD,"AES128-GCM-SHA256", "TLSv1/SSLv3", 256, "PYTHON"],
              ]

class BsdTestTcpBlockingConnectCoverChiperSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingConnectCoverChiperSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.use_certificate_file(ServerCertificate)
        ctx.use_privatekey_file(ServerPrivateKey)
        ctx.load_tmp_dh(ServerDH)
        ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        try:
            privateSd.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        #ret = privateSd.cipher()
        #print  "SSL connected " + TestCipher[i][4] + " " + TestCipher[i][5] + " " + TestCipher[i][6]
        #if ret[0] != TestCipher[i][4]:
        #    self.log(self.getline(), self.failed )
        #if ret[1] != TestCipher[i][5]:
        #    self.log(self.getline(), self.failed )
        #if ret[2] != TestCipher[i][6]:
        #    self.log(self.getline(), self.failed )

        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )

        privateSd.send( rdata )
        privateSd.close()
        s.close()



    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "connect_" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            #tmp = [os.getcwd()+ "\server.exe", "-d", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            tmp = [os.getcwd()+ "\server.exe", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            #os.spawnv( os.P_NOWAIT, 'C:\python27\python', ['server.exe', 'C:\python_bsd_test_ssl\MiddleSSL.py  -p 8000 -m 6000 -d 7000'])
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        pass


    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
        while i < len(TestCipher):
            time.sleep(3)
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackUBYTE( ret[4] )
            if ret != int(TestCipher[i][1]):
                self.log(self.getline(), self.failed )



            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackLONG( ret[4] )
            if ret != TestCipher[i][2]:
                self.log(self.getline(), self.failed )


            #try to connect to non exist server -
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] != 0:
                self.log(self.getline(), self.failed )

            #connected send data on tcp socket+ wait to reply

            ret = self.slBsdHandle.Send( sd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                #print ret
                if sd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1
        self.log(self.getline(), self.success )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpSSLConnectSTARTTLS(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpSSLConnectSTARTTLS", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.use_certificate_file(ServerCertificate)
        ctx.use_privatekey_file(ServerPrivateKey)
        ctx.load_tmp_dh(ServerDH)
        ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        privateSd.send("I am a server")
        privateSd.recv(1000)
        privateSd.send("Hello to you")
        privateSd.recv(1000)
        privateSd.send("yalla")
        privateSd = SSL.Connection(ctx, privateSd)
        ###############################################################################################

        privateSd.set_accept_state()

        try:
            privateSd.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )


        #ret = privateSd.cipher()
        #print  "SSL connected " + TestCipher[i][4] + " " + TestCipher[i][5] + " " + TestCipher[i][6]
        #if ret[0] != TestCipher[i][4]:
        #    self.log(self.getline(), self.failed )
        #if ret[1] != TestCipher[i][5]:
        #    self.log(self.getline(), self.failed )
        #if ret[2] != TestCipher[i][6]:
        #    self.log(self.getline(), self.failed )

        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        print rdata
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )


        privateSd.send( rdata )
        privateSd.close()
        s.close()



    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "connect_" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            #tmp = [os.getcwd()+ "\server.exe", "-d", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            tmp = [os.getcwd()+ "\server.exe", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            #os.spawnv( os.P_NOWAIT, 'C:\python27\python', ['server.exe', 'C:\python_bsd_test_ssl\MiddleSSL.py  -p 8000 -m 6000 -d 7000'])
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        pass


    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        time.sleep(10)
        #time.sleep(10)  # first time in order to sync
        i = 0
        while i < len(TestCipher):
            time.sleep(3)
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackUBYTE( ret[4] )
            if ret != int(TestCipher[i][1]):
                self.log(self.getline(), self.failed )



            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackLONG( ret[4] )
            if ret != TestCipher[i][2]:
                self.log(self.getline(), self.failed )

            #try to connect to non exist server -
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] != 0:
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.Recv( sd, 1000, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Send( sd,len("HELO\r\n"),0,"HELO\r\n")
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Recv( sd, 1000, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Send( sd,len("STARTTLS\r\n"),0,"STARTTLS\r\n")
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Recv( sd, 1000, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            # start the negotiation
            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_STARTTLS, 4, utils.convert_to_propriety_long(1) )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            time.sleep(10)


            #connected send data on tcp socket+ wait to reply
            ret = self.slBsdHandle.Send( sd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )

            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                if sd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )

            #close sockets
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1
        self.log(self.getline(), self.success )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpSSLSetSockOptError(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpSSLSetSockOptError", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)



    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            sd  = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            ctx = SSL.Context(SSL.SSLv23_METHOD)
            ctx.use_privatekey_file (ClientKey)
            ctx.use_certificate_file(ClientCertificate)
            ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
            sd = SSL.Connection(ctx, sd)
            loop = 1
            while loop > 0:
                try:
                    sd.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                    loop = 0
                except Exception, e:
                    if loop > 50:
                        print e
                        self.log(self.getline(), self.failed )
                    else:
                        loop = loop + 1
                        time.sleep(1)

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
        time.sleep(3)
        print "Test Cipher: ", str(i), " ",  TestCipher[i]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
        self.slBsdHandle.clearEvents()

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        sd = ret[1]

        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        privateSd = ret[1]

        #check set sock opt secured on the son socket of the server. it shouldn't be success
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_CERT ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )

        #check setsock opt on secured files
        s = utils.str2HexPadded("cert.der",0)
        s=s[:-1]
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES_CERTIFICATE_FILE_NAME, len("cert.der"), s )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )
        s = utils.str2HexPadded("key.der",0)
        s=s[:-1]
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES_PRIVATE_KEY_FILE_NAME, len("key.der"), s )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )
        s = utils.str2HexPadded("root.der",0)
        s=s[:-1]
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES_CA_FILE_NAME, len("root.der"), s )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )
        s = utils.str2HexPadded("dh.der",0)
        s=s[:-1]
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES_DH_KEY_FILE_NAME, len("dh.der"), s )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        elif( ret[1] != BsdUtils.BSD_ESOCKTNOSUPPORT ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( privateSd, len("done"), 0, "done" )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )

        self.log(self.getline(), self.success )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()

str1 = '1234567890qwer123$vZnmbg65443g*&^%$#DFc1'
str2 = 'rtryuhhggdeuuook,jk$^^&&*4524579)_+_+*854354456566889'
str3 = '678794543dfdfgghgDFDGHy4eet44@##$$%^^&**(()$#$%^^*&ghGHGHDrer232355667789'
str4 = '343566889hjjkkdfffj8998909yjnkklhhdf456577987jjolk;gfhrt768798ut56uhjjh57578678678yjhkhlj;f656FFfg'
str5 = '1234567890'
#large_buffers = [''.join( str1 for i in range(0, 300)), ''.join( str2 for i in range(0, 201)),  ''.join( str3 for i in range(0, 219 )), ''.join( str3 for i in range(0, 111 )), ''.join( str5 for i in range(0, 8 ))]
large_buffers = [''.join( str1 for i in range(0, 300))]
class BsdTestTcpBlockingConnectCoverChiperSSLLargeData(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        print "slBsdHandle", slBsdHandle
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingConnectCoverChiperSSLLargeData", slBsdHandle, fileHandle )
        print "self.slBsdHandle", self.slBsdHandle
        #rand_str = '1234567890qwer123$vZnmbg65443g*&^%$#DFc1'
        #rand_str = 'g'
        remain_str = '6'
        #self.ssldata = ''.join( rand_str for i in range(0,(SSL_LARGE_PAYLOAD_LEN / len(rand_str)) ))
        #self.ssldata += ''.join( remain_str for i in range(0,(SSL_LARGE_PAYLOAD_LEN % len(rand_str)) ))
        #rand_str = 'bgfd763---9shgfrdtASAFFGF235)(7543X124@%'
        #self.ssldata += ''.join( rand_str for i in range(0,(SSL_LARGE_PAYLOAD_LEN / len(rand_str))/2) )
        #TestCipher = TestCipherPyOnly
        print TestCipher
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        print "running python SSL"
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.use_certificate_file(ServerCertificate)
        ctx.use_privatekey_file(ServerPrivateKey)
        ctx.load_tmp_dh(ServerDH)
        ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        try:
            privateSd.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )


        print 'large buffers'
        for x,buf in enumerate(large_buffers):
            print x, len(buf)

        for i,buf in enumerate(large_buffers):
            privateSd.send( buf )
            if i % 2 == 0:
                time.sleep(2)


        privateSd.close()
        s.close()
    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            for buf in large_buffers:
                #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])
                resultfile = "connect_" +  str(i) + "_" + TestCipher[i][4] + ".txt"
                #tmp = [os.getcwd()+ "\server.exe", "-d", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
                tmp = [os.getcwd()+ "\server_large.exe", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] , "-S" + buf]
                print tmp
                if os.path.isfile(SYNCFILE):
                   os.remove(SYNCFILE)
                #os.spawnv( os.P_NOWAIT, 'C:\python27\python', ['server.exe', 'C:\python_bsd_test_ssl\MiddleSSL.py  -p 8000 -m 6000 -d 7000'])
                print os.getcwd()
                print "subprocess.call"
                subprocess.call(tmp)


        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        pass


    def PC(self):
            print "Run PC"
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        print "Run SL"
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
            #python tests
        i = 0
        while i < len(TestCipher):
            if TestCipher[i][7] ==  "PYTHON":
                time.sleep(3)
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                self.slBsdHandle.clearEvents()

                ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                sd = ret[1]
                #self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
                self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

                ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

                ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

                #try to connect to non exist server -
                ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[1] != BsdUtils.BSD_ESECSNOVERIFY:
                    self.log(self.getline(), self.failed )

                #connected send data on tcp socket+ wait to reply

                #ret = self.slBsdHandle.Send( sd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
                #if( ret[0] == False ):
                    #self.log(self.getline(),self.failed  )

                print 'large buffers'
                for x,buf in enumerate(large_buffers):
                    print x, len(buf)


                for buf in large_buffers:
                    print 'starting large data test len: ', len(buf)
                    rsize = 0
                    retbuf = ""
                    while rsize < len(buf):

                        remaining = len(buf) - rsize
                        if remaining > self.MAX_PAYLOAD_IPV4_TCP_SSL:
                            remaining = self.MAX_PAYLOAD_IPV4_TCP_SSL

                        print 'remaining: ', remaining
                        ret = self.slBsdHandle.Recv( sd, remaining, 0 )
                        if( ret[0] == False ):
                            self.log(self.getline(),self.failed  )
                        else:
                            print ret[1]
                            retbuf += ret[3]
                            rsize = rsize + ret[1]
                            print "rsize ", rsize

                    if sd == ret[2] and len(buf) == rsize and retbuf == buf:
                            print 'test passed'
                            pass
                    else:
                            print 'test failed'
                            self.log(self.getline(),self.failed  )


                #close sockets
                ret = self.slBsdHandle.Close( sd )
                if( ret[0] == False ):
                    self.log(self.getline(),self.failed, str(sd) )



            else: #yassl tests
                for buf in large_buffers:
                    time.sleep(3)
                    print "Test Cipher: ", str(i), " ",  TestCipher[i]
                    self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                    self.slBsdHandle.clearEvents()

                    ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    sd = ret[1]
                    #self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
                    self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )

                    ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )

                    ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )

                    #try to connect to non exist server -
                    ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) + i), slConf.PC_IPV4 )
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    if ret[2] != sd:
                        self.log(self.getline(), self.failed )
                    if ret[1] == BsdUtils.BSD_ESECGENERAL:
                        print "SECURE FAILURE !!!!"
                        self.log(self.getline(), self.failed )
                    if ret[1] != BsdUtils.BSD_ESECSNOVERIFY:
                        self.log(self.getline(), self.failed )

                    print '### starting yassl large data test len: ', len(buf)
                    rsize = 0
                    retbuf = ""
                    while rsize < len(buf):

                        remaining = len(buf) - rsize
                        if remaining > self.MAX_PAYLOAD_IPV4_TCP_SSL:
                            remaining = self.MAX_PAYLOAD_IPV4_TCP_SSL

                        print 'remaining: ', remaining
                        ret = self.slBsdHandle.Recv( sd, remaining, 0 )
                        if( ret[0] == False ):
                            self.log(self.getline(),self.failed  )
                        else:
                            print ret[1]
                            retbuf += ret[3]
                            rsize = rsize + ret[1]
                            print "rsize ", rsize


                    if sd == ret[2] and len(buf) == rsize and retbuf == buf:
                            print 'test passed'
                    else:
                            print 'test failed'
                            self.log(self.getline(),self.failed  )

                    #close sockets
                    ret = self.slBsdHandle.Close( sd )
                    if( ret[0] == False ):
                        self.log(self.getline(),self.failed, str(sd) )

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1




        self.log(self.getline(), self.success )



    def run(self):
        print "self.slBsdHandle", self.slBsdHandle
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()
###########         server    #######################


class BsdTestTcpClientCloseWithSelectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientCloseWithSelectSSL", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)


    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        try:
            sslSD = ssl.wrap_socket(s, ca_certs=ServerCA, cert_reqs=ssl.CERT_REQUIRED)
        except Exception, e:
            print e
        while loop > 0:
            try:
                sslSD.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    sslSD.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(1)
        ret = sslSD.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        time.sleep(1) # let set sockopt after accept
        sslSD.send(self.data_2)
        sslSD.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec


        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 750 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != privateSd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )


        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()

class BsdTestTcpClientCloseWithSelectSSLRST(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientCloseWithSelectSSLRST", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)


    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        try:
            sslSD = ssl.wrap_socket(s, ca_certs=ServerCA, cert_reqs=ssl.CERT_REQUIRED)
        except Exception, e:
            print e
        while loop > 0:
            try:
                sslSD.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    sslSD.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(1)
        ret = sslSD.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        sslSD.send(self.data_2)
        l_onoff = 1
        l_ligner = 0
        s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii',l_onoff, l_ligner))

        sslSD.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )
        time.sleep(3)

        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 750 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != privateSd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )


        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()
            
            


class BsdTestNonBlockingAcceptSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestNonBlockingAcceptSSL", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            while i < 5:
                rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
                if udpSd in rlist:
                    rdata = udpSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    i = i + 1
                else: # timeout
                    self.log(self.getline(), self.failed )

            udpSd.close()


            # Test TCP
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            try:
                s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            except Exception, e:
                print e
                s.close()

            try:
                sslSD = ssl.wrap_socket(s, ca_certs=ServerCA, cert_reqs=ssl.CERT_REQUIRED)
            except Exception, e:
                print e
            try:
                sslSD.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
            except Exception, e:
                print e
                ssslSD.close()
                self.log(self.getline(), self.failed )

            ret = sslSD.cipher()
            if ret != None:
                print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            else:
                self.log(self.getline(), self.failed )

            loop = True
            while loop:
                rlist, xlist, xlist = select.select([sslSD], [],[], self.TIMEOUT * SSL_DELAY )
                if sslSD in rlist:
                    rdata = sslSD.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        loop = False
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        self.log(self.getline(), self.success )
                        sslSD.close()
                    else:
                        sslSD.send( rdata )
                else: # timeout
                     loop = False
                     sslSD.close()
                     self.log(self.getline(), self.failed )

    def SL(self):

        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"

        # opem server socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        loop = True
        i = 1
        while loop:
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                if ret[2] == sd:
                    if ret[1] == BsdUtils.BSD_ESECGENERAL:
                        print "SECURE FAILURE !!!!"
                        self.log(self.getline(), self.failed )
                    elif ret[1] == BsdUtils.BSD_EAGAIN:
                        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
                        if( ret[0] == False ):
                            self.log(self.getline(), self.failed )
                        i = i + 1
                        time.sleep(0.1) #sleep 100 ms between data
                        if i == NUM_PACKETS_TO_SEND_BEFORE_EXIT:
                            ret = self.slBsdHandle.Close( sd )
                            if( ret[0] == False ):
                                self.log(self.getline(),self.failed, str(privateSd) )
                            ret = self.slBsdHandle.Close( udpSd )
                            if( ret[0] == False ):
                                self.log(self.getline(),self.failed, str(privateSd) )
                            self.log(self.getline(), self.failed )
                    elif True == BsdUtils.IsBsdError(ret[1], [] ):
                        self.log(self.getline(), self.failed )
                    elif True == self.checkSocketRange( ret[1] ):
                        privateSd = ret[1]
                        loop = False

        # check accept
        if False == self.checkSocketRange( privateSd ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != slConf.AF_INET:
            self.log(self.getline(), self.failed )
        if ret[4] != slConf.PC_PORT:
            self.log(self.getline(), self.failed )
        if ret[5] != slConf.PC_IPV4:
            self.log(self.getline(), self.failed )

        # client connected , send and recv data
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( privateSd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            print ret
            if privateSd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )
        #send end sync event
        ret = self.slBsdHandle.Send( privateSd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
         if self.slBsdHandle != None:
            self.SL()
         else:
            self.PC()




class BsdTestNonBlockingAcceptWithSelectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestNonBlockingAcceptWithSelectSSL", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            while i < 3:
                rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
                if udpSd in rlist:
                    rdata = udpSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    i = i + 1
                else: # timeout
                    udpSd.close()
                    self.log(self.getline(), self.failed )
            udpSd.close()
            # Test TCP
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            try:
                s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            except Exception, e:
                print e
                s.close()

            try:
                sslSD = ssl.wrap_socket(s, ca_certs=ServerCA, cert_reqs=ssl.CERT_REQUIRED)
            except Exception, e:
                print e
            loop = 1
            while loop > 0:
                try:
                    sslSD.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                    loop = 0
                except Exception, e:
                    if loop > 50:
                        print e
                        sslSD.close()
                        self.log(self.getline(), self.failed )
                    else:
                        #print "loop ", loop
                        loop = loop + 1
                        time.sleep(1)

            ret = sslSD.cipher()
            if ret != None:
                print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            else:
                self.log(self.getline(), self.failed )


            loop = True
            while loop:
                rlist, xlist, xlist = select.select([sslSD], [],[], self.TIMEOUT * SSL_DELAY )
                if sslSD in rlist:
                    rdata = sslSD.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        loop = False
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        self.log(self.getline(), self.success )
                        sslSD.close()
                    else:
                        sslSD.send( rdata )
                else: # timeout
                     loop = False
                     sslSD.close()
                     self.log(self.getline(), self.failed )

    def SL(self):

        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"

        # opem server socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(0)+ ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        loop = True
        # call first time accept non blocking
        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        i = 0
        while i < 5:
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            time.sleep(1)
            i = i + 1

        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 0, 1000, BsdUtils.BSDTIMEOUT * SSL_DELAY  )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[2] == sd:
                    if False == BsdUtils.IsBsdError(ret[1], [] ):
                        privateSd = ret[1]
                        # check accept
                        if True == self.checkSocketRange( privateSd ):
                            if ret[2] != sd:
                                self.log(self.getline(), self.failed )
                            if ret[3] != slConf.AF_INET:
                                self.log(self.getline(), self.failed )
                            if ret[4] != slConf.PC_PORT:
                               self.log(self.getline(), self.failed )
                            if ret[5] != slConf.PC_IPV4:
                               self.log(self.getline(), self.failed )
                        else:
                           self.log(self.getline(), self.failed )
                    else:
                        self.log(self.getline(), self.failed )
        else:
            print 'TIME OUT'
            self.log(self.getline(), self.failed )


        # client connected , send and recv data
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( privateSd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            print ret
            if privateSd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )
        #send end sync event
        ret = self.slBsdHandle.Send( privateSd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpSSLAcceptSTARTTLS(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpSSLAcceptSTARTTLS", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)
    def verify_cb(inst,conn, cert, errnum,depth, ok):
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok


    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ctx.load_verify_locations(ServerCA)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        #s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))

        #raw_input("Press To Connect")

        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    self.log(self.getline(), self.failed )
                else:
                    loop = loop + 1
                    time.sleep(1)
        try:
            s.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        rdata = s.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )
        s.send( rdata )
        s.close()



    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "accept" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            tmp = [os.getcwd()+ "\client.exe", "-h" + slConf.SL_IPV4, "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.SL_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                time.sleep(5)
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )


    def SL(self):
        self.log(self.getline(), self.start )
        i = 0
        while i < len(TestCipher):
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] )
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
            if( ret[0] == False ):
                     self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT)))
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.Listen( sd, 2 )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                privateSd = ret[1]
                if False == self.checkSocketRange( privateSd ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[3] != slConf.AF_INET:
                    self.log(self.getline(), self.failed )
                if ret[5] != slConf.PC_IPV4:
                    self.log(self.getline(), self.failed )


            time.sleep(1)

            ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_STARTTLS, 4, utils.convert_to_propriety_long(1) )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


            time.sleep(10)

            #connected send data on tcp socket+ wait to reply

            ret = self.slBsdHandle.Send( privateSd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                #print ret
                if privateSd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( privateSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1

        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpSSLMixConnectionAndFail(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpSSLMixConnectionAndFail", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "
        self.MAX_SOCKETS = 5
        self.PAYLOAD= 27

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        sdList  = []
        sdc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sdc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, sdc.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        sslprivate = ssl.wrap_socket(sdc, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3], ca_certs = ServerCA, ciphers=TestCipher[i][4] )

        loop = 1
        while loop > 0:
            try:
                sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    self.log(self.getline(), self.failed )
                else:
                    loop = loop + 1
                    time.sleep(1)




        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(2)
        for a in range( self.MAX_SOCKETS ):
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            try:
                sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
            except Exception, e:
                print e
                self.log(self.getline(), self.failed, e )

            ret = sslprivate.cipher()
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            if ret[0] != TestCipher[i][4]:
                self.log(self.getline(), self.failed )
            if ret[1] != TestCipher[i][5]:
                self.log(self.getline(), self.failed )
            if ret[2] != TestCipher[i][6]:
                self.log(self.getline(), self.failed )
            sdList.append( sslprivate )
        time.sleep(5)
        for osd in sdList:
            osd.close()
            #privateSd.close()
        s.close()

    def PC(self):
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(0), " ",  TestCipher[0]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[0][0] + " -> " + TestCipher[0][7])
            self.run_python(0)
            self.log( self.getline(), self.info, "End-> " + TestCipher[0][0] )
            self.log( self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
        connectingList = []
        sdList  = []
        time.sleep(3)
        print "Test Cipher: ", str(i), " ",  TestCipher[i]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
        self.slBsdHandle.clearEvents()
        sd = 0
        #open one server
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd2 = ret[1]
        self.slBsdHandle.SetSockOpt( sd2, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd2, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd2, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd2, slConf.AF_INET, str(int(slConf.SL_PORT)))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd2, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )
        ret = self.slBsdHandle.Accept( sd2, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd2:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )


        time.sleep(1)

        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_STARTTLS, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )


        time.sleep(10)
        sdList.append(privateSd)
        sdList.append(sd2)


        #open one connection
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd1 = ret[1]

        ret = self.slBsdHandle.SetSockOpt( sd1, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd1, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd1, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Connect( sd1, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd1, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_STARTTLS, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        sdList.append(sd1)



        for a in range(self.MAX_SOCKETS):
            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            connectingList.append(sd)
            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
        s = 0
        while len(connectingList):
            print "sdList"
            print sdList
            print "connectingList"
            print connectingList
            for cSd in connectingList:
                ret = self.slBsdHandle.Connect( cSd, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != cSd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ( ret[1] == BsdUtils.BSD_ESECT00MANYSSLOPENED ):
                    print "open 4 ssl sockets already"
                    sdList.append(cSd)
                elif ret[1] == 0:
                    sdList.append(cSd)
                    s = s + 1
                elif ret[1] == BsdUtils.BSD_ESECSNOVERIFY:
                    sdList.append(cSd)
                    s = s + 1
            sdList, connectingList = self.removeAfromB(  sdList, connectingList)
        if( s > self.MAX_SOCKETS - 1 ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        for cSd in sdList:
            data = str(cSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (cSd & utils.BSD_SOCKET_ID_MASK ) + 1))+ "@" + str(cSd)
            ret = self.slBsdHandle.Close( cSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(cSd) )

        self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestNonBlockingAcceptWithSelectSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestNonBlockingAcceptWithSelectSSL", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            while i < 3:
                rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
                if udpSd in rlist:
                    rdata = udpSd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    i = i + 1
                else: # timeout
                    udpSd.close()
                    self.log(self.getline(), self.failed )
            udpSd.close()
            # Test TCP
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            try:
                s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            except Exception, e:
                print e
                s.close()

            try:
                sslSD = ssl.wrap_socket(s, ca_certs=ServerCA, cert_reqs=ssl.CERT_REQUIRED)
            except Exception, e:
                print e
            loop = 1
            while loop > 0:
                try:
                    sslSD.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                    loop = 0
                except Exception, e:
                    if loop > 50:
                        print e
                        sslSD.close()
                        self.log(self.getline(), self.failed )
                    else:
                        #print "loop ", loop
                        loop = loop + 1
                        time.sleep(1)

            ret = sslSD.cipher()
            if ret != None:
                print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            else:
                self.log(self.getline(), self.failed )


            loop = True
            while loop:
                rlist, xlist, xlist = select.select([sslSD], [],[], self.TIMEOUT * SSL_DELAY )
                if sslSD in rlist:
                    rdata = sslSD.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        loop = False
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        self.log(self.getline(), self.success )
                        sslSD.close()
                    else:
                        sslSD.send( rdata )
                else: # timeout
                     loop = False
                     sslSD.close()
                     self.log(self.getline(), self.failed )

    def SL(self):

        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"

        # opem server socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(0)+ ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        loop = True
        # call first time accept non blocking
        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        i = 0
        while i < 30:
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            time.sleep(0.2)
            i = i + 1

        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 0, 1000, BsdUtils.BSDTIMEOUT * SSL_DELAY  )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[2] == sd:
                    if False == BsdUtils.IsBsdError(ret[1], [] ):
                        privateSd = ret[1]
                        # check accept
                        if True == self.checkSocketRange( privateSd ):
                            if ret[2] != sd:
                                self.log(self.getline(), self.failed )
                            if ret[3] != slConf.AF_INET:
                                self.log(self.getline(), self.failed )
                            if ret[4] != slConf.PC_PORT:
                               self.log(self.getline(), self.failed )
                            if ret[5] != slConf.PC_IPV4:
                               self.log(self.getline(), self.failed )
                        else:
                           self.log(self.getline(), self.failed )
                    else:
                        self.log(self.getline(), self.failed )
        else:
            print 'TIME OUT'
            self.log(self.getline(), self.failed )


        # client connected , send and recv data
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( privateSd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            print ret
            if privateSd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )
        #send end sync event
        ret = self.slBsdHandle.Send( privateSd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()
            
            
            
            
class BsdTestSSLAcceptNonBlockingImmidiateDisconnect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestSSLAcceptNonBlockingImmidiateDisconnect", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)
    def verify_cb(inst,conn, cert, errnum,depth, ok):
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok


    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ctx.load_verify_locations(ServerCA)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        #s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        
        #raw_input("Press To Connect")

        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    self.log(self.getline(), self.failed )
                else:
                    loop = loop + 1
                    time.sleep(1)
        try:
            s.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        s.close()
        time.sleep(2) 

    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            time.sleep(5)
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            self.run_python(i)
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )            
            self.log(self.getline(), self.success )


    def SL(self):
        self.log(self.getline(), self.start )
        i = 0
        
        print "Test Cipher: ", str(i), " ",  TestCipher[i]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] )
        self.slBsdHandle.clearEvents()

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
            
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT)))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )
             
        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            print privateSd
            if ret[1] != BsdUtils.BSD_EAGAIN:
                print "SECURE FAILURE 1111!!!!"
                self.log(self.getline(), self.failed )
            
        #wait for disconnect from other side
        time.sleep(10) 
                
        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )        
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )           
                

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            

        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpBlockingAcceptCoverChiperSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingAcceptCoverChiperSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)
    def verify_cb(inst,conn, cert, errnum,depth, ok):
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok


    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ctx.load_verify_locations(ServerCA)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        #s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
        #raw_input("Press To Connect")

        loop = 1
        while loop > 0:
            try:

                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    self.log(self.getline(), self.failed )
                else:
                    loop = loop + 1
                    time.sleep(1)
        try:
            s.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        print "lgkhsdlkgjlsdkjglsakgjalsdkgnlsadkgnlsdkgnalsdkgnasldkgnlasdkgnlasdkgnsldkgnlsdkgnsldkgnsldkgnsldkgn"
        rdata = s.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        print rdata
        print rdata
        print rdata
        print rdata
        print rdata
        print rdata
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )
        s.send( rdata )
        s.close()


    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "accept" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            tmp = [os.getcwd()+ "\client.exe", "-h" + slConf.SL_IPV4, "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.SL_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                time.sleep(5)
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )


    def SL(self):
        self.log(self.getline(), self.start )
        i = 0
        while i < len(TestCipher):
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] )
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                     self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT)))
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.Listen( sd, 2 )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                privateSd = ret[1]
                if False == self.checkSocketRange( privateSd ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[3] != slConf.AF_INET:
                    self.log(self.getline(), self.failed )
                if ret[5] != slConf.PC_IPV4:
                    self.log(self.getline(), self.failed )



            #connected send data on tcp socket+ wait to reply

            ret = self.slBsdHandle.Send( privateSd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
            print len(self.ssldata + TestCipher[i][0])
            print self.ssldata + TestCipher[i][0]
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                if privateSd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( privateSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1

        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


######################        Many clients   ############################

class BsdTestTcpManyClientSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpManyClientSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "
        self.MAX_SOCKETS = 6
        self.PAYLOAD= 27

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        sdList = []
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(4)
        for a in range(self.MAX_SOCKETS):
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            try:
                sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
            except Exception, e:
                print e
                self.log(self.getline(), self.failed, e )

            ret = sslprivate.cipher()
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            if ret[0] != TestCipher[i][4]:
                self.log(self.getline(), self.failed )
            if ret[1] != TestCipher[i][5]:
                self.log(self.getline(), self.failed )
            if ret[2] != TestCipher[i][6]:
                self.log(self.getline(), self.failed )
            sdList.append( sslprivate )

        for osd in sdList:
            rdata = osd.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            osd.send( rdata )
            osd.close()
            #privateSd.close()
        s.close()
    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        for a in range(self.MAX_SOCKETS):
            try:
                #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

                resultfile = "connect_" +  str(i) + "_" + TestCipher[i][4] + ".txt"
                #tmp = [os.getcwd()+ "\server.exe", "-d", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
                tmp = [os.getcwd()+ "\server.exe", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
                print tmp
                if os.path.isfile(SYNCFILE):
                   os.remove(SYNCFILE)
                #os.spawnv( os.P_NOWAIT, 'C:\python27\python', ['server.exe', 'C:\python_bsd_test_ssl\MiddleSSL.py  -p 8000 -m 6000 -d 7000'])
                print os.getcwd()
                print "subprocess.call"
                subprocess.call(tmp)
                loop = 0
                while loop < 20:
                    loop = loop + 1
                    time.sleep(0.5)
                    if os.path.isfile(SYNCFILE):
                        loop = 500
                if loop != 500:
                    self.log(self.getline(), self.failed )

                # now parse results
            except Exception, e:
                print e
                self.log(self.getline(), self.failed, e )


    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            if TestCipher[i][7] == "PYTHON" :
                self.run_python(i)
            elif TestCipher[i][7] == "YASSL" :
                print " cannot run yassl windows for now"
               # self.run_yassl(i)
            else:
                self.log(self.getline(), self.failed )
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
    #    while i < len(TestCipher):
        if TestCipher[i][7] == "PYTHON" :
            connectingList = []
            sdList  = []
            time.sleep(3)
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            self.slBsdHandle.clearEvents()
            for a in range(self.MAX_SOCKETS):

                ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                sd = ret[1]
                self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                connectingList.append(sd)
                ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

                ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

                #set non blocking publick socket
                ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

            while len(connectingList):
                print "sdList"
                print sdList
                print "connectingList"
                print connectingList
                for cSd in connectingList:                    
                    ret = self.slBsdHandle.Connect( cSd, slConf.AF_INET, str(int(slConf.PC_PORT) + i), slConf.PC_IPV4 )
                    
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    if ret[2] != cSd:
                        self.log(self.getline(), self.failed )
                    if ret[1] == BsdUtils.BSD_ESECGENERAL:
                        print "SECURE FAILURE !!!!"
                        self.log(self.getline(), self.failed )
                    if ret[1] == 0:
                        sdList.append(cSd)
                        print "sd " +str(cSd) + " send data"
                        data = str(cSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (cSd & utils.BSD_SOCKET_ID_MASK ) + 1))+ "@" + str(cSd)
                        ret = self.slBsdHandle.Send( cSd, len(data), 0, data )
                        if( ret[0] == False ):
                            self.log(self.getline(),self.failed  )
                sdList, connectingList = self.removeAfromB(  sdList, connectingList)
            time.sleep(2)
            for cSd in sdList:
                data = str(cSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (cSd & utils.BSD_SOCKET_ID_MASK ) + 1))+ "@" + str(cSd)
                ret = self.slBsdHandle.Recv( cSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(),self.failed  )
                else:
                    #print ret
##                    print len(data)
##                    print ret[1]
##                    print data
##                    print ret[3]
##                    print cSd
##                    print ret[2]
                    if cSd == ret[2] and len(data) == ret[1] and data == ret[3]:
                        pass
                    else:
                        self.log(self.getline(),self.failed  )
                #close sockets
                ret = self.slBsdHandle.Close( cSd )
                if( ret[0] == False ):
                    self.log(self.getline(),self.failed, str(cSd) )

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
        i = i + 1
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()

class BsdTestTcpManyServerSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpManyServerSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "
        self.MAX_SOCKETS = 6
        self.PAYLOAD= 31

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        for a in range(self.MAX_SOCKETS):
            time.sleep(2)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3], ca_certs = ServerCA, ciphers=TestCipher[i][4] )
            loop = 1
            while loop > 0:
                try:
                    sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ i))
                    loop = 0
                except Exception, e:
                    if loop > 50:
                        print e
                        self.log(self.getline(), self.failed )
                    else:
                        loop = loop + 1
                        time.sleep(1)

            ret = sslprivate.cipher()
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            if ret[0] != TestCipher[i][4]:
                self.log(self.getline(), self.failed )
            if ret[1] != TestCipher[i][5]:
                self.log(self.getline(), self.failed )
            if ret[2] != TestCipher[i][6]:
                self.log(self.getline(), self.failed )
            rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            sslprivate.send( rdata )
            sslprivate.close()


    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        for a in range(self.MAX_SOCKETS):
            time.sleep(2)
            try:
                #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

                resultfile = "accept" +  str(i) + "_" + TestCipher[i][4] + ".txt"
                tmp = [os.getcwd()+ "\client.exe", "-h" + slConf.SL_IPV4, "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.SL_PORT) + i) , "-l" + TestCipher[i][4] ]
                print tmp
                if os.path.isfile(SYNCFILE):
                   os.remove(SYNCFILE)
                print os.getcwd()
                print "subprocess.call"
                subprocess.call(tmp)
                loop = 0
                while loop < 20:
                    loop = loop + 1
                    time.sleep(0.5)
                    if os.path.isfile(SYNCFILE):
                        loop = 500
                if loop != 500:
                    self.log(self.getline(), self.failed )

                # now parse results
            except Exception, e:
                print e
                self.log(self.getline(), self.failed, e )

    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            time.sleep(3)
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            if TestCipher[i][7] == "PYTHON" :
                self.run_python(i)
            elif TestCipher[i][7] == "YASSL" :
                self.run_yassl(i)
            else:
                self.log(self.getline(), self.failed )
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        i = 0


        print "Test Cipher: ", str(i), " ",  TestCipher[i]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] )
        self.slBsdHandle.clearEvents()

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

       #set non blocking public socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + i))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        sdList  = []
        while len(sdList) <  self.MAX_SOCKETS:
            print "sdList"
            print sdList
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECNOCAFILE:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_EAGAIN :
                    time.sleep(0.5)
                elif True == BsdUtils.IsBsdError(ret[1], [] ):
                    self.log(self.getline(), str(ret[1]) )
                else:
                    if ret[3] != slConf.AF_INET:
                        self.log(self.getline(), self.failed )
                    if ret[5] != slConf.PC_IPV4:
                        self.log(self.getline(), self.failed )
                    privateSd = ret[1]
                    sdList.append( privateSd )
                    print "privateSd " +str(privateSd) + " send data"
                    data = str(privateSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (privateSd & utils.BSD_SOCKET_ID_MASK ) + 1))+ "@" + str(privateSd)
                    ret = self.slBsdHandle.Send( privateSd, len(data), 0, data )
                    if( ret[0] == False ):
                        self.log(self.getline(),self.failed  )

        time.sleep(1)
        for cSd in sdList:
            data = str(cSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (cSd & utils.BSD_SOCKET_ID_MASK )  + 1))+ "@" + str(cSd)
            ret = self.slBsdHandle.Recv( cSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                #print ret
##                    print len(data)
##                    print ret[1]
##                    print data
##                    print ret[3]
##                    print cSd
##                    print ret[2]
                if cSd == ret[2] and len(data) == ret[1] and data == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( cSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(cSd) )
        # close public
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
        i = i + 1
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpFailConnectMoreThanNSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpFailConnectMoreThanNSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "
        self.MAX_SOCKETS = 7
        self.PAYLOAD= 27

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        sdList = []
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.listen(2)
        for a in range( self.MAX_SOCKETS - 1 ):
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            try:
                sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
            except Exception, e:
                print e
                self.log(self.getline(), self.failed, e )

            ret = sslprivate.cipher()
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
            if ret[0] != TestCipher[i][4]:
                self.log(self.getline(), self.failed )
            if ret[1] != TestCipher[i][5]:
                self.log(self.getline(), self.failed )
            if ret[2] != TestCipher[i][6]:
                self.log(self.getline(), self.failed )
            sdList.append( sslprivate )
        time.sleep(5)
        for osd in sdList:
            osd.close()
            #privateSd.close()
        s.close()

    def PC(self):
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(0), " ",  TestCipher[0]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[0][0] + " -> " + TestCipher[0][7])
            self.run_python(0)
            self.log( self.getline(), self.info, "End-> " + TestCipher[0][0] )
            self.log( self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
        connectingList = []
        sdList  = []
        time.sleep(3)
        print "Test Cipher: ", str(i), " ",  TestCipher[i]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
        self.slBsdHandle.clearEvents()

        for a in range(self.MAX_SOCKETS):
            ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            connectingList.append(sd)
            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
        s = 0
        while len(connectingList):
            print "sdList"
            print sdList
            print "connectingList"
            print connectingList
            for cSd in connectingList:
                ret = self.slBsdHandle.Connect( cSd, slConf.AF_INET, str(int(slConf.PC_PORT)), slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != cSd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ( ret[1] == BsdUtils.BSD_ESECT00MANYSSLOPENED ):
                    print "open 4 ssl sockets already"
                    sdList.append(cSd)
                elif ret[1] == 0:
                    sdList.append(cSd)
                    s = s + 1
                elif ret[1] == BsdUtils.BSD_ESECSNOVERIFY:
                    sdList.append(cSd)
                    s = s + 1
            sdList, connectingList = self.removeAfromB(  sdList, connectingList)
        if( s > self.MAX_SOCKETS - 1 ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        for cSd in sdList:
            data = str(cSd) + "-"+ self.ssldata + TestCipher[i][0] + self.createData(self.PAYLOAD * ( (cSd & utils.BSD_SOCKET_ID_MASK ) + 1))+ "@" + str(cSd)
            ret = self.slBsdHandle.Close( cSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(cSd) )

        self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpFailAcceptMoreThanNSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpFailAcceptMoreThanNSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "
        self.MAX_SOCKETS = 6
        self.PAYLOAD = 31

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        ssls = []
        for a in range(self.MAX_SOCKETS):
            time.sleep(1)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3], ca_certs = ServerCA, ciphers=TestCipher[i][4] )
            try:
                sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ i))
                ssls.append(sslprivate)
            except Exception, e:
                print e
                self.log(self.getline(), self.failed )

        print str(self.MAX_SOCKETS) + " ssl connected"

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3], ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ i))
            self.log(self.getline(), self.failed )
        except Exception, e:
            print e
            print "\n=> failed other side cannot accept secured"
            sslprivate.close()

        for a in ssls:
            a.close()


        #signal other side failed connect to secure
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 55))
        try:
            buf = s.recv(1000)
        except:
            pass
        s.close()

        time.sleep(6)
        # oteher side finsh to close
        print "try to connect more " + str(self.MAX_SOCKETS)

        ssls = []
        for a in range(self.MAX_SOCKETS):
            time.sleep(1)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3], ca_certs = ServerCA, ciphers=TestCipher[i][4] )
            try:
                sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ i))
                ssls.append(sslprivate)
            except Exception, e:
                print e
                self.log(self.getline(), self.failed )

        print "more " + str(self.MAX_SOCKETS) + " ssl connected"
        for a in ssls:
            a.close()

    def PC(self):
            self.log(self.getline(), self.start )
            print "Test Cipher: ", str(1), " ",  TestCipher[0]
            time.sleep(3)
            self.log(self.getline(), self.info, "Start-> " + TestCipher[0][0] + " -> " + TestCipher[0][7])
            self.run_python(0)
            self.log(self.getline(), self.info, "End-> " + TestCipher[0][0] )
            self.log(self.getline(), self.success )
            time.sleep(3)

    def SL(self):
        self.log(self.getline(), self.start )

        print "Test Cipher: ", str(1), " ",  TestCipher[0]
        self.log(self.getline(), self.info, "Start-> " + TestCipher[0][0] )
        self.slBsdHandle.clearEvents()


        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sdSync = ret[1]


        ret = self.slBsdHandle.Bind( sdSync, slConf.AF_INET, str(int(slConf.SL_PORT) + 55))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sdSync, 3 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[0][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[0][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

       #set non blocking public socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 0))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 3 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )
        sdList  = []
        i = 1
        while i:
            print "sdList"
            print sdList
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECNOCAFILE:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_EAGAIN :
                    time.sleep(0.5)
                elif  ret[1] == BsdUtils.BSD_ESECT00MANYSSLOPENED:
                    self.log(self.getline(), str(ret[1]) )
                    i = 0
                elif True == BsdUtils.IsBsdError(ret[1], [] ):
                    self.log(self.getline(), str(ret[1]) )
                else:
                    privateSd = ret[1]
                    print "add socket to list " + str(privateSd)
                    sdList.append( privateSd )
                    if ret[3] != slConf.AF_INET:
                        self.log(self.getline(), self.failed )
                    if ret[5] != slConf.PC_IPV4:
                        self.log(self.getline(), self.failed )
                    if( len(sdList) == self.MAX_SOCKETS):
                        i = 0

        print str(len(sdList)) + " secured connected "


        val = self.slBsdHandle.core.waitEvent("Socket_Async_Event", [], BsdUtils.BSDTIMEOUT )
        print val
        if (val[1])[4] != sd:
            self.log(self.getline(), self.failed )
        if (val[1])[5] != 0:
            self.log(self.getline(), self.failed )
        if (val[1])[6] != BsdUtils.BSD_ESECT00MANYSSLOPENED:
            self.log(self.getline(), self.failed )


        # wait other side failed connect secure
        ret = self.slBsdHandle.Accept( sdSync, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        sdSyncPrivate = ret[1]

        for cSd in sdList:
            #close sockets
            ret = self.slBsdHandle.Close( cSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(cSd) )
        print "wait before close"
        self.slBsdHandle.Close( sdSyncPrivate )
        self.slBsdHandle.Close( sdSync )
        sdList  = []
        i = 1
        while i:
            print "sdList"
            print sdList
            if  len(sdList) == self.MAX_SOCKETS:
                i = 0
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECNOCAFILE:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_EAGAIN :
                    time.sleep(0.5)
                elif  ret[1] == BsdUtils.BSD_ESECT00MANYSSLOPENED:
                    print str(len(sdList)) + " secured socket connected "
                    i = 0
                elif True == BsdUtils.IsBsdError(ret[1], [] ):
                    self.log(self.getline(), str(ret[1]) )
                else:
                    privateSd = ret[1]
                    print "add socket to list " + str(privateSd)
                    sdList.append( privateSd )
                    if ret[3] != slConf.AF_INET:
                        self.log(self.getline(), self.failed )
                    if ret[5] != slConf.PC_IPV4:
                        self.log(self.getline(), self.failed )

        print "more "+ str(len(sdList)) + " secured connected "
        for cSd in sdList:
            #close sockets
            ret = self.slBsdHandle.Close( cSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(cSd) )



        # close public
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        self.log(self.getline(), self.info, "End-> " + TestCipher[0][0] )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestSSlConnectNoCA(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestSSlConnectNoCA", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        sslprivate.send( self.data1_750 )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != self.data1_750:
            sslprivate.close()
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        sslprivate.send( "*" )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != "*":
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        sslprivate.send( self.data_2 )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.sync3) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # Third test 2 buffer from differnet source port  < payload
        sslprivate.send(self.data_3_0 )
        sslprivate.send(self.data_3_1)



        # wait to end of test msg
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(0) + ":" +  str(0) + ":" + str(0) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECSNOVERIFY:
                print "SecureD witout verfiy CA !!!"
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  max paylaod 750 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_750) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_750:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len("*") or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != "*":
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # second test buuffer recive < payload read 3 iteration

        # read only 2 bytes
        ret = self.slBsdHandle.Recv( sd, 2, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 2 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[0:2]:
            self.log(self.getline(), self.failed )
        # read only 3 bytes
        ret = self.slBsdHandle.Recv( sd, 3, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[2:5]:
            self.log(self.getline(), self.failed )

        # read the exactly the rest
        ret = self.slBsdHandle.Recv( sd, len(self.data_2) - 5, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_2) - 5) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[5:]:
            self.log(self.getline(), self.failed )

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync3), 0, self.sync3)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(3)


        # Third test 2 buffer from differnet source port  < payload 2 reads 3

        # first packet from pc mng prot

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_3_0) +  len(self.data_3_1 )) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != (self.data_3_0 + self.data_3_1):
            self.log(self.getline(), self.failed )



        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



class BsdTestSSlConnectErrorCodes(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestSSlConnectErrorCodes", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )


        i = 1
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + 13))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
        try:
            sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
        except Exception, e:
            privateSd.close()
            s.close()
        i = 1
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + 14))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
        try:
            sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
        except Exception, e:
            privateSd.close()
            s.close()
        i = 1
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + 15))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
        try:
            sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
        except Exception, e:
            privateSd.close()
            s.close()

        i = 4
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + 30))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
        try:
            sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
        except Exception, e:
            privateSd.close()
            s.close()


        # habndshake error
      # i = 1
      # s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      # s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
      # s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + 40))
      # s.listen(4)
      # privateSd = None
      # try:
      #     privateSd, addr = s.accept()
      # except Exception, e:
      #     print e
      # try:
      #     sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3], ca_certs = ClientCA, ciphers=TestCipher[i][4] )
      # except Exception, e:
      #     privateSd.close()
      #     s.close()

        # VERSION error
        i = 0

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
        try:
            sslprivate = ssl.wrap_socket( privateSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_REQUIRED, ssl_version=TestCipher[i][3]-1, ca_certs = ClientCA, ciphers=TestCipher[i][4] )
        except Exception, e:
            privateSd.close()
            s.close()


        self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        time.sleep(3)
        self.slBsdHandle.clearEvents()

        # Test error code BSD_ESECBADCERTFILE

        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_PRIVATE_KEY) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )




        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) +  13 ), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        print ret[1]
        if ret[1] !=  BsdUtils.BSD_ESECBADCERTFILE:
            self.log(self.getline(), self.failed )
        else:
            print "BSD_ESECBADCERTFILE"
       #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test error code ESECBADCAFILE

        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(86) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )




        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) +  14 ), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] !=  BsdUtils.BSD_ESECBADCAFILE:
            self.log(self.getline(), self.failed )
        else:
            print "ESECBADCAFILE"
       #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )



        # Test error code BSD_ESECBADPRIVATEFILE

        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        #self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(86) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )




        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) +  15 ), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] !=  BsdUtils.BSD_ESECBADPRIVATEFILE:
            self.log(self.getline(), self.failed )
        else:
            print "BSD_ESECBADPRIVATEFILE"
       #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test error code BSD_ESEC_UNKNOWN_CA
        i = 4
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CA_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )




        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) +  30 ), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] !=  BsdUtils.BSD_ESEC_UNKNOWN_CA:
            self.log(self.getline(), self.failed )
        else:
            print "BSD_ESEC_UNKNOWN_CA"
       #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )





    #   # Test error code BSD_ESEC_HANDSHAKE_FAILURE
    #   i = 1
    #   ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
    #   if( ret[0] == False ):
    #       self.log(self.getline(), self.failed )
    #   sd = ret[1]
    #   self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
    #   if( ret[0] == False ):
    #       self.log(self.getline(), self.failed )
    #
    #
    #   ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
    #   if( ret[0] == False ):
    #       self.log(self.getline(), self.failed )
    #
    #
    #
    #
    #   ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[2][2]) ) # sec , micro sec
    #   if( ret[0] == False ):
    #       self.log(self.getline(), self.failed )
    #
    #
    #
    #   #try to connect to non exist server -
    #   ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) +  40 ), slConf.PC_IPV4 )
    #   if( ret[0] == False ):
    #       self.log(self.getline(), self.failed )
    #   if ret[2] != sd:
    #       self.log(self.getline(), self.failed )
    #   if ret[1] !=  BsdUtils.BSD_ESEC_HANDSHAKE_FAILURE:
    #       self.log(self.getline(), self.failed )
    #   else:
    #       print "BSD_ESEC_HANDSHAKE_FAILURE"
    #  #close sockets
    #   ret = self.slBsdHandle.Close( sd )
    #   if( ret[0] == False ):
    #       self.log(self.getline(),self.failed, str(sd) )











        # Test error code VERSION_ERROR
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, str(int(slConf.PC_PORT) ), slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] !=  BsdUtils.BSD_ESEC_PROTOCOL_VERSION:
            self.log(self.getline(), self.failed )
        else:
            print "BSD_ESEC_PROTOCOL_VERSION"
       #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        self.log(self.getline(), self.success )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()





class BsdTestSSlServerErrorCodes(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestSSlServerErrorCodes", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        time.sleep(5)
        i = 1
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 5))
        except Exception, e:
            print e
        time.sleep(1)
        s.close()


        i = 1
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 10))
        except Exception, e:
            print e
        s.close()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 20))
        except Exception, e:
            print e
        s.close()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 30))
        except Exception, e:
            print e
        s.close()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 40))
        except Exception, e:
            print e
        s.close()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        s.bind((slConf.PC_IPV4, int(slConf.PC_PORT) + i))
        sslprivate = ssl.wrap_socket(s, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[i][3]-1, ca_certs = ServerCA, ciphers=TestCipher[i][4] )
        loop = 1
        time.sleep(21)
        try:
            sslprivate.connect((slConf.SL_IPV4, int(slConf.SL_PORT)+ 50))
        except Exception, e:
            print e
        s.close()

        self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        time.sleep(3)
        self.slBsdHandle.clearEvents()
        # test async event
        i = 4
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        #if( ret[0] == False ):
        #    self.log(self.getline(), self.failed )

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 5))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        val = self.slBsdHandle.Accept( sd, slConf.AF_INET )

        if( val[0] == False ):
            self.log(self.getline(), self.failed )

        val = self.slBsdHandle.core.waitEvent("Socket_Async_Event", [], BsdUtils.BSDTIMEOUT )
        print val
        MATCH_SUITE_ERROR = 0xFCE9 # -791
        if  val[0] == True:
            print val
        if (val[1])[4] != sd:
            self.log(self.getline(), self.failed )
        if (val[1])[5] != 0:
            self.log(self.getline(), self.failed )
        if (val[1])[6] != MATCH_SUITE_ERROR:
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )



        # Test error code BSD_ESECNOCAFILE
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        #self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(86) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro secif( ret[0] == False ):
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 10))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            if ret[1] !=  BsdUtils.BSD_ESECNOCAFILE:
                self.log(self.getline(), self.failed )
            else:
                print "BSD_ESECNOCAFILE"
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test error code BSD_ESECBADCAFILE
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        #self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_PRIVATE_KEY) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro secif( ret[0] == False ):
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 20))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            if ret[1] !=  BsdUtils.BSD_ESECBADCAFILE:
                self.log(self.getline(), self.failed )
            else:
                print "BSD_ESECBADCAFILE"
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


##################

        # Test error code BSD_ESECBADCERTFILE
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_PRIVATE_KEY) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 30))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            if ret[1] !=  BsdUtils.BSD_ESECBADCERTFILE:
                self.log(self.getline(), self.failed )
            else:
                print "BSD_ESECBADCERTFILE"
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test error code BSD_ESECBADPRIVATEFILE
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(86) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 40))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            if ret[1] !=  BsdUtils.BSD_ESECBADPRIVATEFILE:
                self.log(self.getline(), self.failed )
            else:
                print "BSD_ESECBADPRIVATEFILE"
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test error code BSD_ESECBADDHFILE
        i = 1
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(86) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 50))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            if ret[1] !=  BsdUtils.BSD_ESECBADDHFILE:
                self.log(self.getline(), self.failed )
            else:
                print "BSD_ESECBADDHFILE"
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpMssSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpMssSSL", slBsdHandle, fileHandle)
        self.data1_1402 = "jmf0ef-isdf-0i93n92j-0GCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS8"
        self.data2_1402 = "56xdmnopuj09u8-9z908er935rsdfsdf;glsh;74nyo693u7x48fsdt5678678kbhas56gjsjo8ugzhsfgjdghjkghi67tyjhdfjhfgI7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT96PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3W6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RJUY2N6DF797JLMO3P7179PR"
        if len(self.data1_1402) != 1400:
            print len(self.data1_1402)
            self.log(self.getline(), self.failed )
        if len(self.data2_1402) != 1400:
            self.log(self.getline(), self.failed )
        self.MAXSEG =  73

    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)

        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )


        # now pc and sl are sync
        aggData = ""
        loop = True
        while loop:
            rdata =  sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            aggData = aggData + rdata
            if aggData == self.data1_1402:
                print len(aggData)
                loop = False
            else:
               # print len(aggData)
               pass

        sslprivate.send(aggData)

        # now pc and sl are sync
        aggData = ""
        loop = True
        while loop:
            rdata =  sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            aggData = aggData + rdata
            if aggData == self.data2_1402:
                print len(aggData)
                loop = False
            else:
               # print len(aggData)
               pass

        sslprivate.send(aggData)

        # now pc and sl are sync
        aggData = ""
        loop = True
        while loop:
            rdata =  sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            aggData = aggData + rdata
            if aggData == self.data1_1402:
                print len(aggData)
                loop = False
            else:
               # print len(aggData)
               pass

        sslprivate.send(aggData)

        # now pc and sl are sync
        aggData = ""
        loop = True
        while loop:
            rdata =  sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
            aggData = aggData + rdata
            if aggData == self.data2_1402:
                print len(aggData)
                loop = False
            else:
               # print len(aggData)
               pass

        sslprivate.send(aggData)

        rdata =  sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata != self.endSyncMsg:
            self.log(self.getline(), self.failed )

        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(0) + ":" +  str(0) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != 0:
            self.log(self.getline(), self.failed )



        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)


        ret = self.slBsdHandle.Send( sd, len(self.data1_1402), 0, self.data1_1402 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        # test  max paylaod 1440 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1402) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1402:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SendTo( sd, len(self.data2_1402), 0, self.data2_1402 ,slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        # test  max paylaod 1440 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data2_1402) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data2_1402:
            self.log(self.getline(), self.failed )




        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != 1460:
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4, utils.convert_to_propriety_long(self.MAXSEG) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != self.MAXSEG:
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Send( sd, len(self.data1_1402), 0, self.data1_1402 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        # test  max paylaod 1440 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1402) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1402:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.SendTo( sd, len(self.data2_1402), 0, self.data2_1402 ,slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        time.sleep(2)
        # test  max paylaod 1440 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data2_1402) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data2_1402:
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()

## Aggregation tests


class BsdTestTcpAggregationRecvSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpAggregationRecvSSL", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.DATA_6529 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L4D5QIZ4MEB53"
        self.DATA_6529 = self.DATA_6529+ "3h2323errrr333ed43hc3333dhff6gdffffhgfyrfff6fy9ffff8ff000040f080f0dfws8s0df9sd0f9sTestsel.data_2-checkit!@#$%%56jdsfbh237sdcvhasd werf897erf79y93yreyrf9sdfgvywe89yf789erfywer79fyh349-yfvye79rty89dfvya9wehdfwgnm238r5yqfguq9yrt97q4vhw3789fyhv34789vh34789fh3478y378fy3478vyw78vy378fy39ry29-ry9fy34789fyh34789fh3789hf34789vh5897vh3789fhv378fyh578fh34789fh34789fyh54f789h34f78h34f9739dfgvyse9rv  df -r u9dvn wsd7fy89 n98237c4 9    8w37rcqw890ey7r-12387cn 9ewyf uisdhfuy8qwefyhq93rfye9yf1239-8ua[PCKDM `478 89YDCA79WEYR `89Y489Q WYDF89Q34Y7T348 78ERYFASDUIHCV34789RY34 FYSDY129-RYE9R8YFER89YF914E4[  9U CZDFFN123789DH HCV3478FY3478 FYQCY3478FY3478 FY 9FY139 4RY QWEYFQ78934YFHIO12RGY-`-27R3479YR3478Y4789YCVYXD897FVYER789FYQ34R5Y34YRRNX CWE89Y V47R7834YR7813YR-ADAFU NQWEHBDC 238DHQW78D N784F2780RYQ0W7YD C  OAUYS F13478RH134R3478RTY2 BWEDB47RGF23 F34 -0Y FQ23481TY Q368  23T RTG346TR34RT 8334R7834YR780134YR80347YRQ78FYHB4 CF364TFG346TF 346TRF 3468TF 13468RT 348R 31478TY 13478R 13478YR Q78WEYF 3Q2C8213HD 34CG347B368R7"
        self.DATA_6529 = self.DATA_6529 +  "SADSDFSD9-FVIW939-4I9349-R CI,    WE90RI 3489034890 U 3UF890ASDUF890ASDUF890SDFUR C890QSUJDs)FUI 1 WDUA90SDJFKQ23OIRCM 340T81=348R18903478580Q34RT0134URM 34R81 08R5051394R5 13890T 3V4RT893 8934789 374R897348RT738947RT8934R7 8934YRTF 78934YRT7893T784Y5T789YT789Y54 9Y13489RY 1349RY 34789RY 3497YR 1394UYR3489 7R89-37R NE0F8D N14R908CM E09R8WQER23E802UE08237889237897WEDF6 234 `2942Y3R790234T347Y`289-7R 8234N R3417R61347890R6`2-4=23R78QBNRFY-9WE RB236 N2736E789y6r aer79fy7er79fg659t7349y7ernc89erpf 134[r'0134 ur[134r78 ane796f-123r67bp aa;A7    P2374Q0 B4R60346RB NPQN 4R  P w;R71P3274WE- B13409R6 1347RY NP;AWr;/q4thr 134-WEUG[WTMNGWNV-348=34TU [GY75489-T734-9T7QP9TN7 T7134[TP-7T7PT34BT63478B 23478R6 B0349R8734H 780346HR5 PA47 R5HQ   23479H 1349P8H 437975 B3476 178034 613478 0 R6JN34P98R57 JN134786 H37846H 1347806 782346 B08137265 B1347805 6BN 1P56 BQWEKL ILWRLTH54Y9O1239    BWER6Y3478RT3478T63478T674TG677892346T347863478T613478 13478RY 87;OADFUYF3409RT7R57 9327947809234Y667802346023967723967123657189236"
        self.DATA_6529 = self.DATA_6529 +  "das diasedfjkir90w    ir923i2390riw90ei ,sd90fiaergikg-i  2390ruj3490uj890gu890gu890gu90gui90gbui90gvuqef890u5tu90tufu890fuzsdf90rieg9054ut2=90uti590tit90vuid80fug0w49ugj3590gj3vcj34=0ru3490ui340uj80vjh489vjh50vu590fvuj5490vu50vu50u34901=cjmn v34h  4w3-eri  `4  =09W3RI34=95I92=T5I9 Q3459 ]FzsdFEDFAWERRF9054 =9T854890 T45TUTU245UTQ90WUFDFJG=034TYI82459YI88YI4905Y5UT5U54TUUAS FQ93FQ-WERT348T5=349T8RQ90 E4UMT23480TU Q384U5 01348U5 134895U 1=435U 348-5 U13458 134058U 1340=58 1349058 103485 90834905 8151349058 134=958 134=9058 134=958 1349058 1=4985 1=9034581=903458 9013458901 8345=91834 5901F90SDUI09WER8ER=9T8WER=-9T8WER9T8WER90T8W=90ERT8=WER9T8WE9R8T90WER8T90ER8T=W9E9RT8 M134805U 18345 1=94358 193485 134958 1490358 1349058 =34085 1903485 90AWE0RHWE WER  34T890FGT90  232389TRG3489VBUJHR489WGU8934U895U89FU890RTKWERJKOJKLERJIOERSJIOWERI0RG80WE5854UIODJIOEFAJIOJIOWEIOU80RRTG90JL43JKLDFKLDFSRIERIOIOEGIOGGTG89RTG89RTG89RTG89RTG8989RTG89RTG8989T789RT8989WER89WERTWERTGW54TY54Y90YR09TGI90W4TGUI9023UT945JTG8"
        self.DATA_6529 = self.DATA_6529 +  "AsDUIASDF89AERUFG890U0U QWET89U89T U3489UTU8 E90RGU890SERUG890SDFJV 090UI90DFGB890S=098U890DGU80U880U85U89UV89TVW79Y785VH578VH78FY578Y789Y78Y57Y789VY57895FY5789GY5789Y5789Y5789Y578Y378Y7Y785TY895Y5789Y5789Y5789Y59TU754 Q384QE8944TU7Q2=-8-0-8FD-GW8-ERTU789TU7895N 34 3478YR9- 134UY89-2USADUQ23[R5T-082340T8920 N34789TY 7945YT 7834YT 78934TU7892347T89T7GH8H880ERG5890GTG54U45G8945GU45G895UG895UYGGUYUYGQ2-2Q--9-8EDFYUQ7894FYU34789FUY34789FUY37894YFU78934FUY78934YF7834FY34789YF7834YR734YF78Q3Y4RF7831F09384FU3489FUY78934FUY SDIF 8R 789ASEFDYQ -R8 U134-8RU QORU891234RU-134589Q34793478RY34780RY3478FH34 34D1789 Y12379ERY 19034YR7934YR3478RY3478RY3478RY3478RYF3478FHUIFH 14789RY 78QW4YR 1342789RY 143Y7RY QW7903YER7 2Y134787813413478134780QF78FY7Y7ASE;KSDR;AW3topq34u-47r91348uy 789234ry A dq34-r7 q90348r 34789 134t78y3478rty1340t0q;awtpy-0tq-t134-tart]q34tu=t=54tg[h34f-4-13-4rfy4783y78fy78qwyer67dt b   23r 67234rg0 34yrq3489t7-t8-9erf7uqer89fgu3489tu73489qt 3478ry7834ry3478ry3478ry3478ry3478ry340r347ry3478ry3"
        self.DATA_6529 = self.DATA_6529 +  "asdfiosdfuwer890uf89  23ur    2389u   983ud89we d9    23e8923 r89q34ur=9034ufiovnlasdk fna'ASDCASKOFWEIOJ23489RU489   3U DQ89us 8UWD890   23UR=3409TIE GRTGJK[54GJK5490U5489U5T54YF78ERWHF78FH 7834HF7834YF7834YF-2R= 34RFNQE89FUER89-FU3489TYF54BHERYIFG7834RT-34789YRF-9ERFYAS7 FNA[-04TU54]=0U93T2489Y1T7934YQT78WECH dcNJQLRF7348CJQ78943R 81YRT789WT 341[-9E78FYH 9-QAHRF=-  1T4=5UYHW[THJ5454G9Q348Y784FYQER78FY7 Q-34R 8943 P8RTVJ L;34KQJTF8 NUG89UY 35T  A4EF9Y 54T9-YYQ[T8YDF 9G5 J4U6UOK7K78UOPTR054UT895TU A49TY Q34TY TY9- TU -W5TU 5T89U2-Q 34TW54UT -9E8TU 2-85UT-W95UT58 W49-TU 489-TJ54GJT558JW54GJ-W3TGU489FJ54TG54GW9P JTY-=W54T W=-5T4 =-W54T W54U W54TY9U W54UY 54U W8954U T-W95UYW-54YUW54UY W84Y4892-5UY W854UY W54U W54UTW89JKG WI[54Y IS09DTUI5689 Y03UW54 [W54Y [W54YJ UW54TY-U JW54Y89-W54 9W54T89U W54TUW89 T5U W89-TUW5 4T89U89-U R-98TGUW59 4G9SERUG W['TOP IW=456T2568 MWUT5YU8T8RHUY89-TJDTYJK-0SDTFUIG[AS 4 TAW34;T5OJ W-T5J 54TJ894JY5YJ8 DSRT3'5YJ56890UZ0RFGW98-RTUW54U T54UJ89UW54TW45TUW-45FYHJ]UYKIUYK-I9UY"
        if len(self.DATA_6529) != 6529:
            self.log(self.getline(), self.failed )
        self.data1_750 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHP"
        if len(self.data1_750) != 750:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()

        try:
            sslprivate = ssl.wrap_socket( privateSd, server_side = True, certfile=ServerCertificate, keyfile=ServerPrivateKey, ssl_version=ssl.PROTOCOL_TLSv1)
        except Exception, e:
            print e
            self.log(self.getline(), self.failed )

        ret = sslprivate.cipher()
        if ret != None:
            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
        else:
            self.log(self.getline(), self.failed )

        # now pc and sl are sync
        # send DATA_6529
        sslprivate.send( self.DATA_6529 )
        # expect back only 750 bytes
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != self.data1_750:
            sslprivate.close()
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        sslprivate.send( "*" )
        if sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL) != "*":
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        sslprivate.send( self.data_2 )

        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.sync3) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # Third test 2 buffer from differnet source port  < payload
        sslprivate.send(self.data_3_0 )
        sslprivate.send(self.data_3_1)



        # wait to end of test msg
        #sync again
        rdata = sslprivate.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        if rdata.find(self.endSyncMsg) == -1:
            sslprivate.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        sslprivate.close()
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(0) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECSNOVERIFY:
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        time.sleep(3)
        readData =""
        # READ DATA_6529
        # first test  max paylaod 750 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, 3500, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3500 or ret[2] != sd:
            print "ret[1] ", ret[1]
            print "sd ", ret[2]
            self.log(self.getline(), self.failed )
        readData = readData + ret[3]
        print "\n\nreadData ", len(readData)
        while( len(readData) < len(self.DATA_6529) ):
            ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            readData = readData + ret[3]
            print "\n\nreadData ", len(readData)
        # Compare data
        if readData != self.DATA_6529:
            self.log(self.getline(), self.failed )

        # send back only 750 bytes
        ret = self.slBsdHandle.Send( sd, 750, 0, self.data1_750 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len("*") or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != "*":
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # second test buuffer recive < payload read 3 iteration

        # read only 2 bytes
        ret = self.slBsdHandle.Recv( sd, 2, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 2 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[0:2]:
            self.log(self.getline(), self.failed )
        # read only 3 bytes
        ret = self.slBsdHandle.Recv( sd, 3, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[2:5]:
            self.log(self.getline(), self.failed )

        # read the exactly the rest
        ret = self.slBsdHandle.Recv( sd, len(self.data_2) - 5, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_2) - 5) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[5:]:
            self.log(self.getline(), self.failed )

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync3), 0, self.sync3)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # Third test 2 buffer from differnet source port  < payload 2 reads 3

        # first packet from pc mng prot

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_3_0) +  len(self.data_3_1 )) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != (self.data_3_0 + self.data_3_1):
            self.log(self.getline(), self.failed )



        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



class BsdTestAcceptWithWrongCAInClientSSL(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestAcceptWithWrongCAInClientSSL", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def verify_cb(inst,conn, cert, errnum,depth, ok):
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok

    def PC(self):
        self.log(self.getline(), self.start )
        time.sleep(6)

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(SSL.TLSv1_METHOD)
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ############################## wrong CA #######################################################
        ctx.load_verify_locations(ClientCertificate)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        try:
            s.connect((slConf.SL_IPV4, int(slConf.SL_PORT) + 5))
            s.do_handshake()

        except Exception, e:
            print e
        s.close()

        time.sleep(1)

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(SSL.TLSv1_METHOD)
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ctx.load_verify_locations(ServerCA)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        #s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.connect((slConf.SL_IPV4, int(slConf.SL_PORT) + 5))
        s.do_handshake()
        s.close()






        self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        time.sleep(3)
        self.slBsdHandle.clearEvents()
        # test async event
        i = 4
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]

        self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, str(int(slConf.SL_PORT) + 5))
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
             self.log(self.getline(), self.failed )

        val = self.slBsdHandle.Accept( sd, slConf.AF_INET )

        if( val[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpBlockingConnectCoverChiperSSLIPv6(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingConnectCoverChiperSSLIPv6", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.use_certificate_file(ServerCertificate)
        ctx.use_privatekey_file(ServerPrivateKey)
        ctx.load_tmp_dh(ServerDH)
        ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        s.bind((slConf.PC_IPV6, int(slConf.PC_PORT)))
        s.listen(4)
        privateSd = None
        try:
            privateSd, addr = s.accept()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        try:
            privateSd.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        #ret = privateSd.cipher()
        #print  "SSL connected " + TestCipher[i][4] + " " + TestCipher[i][5] + " " + TestCipher[i][6]
        #if ret[0] != TestCipher[i][4]:
        #    self.log(self.getline(), self.failed )
        #if ret[1] != TestCipher[i][5]:
        #    self.log(self.getline(), self.failed )
        #if ret[2] != TestCipher[i][6]:
        #    self.log(self.getline(), self.failed )

        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV6_TCP_SSL)
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )

        privateSd.send( rdata )
        privateSd.close()
        s.close()



    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "connect_" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            #tmp = [os.getcwd()+ "\server.exe", "-d", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            tmp = [os.getcwd()+ "\server.exe", "-b", "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.PC_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            #os.spawnv( os.P_NOWAIT, 'C:\python27\python', ['server.exe', 'C:\python_bsd_test_ssl\MiddleSSL.py  -p 8000 -m 6000 -d 7000'])
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

        pass


    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )

    def SL(self):
        self.log(self.getline(), self.start )
        #time.sleep(10)  # first time in order to sync
        i = 0
        while i < len(TestCipher):
            time.sleep(3)
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_CLIENT_PRIVATE_KEY ) + ":" +  str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_CA_CERT) + ":" + str(0) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackUBYTE( ret[4] )
            if ret != int(TestCipher[i][1]):
                self.log(self.getline(), self.failed )



            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            ret = utils.unpackLONG( ret[4] )
            if ret != TestCipher[i][2]:
                self.log(self.getline(), self.failed )


            #try to connect to non exist server -
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET6, str(int(slConf.PC_PORT)), slConf.PC_IPV6 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == BsdUtils.BSD_ESECGENERAL:
                print "SECURE FAILURE !!!!"
                self.log(self.getline(), self.failed )
            if ret[1] != 0:
                self.log(self.getline(), self.failed )

            #connected send data on tcp socket+ wait to reply

            ret = self.slBsdHandle.Send( sd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV6_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                #print ret
                if sd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )

            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1
        self.log(self.getline(), self.success )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpBlockingAcceptCoverChiperSSLIPv6(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingAcceptCoverChiperSSLIPv6", slBsdHandle, fileHandle )
        self.ssldata = "testing ssl Cipher: "

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)
    def verify_cb(inst,conn, cert, errnum,depth, ok):
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok


    def run_python(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        s.bind( (slConf.PC_IPV6, 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)

        ############################## init Open SSL ##################################################
        ctx = SSL.Context(TestCipher[i][3])
        ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)
        ctx.use_privatekey_file (ClientKey)
        ctx.use_certificate_file(ClientCertificate)
        ctx.load_verify_locations(ServerCA)
        s = SSL.Connection(ctx, s)
        ###############################################################################################


        #s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        s.connect((slConf.SL_IPV6, int(slConf.SL_PORT)))
        #raw_input("Press To Connect")

        loop = 1
        while loop > 0:
            try:

                loop = 0
            except Exception, e:
                if loop > 50:
                    print e
                    self.log(self.getline(), self.failed )
                else:
                    loop = loop + 1
                    time.sleep(1)
        try:
            s.do_handshake()
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )
        print "lgkhsdlkgjlsdkjglsakgjalsdkgnlsadkgnlsdkgnalsdkgnasldkgnlasdkgnlasdkgnsldkgnlsdkgnsldkgnsldkgnsldkgn"
        rdata = s.recv(self.MAX_PAYLOAD_IPV4_TCP_SSL)
        print rdata
        print rdata
        print rdata
        print rdata
        print rdata
        print rdata
        if rdata != self.ssldata + TestCipher[i][0]:
            self.log(self.getline(), self.failed )
        s.send( rdata )
        s.close()


    def run_yassl(self, i):
        self.log(self.getline(), self.info, "RUN SSL->  " + TestCipher[i][7] )
        try:
            #subprocess.call( [os.getcwd()+ "\server.exe", "-d", "-b", "-f sss.txt" , "-v 1", "-p 5001" , "-lDHE-RSA-AES256-SHA" ])

            resultfile = "accept" +  str(i) + "_" + TestCipher[i][4] + ".txt"
            tmp = [os.getcwd()+ "\client.exe", "-h" + slConf.SL_IPV4, "-f"+ resultfile, "-v " + TestCipher[i][1], "-p " + str(int(slConf.SL_PORT) + i) , "-l" + TestCipher[i][4] ]
            print tmp
            if os.path.isfile(SYNCFILE):
               os.remove(SYNCFILE)
            print os.getcwd()
            print "subprocess.call"
            subprocess.call(tmp)
            loop = 0
            while loop < 20:
                loop = loop + 1
                time.sleep(0.5)
                if os.path.isfile(SYNCFILE):
                    loop = 500
            if loop != 500:
                self.log(self.getline(), self.failed )

            readFile = open( os.getcwd()+ "\\" + resultfile ,'r')
            testResult = False
            cmpZ = "Client message: " + self.ssldata + TestCipher[i][0] + "\n"
            for z in readFile:
                if z == cmpZ:
                    print "found message !!!!"
                    print z
                    testResult = True
            readFile.close()
            if testResult == False:
                self.log(self.getline(), self.failed )

            # now parse results
        except Exception, e:
            print e
            self.log(self.getline(), self.failed, e )

    def PC(self):
            i = 0
            self.log(self.getline(), self.start )
            while i < len(TestCipher):
                print "Test Cipher: ", str(i), " ",  TestCipher[i]
                time.sleep(5)
                self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] + " -> " + TestCipher[i][7])
                if TestCipher[i][7] == "PYTHON" :
                    self.run_python(i)
                elif TestCipher[i][7] == "YASSL" :
                    self.run_yassl(i)
                else:
                    self.log(self.getline(), self.failed )
                self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
                i = i + 1
            self.log(self.getline(), self.success )


    def SL(self):
        self.log(self.getline(), self.start )
        i = 0
        while i < len(TestCipher):
            print "Test Cipher: ", str(i), " ",  TestCipher[i]
            self.log(self.getline(), self.info, "Start-> " + TestCipher[i][0] )
            self.slBsdHandle.clearEvents()

            ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, BsdUtils.SL_SECURITY_ANY )
            if( ret[0] == False ):
                     self.log(self.getline(), self.failed )
            sd = ret[1]
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_FILES, 4, str(SLINK_FILE_PRIVATE_KEY) + ":" +  str(SLINK_FILE_SERVER_CERT) + ":" + str(SLINK_FILE_CLIENT_CERT) + ":" + str(SLINK_FILE_DH_SERVER) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECMETHOD, 1, TestCipher[i][1] )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_SECURE_MASK, 4, utils.convert_to_propriety_long(TestCipher[i][2]) ) # sec , micro sec
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


            ret = self.slBsdHandle.Bind( sd, slConf.AF_INET6, str(int(slConf.SL_PORT)))
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

            ret = self.slBsdHandle.Listen( sd, 2 )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            ret = self.slBsdHandle.Accept( sd, slConf.AF_INET6 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            else:
                privateSd = ret[1]
                if False == self.checkSocketRange( privateSd ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] == BsdUtils.BSD_ESECGENERAL:
                    print "SECURE FAILURE !!!!"
                    self.log(self.getline(), self.failed )
                if ret[3] != slConf.AF_INET6:
                    self.log(self.getline(), self.failed )
                if ret[5] != slConf.PC_IPV6:
                    self.log(self.getline(), self.failed )



            #connected send data on tcp socket+ wait to reply

            ret = self.slBsdHandle.Send( privateSd, len(self.ssldata + TestCipher[i][0]), 0, self.ssldata + TestCipher[i][0] )
            print len(self.ssldata + TestCipher[i][0])
            print self.ssldata + TestCipher[i][0]
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP_SSL, 0 )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed  )
            else:
                if privateSd == ret[2] and len(self.ssldata + TestCipher[i][0]) == ret[1] and self.ssldata + TestCipher[i][0] == ret[3]:
                    pass
                else:
                    self.log(self.getline(),self.failed  )
            #close sockets
            ret = self.slBsdHandle.Close( privateSd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            ret = self.slBsdHandle.Close( sd )
            if( ret[0] == False ):
                self.log(self.getline(),self.failed, str(sd) )
            self.log(self.getline(), self.info, "End-> " + TestCipher[i][0] )
            i = i + 1

        self.log(self.getline(), self.success )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


