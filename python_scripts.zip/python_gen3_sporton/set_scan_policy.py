
import sys
import time
import TICore
import configurations as conf
import string
import options

ENABLE_SCAN  = 1
DISABLE_SCAN = 0

def POLICYSETCOMMAND(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    print "*********************************************\n"
    core.InvokeSLCommand("WLAN", "SETCONNPOL",1000,0x20, 0, DISABLE_SCAN, 4,"00:03:00:00")

    time.sleep(1)
    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    POLICYSETCOMMAND(Opts)