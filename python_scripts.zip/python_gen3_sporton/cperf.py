import Queue
import time
import sys
import argparse
import time
import TICore
import configurations as conf
import math
import string
import options
import utils
import BsdUtils
import datetime
import select
import socket
import struct
import ssl
import os
from OpenSSL import SSL

TRACE_LEVEL_ERROR = 1
TRACE_LEVEL_ACTIVITY = 2
TRACE_LEVEL_INFO = 3
TRACE_LEVEL_DEBUG = 4


version = 'CPREF - SimpleLink Communication Test Utility - Version 1.0.0.4';


TEST_TYPE_UDP_TX				= 0
TEST_TYPE_UDP_RX				= 1
TEST_TYPE_TCP_TX				= 2
TEST_TYPE_TCP_RX				= 3
TEST_TYPE_TCP_SERVER_BI_DIR		= 4
TEST_TYPE_TCP_CLIENT_BI_DIR		= 5
TEST_TYPE_UDP_BI_DIR			= 6
TEST_TYPE_RAW_TX                     = 7
TEST_TYPE_RAW_RX                     = 8
TEST_TYPE_RAW_BI_DIR                 = 9
TEST_TYPE_SECURED_TCP_TX             = 10
TEST_TYPE_SECURED_TCP_RX             = 11
TEST_TYPE_SECURED_TCP_SERVER_BI_DIR  = 12
TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR  = 13
TEST_TYPE_UDP_TX_IPV6				 = 14
TEST_TYPE_UDP_RX_IPV6				 = 15
TEST_TYPE_TCP_TX_IPV6				 = 16
TEST_TYPE_TCP_RX_IPV6				 = 17
TEST_TYPE_TCP_SERVER_BI_DIR_IPV6	 = 18
TEST_TYPE_TCP_CLIENT_BI_DIR_IPV6	 = 19
TEST_TYPE_UDP_BI_DIR_IPV6			 = 20
TEST_TYPE_RAW_TX_IPV6                     = 21
TEST_TYPE_RAW_RX_IPV6                     = 22
TEST_TYPE_RAW_BI_DIR_IPV6                 = 23
TEST_TYPE_SECURED_TCP_TX_IPV6             = 24
TEST_TYPE_SECURED_TCP_RX_IPV6             = 25
TEST_TYPE_SECURED_TCP_SERVER_BI_DIR_IPV6  = 26
TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR_IPV6  = 27
TEST_TYPE_TRANSCEIVER_TX                  = 28
TEST_TYPE_TRANSCEIVER_RX                  = 29

CIPHERS = ['RC4-SHA','ECDHE-RSA-RC4-SHA','ECDHE-RSA-AES256-SHA','DHE-RSA-AES256-SHA','AES256-SHA','RC4-MD5']
#CIPHERS = 'RC4-SHA,ECDHE-RSA-RC4-SHA,ECDHE-RSA-AES256-SHA,DHE-RSA-AES256-SHA,AES256-SHA,RC4-MD5'
METHODS = [SSL.SSLv3_METHOD,SSL.TLSv1_METHOD,SSL.SSLv23_METHOD]

CipherCombinations = [11,16,21,22,23,24,25,26,31,32,33,34,35,36]


KILO = 1000

TEST_TYPE_NAME = [ "UDP_TX", "UDP_RX", "TCP_TX", "TCP_RX", "TCP_SERVER_BI_DIR", "TCP_CLIENT_BI_DIR", "UDP_BI_DIR", "RAW_TX", "RAW_RX", "RAW_BI_DIR", "SECURED_TCP_TX", "SECURED_TCP_RX", "SECURED_TCP_SERVER_BI_DIR", "SECURED_TCP_CLIENT_BI_DIR" ,  "UDP_TX_IPV6", "UDP_RX_IPV6", "TCP_TX_IPV6", "TCP_RX_IPV6", "TCP_SERVER_BI_DIR_IPV6", "TCP_CLIENT_BI_DIR_IPV6", "UDP_BI_DIR_IPV6", "RAW_TX_IPV6", "RAW_RX_IPV6", "RAW_BI_DIR_IPV6", "SECURED_TCP_TX_IPV6", "SECURED_TCP_RX_IPV6", "SECURED_TCP_SERVER_BI_DIR_IPV6", "SECURED_TCP_CLIENT_BI_DIR_IPV6" , "TRANSCEIVER_TX", "TRANSCEIVER_RX"]

TEST_TYPE_UNKONWEN              = 9999

BIND_IP = ""
CONNECT_IP = ""

#----------------------------------------    SSL    ------------------------------------------------------------

TestCipher = [  # test name | SL method | SL Cipher | Python metod | Python Cipher set + get, | Python method get | python key lenggh get | run python or yassl \
                [  "NONE",  0, 0, 0, "NONE", "NONE", 0 ],  # MANDATORY - pass\
                [  "ANY",  0, 0, 0, "NONE", "NONE", 0 ],  # MANDATORY - pass\
                [  "SSLv3 RSA_WITH_RC4_128_SHA",  BsdUtils.SO_SECMETHOD_SSLV3, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA, ssl.PROTOCOL_SSLv3, "RC4-SHA", "TLSv1/SSLv3", 128 ],  # MANDATORY - pass\
                [  "TLSv1 RSA_WITH_RC4_128_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA, ssl.PROTOCOL_TLSv1, "RC4-SHA", "TLSv1/SSLv3", 128 ],  # MANDATORY - pass\
                [  "SSLv3 RSA_WITH_RC4_128_MD5",  BsdUtils.SO_SECMETHOD_SSLV3, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5, ssl.PROTOCOL_SSLv3, "RC4-MD5", "TLSv1/SSLv3", 128 ],  # Nice to Have - pass\
                [  "TLSv1 RSA_WITH_RC4_128_MD5",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5, ssl.PROTOCOL_TLSv1, "RC4-MD5", "TLSv1/SSLv3", 128 ],  # Nice to Have - pass\
                [  "TLSv1 RSA_WITH_AES_256_CBC_SHA",  BsdUtils.SO_SECMETHOD_TLSV1, BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA, ssl.PROTOCOL_TLSv1, "AES256-SHA", "TLSv1/SSLv3", 256 ]  # Nice to Have - pass\
              ]

ServerCertificate = os.getcwd() + "\cert\server-cert.pem"
ServerPrivateKey  = os.getcwd() + "\cert\server-key.pem"
ServerCA          = os.getcwd() + "\cert\ca-cert.pem"
ClientKey          = os.getcwd() + "\cert\client-key.pem"
ClientCertificate   = os.getcwd() + "\cert\client-cert.pem"
ServerDH            =  os.getcwd() + "\cert\dh2048.pem"
ClientCA            = ClientCertificate

SLINK_FILE_PRIVATE_KEY =  97   # 151 cert\server-key.der  1400 bytes
SLINK_FILE_SERVER_CERT =  98   # 152 cert\server-cert.der 1024 bytes
SLINK_FILE_CA_CERT    =   99   # 153 cert\ca-cert.der      1300 bytes

SLINK_FILE_CLIENT_CERT =          90 # 144 cer\client_cert.der   1400 bytes
SLINK_FILE_CLIENT_PRIVATE_KEY =   91 # 145 cer\client_key.der  1700 bytes
SLINK_FILE_DH_SERVER   =          92 # 146 cer\dh2048.der     800 bytes

#----------------------------------------    END    ------------------------------------------------------------



class cperf_t:
    def __init__(self , trace_level = TRACE_LEVEL_ACTIVITY):
        print "\n"+version+"\n"
        self.logoutOnce = False
        self.g_TraceLevel = trace_level
        self.g_Parser = argparse.ArgumentParser(description=version)

        self.g_Parser.add_argument('-u', dest='udp'            , action='store_true'    , help='Use UDP rather than TCP')
        self.g_Parser.add_argument('-s', dest='server'         , action='store_true'    , help='Run in a server mode')
        self.g_Parser.add_argument('-x', dest='dualtest'       , action='store_true'    , help='Do a bidirectional test simultaneously')
        self.g_Parser.add_argument('-d', dest='comm'                                    , help='serial port or 1000 - internal socket ')
        self.g_Parser.add_argument('-p', dest='port'                                    , help='Server port to listen / Client port to connect')
        self.g_Parser.add_argument('-c', dest='client'                                  , help='Run in a client mode, connect to <host>')
        self.g_Parser.add_argument('-a', dest='abort_all'      , action='store_true'    , help='Abort all running tests')
        self.g_Parser.add_argument('-l', dest='length'                                  , help='Length of the buffer to read or write')
        self.g_Parser.add_argument('-b', dest='throughput'                              , help='The target write throughput in bits/sec')
        self.g_Parser.add_argument('-PC', dest='pc_side'       , action='store_true'    , help='Run in PC side')
        self.g_Parser.add_argument('-V', dest='ipv6_mode'      , action='store_true'    , help='IPv6 ')
        self.g_Parser.add_argument('-i', dest='seconds'                                 , help='Seconds between periodic bandwidth reports')
        self.g_Parser.add_argument('-t', dest='time'                                    , help='time in seconds to transmit for (default 10 secs')
        self.g_Parser.add_argument('-B', dest='bind'                                    , help='bind multicast address')
        self.g_Parser.add_argument('-g', dest='CheckSum'                                 , help='enable checksum')
        self.g_Parser.add_argument('-e', dest='security'                                 , help='Securitiy method and cipher - Methods are: 10 - SSLv3 ||| 20 - TLSv1 ||| 30 - TLSv1.1 and TLSv1.2. Plus Cipher 1 - SSL_RSA_WITH_RC4_128_SHA1 ||| 2 - TLS_ECDHE_RSA_WITH_RC4_128_SHA1 ||| 3 - TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA1 ||| 4 - TLS_DHE_RSA_WITH_AES_256_CBC_SHA1 ||| 5 - TLS_RSA_WITH_AES_256_CBC_SHA1 ||| 6 - SSL_RSA_WITH_RC4_128_MD5'  )
        self.g_Parser.add_argument('-r', dest='rawProtocol'                              , help='raw protocol'  )
        self.g_Parser.add_argument('-w', dest='window'                                   , help='not used ')
        self.g_Parser.add_argument('-f', dest='format'                                   , help='not used ')
        self.g_Parser.add_argument('-T', dest='transceiver'    , action='store_true'     , help='transceiver mode'  )

        self.g_Args = self.g_Parser.parse_args()

        self.g_DefaultPort = 5001
        self.g_DefaultLength = 1460
        self.g_DefaultThroughput = 0 # maximum
        self.g_SendToAddr = None
        self.g_OldSd        = None
        self.g_Sd           = None
        self.g_DestAddr   = None
        self.g_rid = 0
        self.g_tid = 0
        self.g_prevRid = -1
        self.g_DeltaUdpRx = 1000

        self.g_time_stamp_1 = float(0.0)
        self.g_time_stamp_2 = float(0.0)
        self.g_time_tp_1 = float(0.0)
        self.g_time_tp_2 = float(0.0)
        # client statistices
        self.g_c_numBytes = float(0.0)
        self.g_c_AveNumBytes = float(0.0)
        # server statistices
        self.g_s_numBytes = float(0.0)
        self.g_s_AveNumBytes = float(0.0)
        self.g_stat_cntr = float(0.0)
        self._g_startStat = 0
        self._g_time = 0
        self.g_multicastRxEnabled = False
        self.g_csEnable = 0
        self.g_security = 0
        self.sslprivate = None
        self.OutOforderPackets = 0
        self.missedPackets     = 0
        self.connectedTest     = False
        self.doTx              = False
        self.doRx              = False
        self.comm = None
        self.g_protocol = 0
        self.g_rawRxOffset = 0
        self.g_ipVersion =  4

    def _trace_msg(self, level = TRACE_LEVEL_DEBUG , str = ""):
        if (level <= self.g_TraceLevel):
            print str

    def _find_test_type(self):
        self.g_DefaultPort = 5001
        self.g_TestType = TEST_TYPE_UNKONWEN
        if ((self.g_Args.client != None) and (not self.g_Args.server)):
            # time out on client case
            if (self.g_Args.time != None):
                self._g_time = int(self.g_Args.time)
            else:
                self._g_time = 0


            # client
            if (self.g_Args.rawProtocol):
                self.g_protocol = int(self.g_Args.rawProtocol )
                if (4 == self.g_ipVersion):
                     if (not self.g_Args.dualtest):
                        self.g_TestType = TEST_TYPE_RAW_TX
                        self.g_DefaultLength = 1472
                     else:
                        self.g_TestType = TEST_TYPE_RAW_BI_DIR
                        self.g_DefaultLength = 1472
                        self.g_rawRxOffset = 20
                else:
                     if (not self.g_Args.dualtest):
                        self.g_TestType = TEST_TYPE_RAW_TX_IPV6
                        self.g_DefaultLength = 1452
                     else:
                        self.g_TestType = TEST_TYPE_RAW_BI_DIR_IPV6
                        self.g_DefaultLength = 1452
                        self.g_rawRxOffset = 40

            elif (self.g_Args.udp):
                # udp tx
                # ------
                if (4 == self.g_ipVersion):
                     if (not self.g_Args.dualtest):
                        self.g_TestType = TEST_TYPE_UDP_TX
                        self.g_DefaultLength = 1470
                     else:
                        self.g_TestType = TEST_TYPE_UDP_BI_DIR
                        self.g_DefaultLength = 1470
                else:
                     if (not self.g_Args.dualtest):
                        self.g_TestType = TEST_TYPE_UDP_TX_IPV6
                        self.g_DefaultLength = 1450
                     else:
                        self.g_TestType = TEST_TYPE_UDP_BI_DIR_IPV6
                        self.g_DefaultLength = 1450
            elif (self.g_Args.transceiver):
            #transceiver mode tx
            #----------------
                self.g_TestType = TEST_TYPE_TRANSCEIVER_TX
                self.g_DefaultPort = 5001
                self.g_DefaultLength = 1470
            
            else:
                # tcp tx
                # ------
                if( 4 == self.g_ipVersion ):
                     if (not self.g_Args.dualtest):
                        if( self.g_security ):
                            self.g_TestType = TEST_TYPE_SECURED_TCP_TX
                            self.g_DefaultLength = 1402
                        else:
                            self.g_TestType = TEST_TYPE_TCP_TX
                            self.g_DefaultLength = 1460
                     else:
                        if( self.g_security ):
                            self.g_TestType = TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR
                            self.g_DefaultLength = 1402
                        else:
                            self.g_TestType = TEST_TYPE_TCP_CLIENT_BI_DIR
                            self.g_DefaultLength = 1460
                else:
                     if (not self.g_Args.dualtest):
                        if( self.g_security ):
                            self.g_TestType = TEST_TYPE_SECURED_TCP_TX_IPV6
                            self.g_DefaultLength = 1382
                        else:
                            self.g_TestType = TEST_TYPE_TCP_TX_IPV6
                            self.g_DefaultLength = 1440
                     else:
                        if( self.g_security ):
                            self.g_TestType = TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR_IPV6
                            self.g_DefaultLength = 1382
                        else:
                            self.g_TestType = TEST_TYPE_TCP_CLIENT_BI_DIR_IPV6
                            self.g_DefaultLength = 1440

        else:
            if ((self.g_Args.client == None) and (self.g_Args.server)):
                if (self.g_Args.rawProtocol):
                    self.g_protocol = int(self.g_Args.rawProtocol )
                    if (4 == self.g_ipVersion):
                        self.g_TestType = TEST_TYPE_RAW_RX
                        self.g_DefaultLength = 1472
                        self.g_rawRxOffset = 20
                    else:
                        self.g_TestType = TEST_TYPE_RAW_RX_IPV6
                        self.g_DefaultLength = 1452
                        self.g_rawRxOffset = 40
                elif (self.g_Args.udp):
                    # udp rx
                    # ------
                    if( 4 == self.g_ipVersion):
                         if (not self.g_Args.dualtest):
                            self.g_TestType = TEST_TYPE_UDP_RX
                            self.g_DefaultPort = 5001
                            self.g_DefaultLength = 1470
                    else:
                        if (not self.g_Args.dualtest):
                            self.g_TestType = TEST_TYPE_UDP_RX_IPV6
                            self.g_DefaultPort = 5001
                            self.g_DefaultLength = 1450
                            
                elif (self.g_Args.transceiver):
                    # transceiver rx
                    self.g_TestType = TEST_TYPE_TRANSCEIVER_RX
                    self.g_DefaultPort = 5001
                    self.g_DefaultLength = 1470
                else:
                    # tcp rx
                    # ------
                    if( 4 == self.g_ipVersion ):
                         if (not self.g_Args.dualtest):
                               if( self.g_security ):
                                    self.g_TestType = TEST_TYPE_SECURED_TCP_RX
                                    self.g_DefaultLength = 1402
                               else:
                                    self.g_TestType = TEST_TYPE_TCP_RX
                                    self.g_DefaultLength = 1460
                         else:
                               if( self.g_security ):
                                    self.g_TestType = TEST_TYPE_SECURED_TCP_SERVER_BI_DIR
                                    self.g_DefaultLength = 1402
                               else:
                                    self.g_TestType = TEST_TYPE_TCP_SERVER_BI_DIR
                                    self.g_DefaultLength = 1460
                    else:
                         if (not self.g_Args.dualtest):
                               if( self.g_security ):
                                    self.g_TestType = TEST_TYPE_SECURED_TCP_RX_IPV6
                                    self.g_DefaultLength = 1382
                               else:
                                    self.g_TestType = TEST_TYPE_TCP_RX_IPV6
                                    self.g_DefaultLength = 1440
                         else:
                               if( self.g_security ):
                                    self.g_TestType = TEST_TYPE_SECURED_TCP_SERVER_BI_DIR_IPV6
                                    self.g_DefaultLength = 1382
                               else:
                                    self.g_TestType = TEST_TYPE_TCP_SERVER_BI_DIR_IPV6
                                    self.g_DefaultLength = 1440

    def _parse_parameters(self):
        self.g_Port = self.g_DefaultPort
        if (self.g_Args.port != None):
            self.g_Port = int(self.g_Args.port)

        if (self.g_Args.CheckSum != None):
            self.g_csEnable = int(self.g_Args.CheckSum)
        self.g_PacketLen = self.g_DefaultLength
        if (self.g_Args.length != None):
            self.g_PacketLen = int(self.g_Args.length)
        if self.connectedTest:
            self.g_Throughput = self.g_DefaultThroughput
        else:
            self.g_Throughput = 1000
        if (self.g_Args.throughput != None):
            self.g_Throughput = self._convertThroughputString(self.g_Args.throughput)

        self.g_DstIP0      =  0
        self.g_DstIP1      =  0
        self.g_DstIP2      =  0
        self.g_DstIP3      =  0
        if( 6 == self.g_ipVersion ):
            if (self.g_Args.client != None ):
                if self.g_Args.pc_side:
                    self.g_DstIP0    =  self.g_Args.client
                else:
                    self.g_DstIP0      =  utils.ipv6GetUlong(self.g_Args.client, 0)
                    self.g_DstIP1      =  utils.ipv6GetUlong(self.g_Args.client, 1)
                    self.g_DstIP2      =  utils.ipv6GetUlong(self.g_Args.client, 2)
                    self.g_DstIP3      =  utils.ipv6GetUlong(self.g_Args.client, 3)

            if (self.g_Args.bind != None ):
                if self.g_Args.pc_side:
                    self.g_DstIP0    =  self.g_Args.bind
                else:
                    self.g_DstIP0      =  utils.ipv6GetUlong(self.g_Args.bind, 0)
                    self.g_DstIP1      =  utils.ipv6GetUlong(self.g_Args.bind, 1)
                    self.g_DstIP2      =  utils.ipv6GetUlong(self.g_Args.bind, 2)
                    self.g_DstIP3      =  utils.ipv6GetUlong(self.g_Args.bind, 3)
        else:    #  IPv4
            if (self.g_Args.client != None ):
                if self.g_Args.pc_side:
                    self.g_DstIP0    =  self.g_Args.client
                else:
                    self.g_DstIP0    =  utils.getIpHexNum(self.g_Args.client)

            if (self.g_Args.bind != None ):
                if self.g_Args.pc_side:
                    self.g_DstIP0    =  self.g_Args.bind
                else:
                    self.g_DstIP0    =  utils.getIpHexNum(self.g_Args.bind)


    def _stop_active_ctst(self):
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"Abort all tests");

        core = TICore.TICore()
        core.initialize1(self.comm)
        core.InvokeSLCommand("WLAN", "CTST_STOP"       ,2)
        x = 0
        for x in range(8):
            self.waitTestEvent( core, 400 );

        core.close()
        sys.exit("=> stop ctst")

    def _convertThroughputChar(self,ch):
        return {
            '1': 1,
            '2': 2,
            '3': 3,
            '4': 4,
            '5': 5,
            '6': 6,
            '7': 7,
            '8': 8,
            '9': 9,
            '0': 0,
            'k': 1024,
            'K': 1024,
            'M': 1024*1024,
            'm': 1024*1024,
            }.get(ch, 0)    # 9 is default if x not found

    def _convertThroughputString(self,throughput):
        output = 0
        for ch in self.g_Args.throughput:
            temp = self._convertThroughputChar(ch)
            if (temp < 10):
                output *= 10
                output += temp
            else:
                output *= temp
        # output should be in KB units
        if output > 0:
            output = output/KILO
            if output == 0:
                output = 1 # if after the div it is 0 we need to set it to 1, otherwise the device will send maximum throughput
        return output


    def _start_ctst(self):
        DstPort     =  self.g_Port
        SrcPort     =  self.g_Port
        PayloadThroughputVal =  (self.g_PacketLen & 0xffff) | (self.g_Throughput << 16)
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"#########################################")
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"\tSL Start new test " + TEST_TYPE_NAME[self.g_TestType])
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"#########################################")
        self._trace_msg(TRACE_LEVEL_INFO,"port: "+           str(self.g_Port))
        self._trace_msg(TRACE_LEVEL_INFO,"length: "+         str(self.g_PacketLen))
        self._trace_msg(TRACE_LEVEL_INFO,"throughput[KB]: "+  str(self.g_Throughput))
      #  self._trace_msg(TRACE_LEVEL_INFO,"IP[0]: "+     str(self.g_DstIP0))
      #  self._trace_msg(TRACE_LEVEL_INFO,"IP[1]: "+     str(self.g_DstIP1))
      #  self._trace_msg(TRACE_LEVEL_INFO,"IP[2]: "+     str(self.g_DstIP2))
      #  self._trace_msg(TRACE_LEVEL_INFO,"IP[3]: "+     str(self.g_DstIP3))

        testType = self.g_TestType

        SECURE_METHOD = BsdUtils.SO_SECMETHOD_SSLV3
        #SECURE_METHOD = BsdUtils.SO_SECMETHOD_TLSV1

        #SECURE_MASK = BsdUtils.SECURE_MASK_TLS_ECDHE_RSA_WITH_RC4_128_SHA
        #SECURE_MASK = BsdUtils.SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA
        #SECURE_MASK = BsdUtils.SECURE_MASK_TLS_DHE_RSA_WITH_AES_256_CBC_SHA
        SECURE_MASK = BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5
        #SECURE_MASK = BsdUtils.SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA
        #SECURE_MASK = BsdUtils.SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA

        PRIVATE_KEY_IDX = 145
        CERT_IDX = 144
        #CA_IDX = 153
        CA_IDX = 0 #set to zero if server and no client cert check wanted
        DH_IDX = 0


        core = TICore.TICore()
        core.initialize1(self.comm)
        core.InvokeSLCommand("WLAN", "CTST_START"       ,2, testType, DstPort, SrcPort, self.g_DstIP0, self.g_DstIP1, self.g_DstIP2, self.g_DstIP3, PayloadThroughputVal, self._g_time, self.g_csEnable, str(self.g_security), str(self.g_protocol), 0, 0, 0, 0 )
        #do not wait for <esc>, use comm_test_stop.py to stop all comm_tests
        #utils.waitForEscKeypress()
        time.sleep(2)
        while 1:
            self.waitTestEvent( core, 0xFFFFFFFF );
        core.close()


    def waitTestEvent(self, core , timeOut ):
        val = core.waitEvent("CTST_REPORT_Async_Event", [], timeOut )
        if  val[0] == True:
            print("ReportEvent: ")
            ret = ( True, (val[1])[4], (val[1])[7], (val[1])[8] )
            print ( TEST_TYPE_NAME[(val[1])[4]]  + " Socket {0} Time {1}-{2} sec, txKbitSec {3} rxKbitSec {4} OutOfOrderPackets {6} missedPackets {6} ".format((val[1])[5], (val[1])[7],(val[1])[8], (val[1])[9],(val[1])[10], (val[1])[11] , (val[1])[12] ))
        else:
            ret = ( False, -1, -1 )
            print("ReportEvent: ")
            print(ret)
        return ret


    def execute(self):
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"\nExecute CPERF Test\n");
        self._trace_msg(TRACE_LEVEL_INFO,"UDP: "+            str(self.g_Args.udp))
        self._trace_msg(TRACE_LEVEL_INFO,"SERVER: "+         str(self.g_Args.server))
        self._trace_msg(TRACE_LEVEL_INFO,"BIDIRECTIONAL: " + str(self.g_Args.dualtest))
        self._trace_msg(TRACE_LEVEL_INFO,"PORT: "+           str(self.g_Args.port))
        self._trace_msg(TRACE_LEVEL_INFO,"CLIENT: "+         str(self.g_Args.client))
        self._trace_msg(TRACE_LEVEL_INFO,"ABORT ALL: "+      str(self.g_Args.abort_all))
        self._trace_msg(TRACE_LEVEL_INFO,"LENGTH: "+         str(self.g_Args.length))
        self._trace_msg(TRACE_LEVEL_INFO,"THROUGHPUT: "+     str(self.g_Args.throughput))
        self._trace_msg(TRACE_LEVEL_INFO,"PC SIDE: "+        str(self.g_Args.pc_side))
        self._trace_msg(TRACE_LEVEL_INFO,"IPv6: "+           str(self.g_Args.ipv6_mode))
        self._trace_msg(TRACE_LEVEL_INFO,"TIME: "+           str(self.g_Args.time))
        self._trace_msg(TRACE_LEVEL_INFO,"BIND: "+           str(self.g_Args.bind))


        if (self.g_Args.comm):
            self.comm = int(self.g_Args.comm)
        else:
            Opts = options.TIOptions('')
            self.comm = int(Opts.GetVal('SerialPort'))

        if self.comm == 1000:
            print "comm internal socket"
        else:
            print "comm ", self.comm
        if (self.g_Args.abort_all):
            self._stop_active_ctst()

        if (self.g_Args.security != None):
            self.g_security = int(self.g_Args.security)
            notFound = 0
            for i in CipherCombinations:
                if i == self.g_security:
                    notFound = 1
            if ( notFound == 0 and self.g_Args.pc_side ):
                print "INVALID SECURITY PARAM"
                self._LogOut()
                sys.exit()
            print  "SECURITY: "

        if (self.g_Args.ipv6_mode ):
            self.g_ipVersion =  6

        self._find_test_type()
        self.connectedTest  = self._need_to_accept()
        if( self.connectedTest == False ):
            self.connectedTest  = self._need_to_connect()

        self._parse_parameters()


        if not self.g_Args.server:
            self.doTx =True
        if self.g_Args.dualtest:
            self.doTx = True

        if self.g_Args.server:
            self.doRx = True
        if self.g_Args.dualtest:
            self.doRx = True


        if self.g_TestType == TEST_TYPE_UNKONWEN:
            pass
        elif self.g_Args.pc_side:
            self._run_pc_test()
        else:
            self._start_ctst()

    # **************************** pc tool ****************************

    def _get_sock_type(self):
        if self.g_Args.rawProtocol:
            return socket.SOCK_RAW
        elif (self.g_Args.udp):
            return socket.SOCK_DGRAM
        else:
            return socket.SOCK_STREAM
    def _get_sock_family(self):
        if self.g_ipVersion ==  4:
            return socket.AF_INET
        else:
            return socket.AF_INET6

    def _prepare_tx_data(self):
        idVal = struct.pack( ">lll" , self.g_tid , 1 , 2 )
        #print idVal
        data = idVal[0] + idVal[1] + idVal[2]
        i = len(data)
        while( i < self.g_PacketLen ):
            i = i + 1
            data += str(i%10)
        self.g_tid += 1
        return data

    def _sendDisconnectConnectionlLess(self):
        if self.connectedTest == True and self.doTx:
            return
        idVal = struct.pack( ">lll" , -self.g_tid , 1 , 2 )
        data = idVal[0] + idVal[1] + idVal[2]
        i = len(data)
        while( i < self.g_PacketLen ):
            i = i + 1
            data += str(i%10)
        for i  in range(5):
            time.sleep(0.1)
            self._Tx( data )


    def _need_to_bind(self):
        if self.g_TestType == TEST_TYPE_UDP_RX or self.g_TestType == TEST_TYPE_TCP_RX or self.g_TestType == TEST_TYPE_TCP_SERVER_BI_DIR or self.g_TestType == TEST_TYPE_SECURED_TCP_RX or self.g_TestType == TEST_TYPE_SECURED_TCP_SERVER_BI_DIR:
            return True
        if self.g_TestType == TEST_TYPE_UDP_BI_DIR:
            return True
        if  self.g_TestType == TEST_TYPE_RAW_RX or self.g_TestType == TEST_TYPE_RAW_BI_DIR:
            self.g_Port = 0
            return True

        if self.g_TestType == TEST_TYPE_UDP_RX_IPV6 or self.g_TestType == TEST_TYPE_TCP_RX_IPV6 or self.g_TestType == TEST_TYPE_TCP_SERVER_BI_DIR_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_RX_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_SERVER_BI_DIR_IPV6:
            return True
        if self.g_TestType == TEST_TYPE_UDP_BI_DIR_IPV6:
            return True
        if  self.g_TestType == TEST_TYPE_RAW_RX_IPV6 or self.g_TestType == TEST_TYPE_RAW_BI_DIR_IPV6:
            self.g_Port = 0
            return True
        return False

    def _need_to_accept(self):
        if self.g_TestType == TEST_TYPE_TCP_RX or self.g_TestType == TEST_TYPE_TCP_SERVER_BI_DIR or self.g_TestType == TEST_TYPE_SECURED_TCP_RX or self.g_TestType == TEST_TYPE_SECURED_TCP_SERVER_BI_DIR:
            return True

        if self.g_TestType == TEST_TYPE_TCP_RX_IPV6 or self.g_TestType == TEST_TYPE_TCP_SERVER_BI_DIR_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_RX_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_SERVER_BI_DIR_IPV6:
            return True

        return False

    def _need_to_connect(self):
        if self.g_TestType == TEST_TYPE_TCP_TX or self.g_TestType == TEST_TYPE_TCP_CLIENT_BI_DIR or self.g_TestType == TEST_TYPE_SECURED_TCP_TX or self.g_TestType == TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR:
            return True

        if self.g_TestType == TEST_TYPE_TCP_TX_IPV6 or self.g_TestType == TEST_TYPE_TCP_CLIENT_BI_DIR_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_TX_IPV6 or self.g_TestType == TEST_TYPE_SECURED_TCP_CLIENT_BI_DIR_IPV6:
            return True

        return False
    def _neet_to_set_destination(self):
        if self.g_TestType == TEST_TYPE_UDP_TX or self.g_TestType == TEST_TYPE_UDP_BI_DIR:
            return True
        if self.g_TestType == TEST_TYPE_RAW_TX or self.g_TestType == TEST_TYPE_RAW_BI_DIR:
            self.g_Port = 0
            return True

        if self.g_TestType == TEST_TYPE_UDP_TX_IPV6 or self.g_TestType == TEST_TYPE_UDP_BI_DIR_IPV6:
            return True
        if self.g_TestType == TEST_TYPE_RAW_TX_IPV6 or self.g_TestType == TEST_TYPE_RAW_BI_DIR_IPV6:
            self.g_Port = 0
            return True

        return False

    def _setNonblocking(self):
        self.g_Sd.setblocking(0)

    def _Tx(self, data):
        if self.connectedTest:
            return self.g_Sd.send( data )
        else:
            if self.g_DestAddr != None:
                return self.g_Sd.sendto( data, self.g_DestAddr )
                #raise OSError(10035,0)

    def _Rx(self, size):
        if self.connectedTest:
            return self.g_Sd.recv( size )
        else:
            data, addr =  self.g_Sd.recvfrom( size )
            return data
    def _LogOut( self ):
        if self.logoutOnce == True:
            sys.exit()
        self.logoutOnce = True
        self._sendDisconnectConnectionlLess()
        self.g_Sd.close()
        if self.g_OldSd != None:
            self.g_OldSd.close()
        print "Time 0.0" + "-" + str(self.g_stat_cntr) + " sec txKbitSec " + str(int(self.g_c_AveNumBytes)) + " rxKbitSec " + str(int(self.g_s_AveNumBytes)) + " OutOfOrderPackets " + str(self.OutOforderPackets) + " MissedPackets " + str(self.missedPackets)
        sys.exit()
    def _pc_check_other_side_close_connection_less(self, data ):
        if self.connectedTest == False:
            if self.g_rawRxOffset:
                data = data[self.g_rawRxOffset:]
            valId = struct.unpack( '>l' , data[0:4] )
            self.g_rid = valId[0]
            if( self.g_rid < 0 ):
                raise OSError("connection less closed by other side")
            if( self.g_prevRid == -1 ):
                self.g_prevRid = self.g_rid

            elif( self.g_prevRid == 0x7fffffff):
                self.g_prevRid = 0
            else:
                self.g_prevRid += 1

            if( self.g_rid != self.g_prevRid ):
                if( self.g_rid < self.g_prevRid ):
                    self.OutOforderPackets+=1
                else:
                    self.missedPackets += 1 + self.g_rid - self.g_prevRid
                self.g_prevRid = self.g_rid

    def _need_multicast(self):
        # check if need to bind multicast recv
        if self.g_Args.udp:
            if self.g_Args.bind != None:
                self.g_multicastRxEnabled = True
                return True
            else:
                if self.g_Args.client != None:
                    if self.g_DstIP0[0:4] == "224.":
                        self.g_multicastRxEnabled = True
                        return True

        self.g_multicastRxEnabled = False
        return False

    def _configure_multicast(self):
        # if PC
        if( self.g_Args.pc_side ):
            if self.g_Args.bind != None:
                group = socket.inet_aton( self.g_Args.bind )
            else:
                group = socket.inet_aton( self.g_DstIP0 )
            mreq = struct.pack('4sL', group,socket.INADDR_ANY )
            self.g_Sd.setsockopt( socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq  )

        else:
            pass


    def _pc_statistics(self):
        if self._g_startStat == 1:
            # init timer
            self.g_time_stamp_1 = float(0.0 + time.clock())
            self._g_startStat = 2
        if self._g_startStat == 2:
            self.g_time_stamp_2 = float(time.clock())
            deltaT = float(self.g_time_stamp_2 - self.g_time_stamp_1)
            if deltaT > 1:
                #print deltaT
                # client/server statistics
                self.g_time_stamp_1 = self.g_time_stamp_2
                # since python recv hist transmittion
                if( self.g_multicastRxEnabled):
                    self.g_s_numBytes = self.g_s_numBytes - self.g_c_numBytes
                    if self.g_s_numBytes < 0:
                        self.g_s_numBytes = 0
                self.g_c_currentStat = float(0.0 + (self.g_c_numBytes * 8) / (deltaT  * KILO))
                self.g_s_currentStat = float(0.0 + (self.g_s_numBytes * 8) / (deltaT  * KILO))
                self.g_c_numBytes = 0
                self.g_s_numBytes = 0

                if( self.g_stat_cntr < 30 ):
                    tmpCntr = self.g_stat_cntr
                else:
                    tmpCntr = 30
                self.g_c_AveNumBytes = (( self.g_c_AveNumBytes * tmpCntr ) + self.g_c_currentStat) / (tmpCntr + 1)
                self.g_s_AveNumBytes = (( self.g_s_AveNumBytes * tmpCntr ) + self.g_s_currentStat) / (tmpCntr + 1)
                self.g_stat_cntr = self.g_stat_cntr + 1

                print "Time " + str(self.g_stat_cntr-1) + "-" + str(self.g_stat_cntr) + " sec txKbitSec " + str(int(self.g_c_currentStat)) + " rxKbitSec " + str(int(self.g_s_currentStat)) + " OutOfOrderPackets " + str(self.OutOforderPackets) + " MissedPackets " + str(self.missedPackets)
                # timeout only incase of client
                if self.g_stat_cntr >= self._g_time and self._g_time:
                    raise OSError("Test finished (timeout)")


##                    if( self.g_id < 0 ):
##

    def verify_cb(inst,conn, cert, errnum,depth, ok):

        print ok
    # This obviously has to be updated
        #print 'Got certificate: %s' % cert.get_subject()
        return ok

    def _run_pc_test(self):
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"#########################################")
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"\tRun PC test " + TEST_TYPE_NAME[self.g_TestType])
        self._trace_msg(TRACE_LEVEL_ACTIVITY,"#########################################")
        socketType = self._get_sock_type()
        sockFamily = self._get_sock_family()
        self.g_Sd  = socket.socket(sockFamily, socketType, self.g_protocol)
        if( self.g_security ):
            cipher = (self.g_security % 10) - 1
            method = (self.g_security / 10) - 1

            ctx = SSL.Context(METHODS[method])
            if self._need_to_accept():
                ctx.use_certificate_file(ServerCertificate)
                ctx.use_privatekey_file(ServerPrivateKey)
                ctx.load_tmp_dh(ServerDH)
                ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
               # print SSL.get_cipher_list()
                ctx.set_cipher_list(CIPHERS[cipher])
                self.g_Sd = SSL.Connection(ctx, self.g_Sd)

                ciphers = self.g_Sd.get_cipher_list()
                for m in ciphers:
                    print m

                if self._need_to_bind():
                    self.g_Sd.bind((BIND_IP, self.g_Port))
                self.g_Sd.listen(5)
                newSd, addr, = self.g_Sd .accept()
                newSd.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                try:
                    newSd.do_handshake()
                except Exception as ex:
                    print "Handshake faild"
                    sys.exit()
                self.g_OldSd = self.g_Sd
                self.g_Sd = newSd

            elif self._need_to_connect():
                print "connecting"
                ctx.set_verify(SSL.VERIFY_PEER , self.verify_cb)

                print "loading cert " + ServerCA
                ctx.set_cipher_list(CIPHERS[cipher])
                ctx.use_privatekey_file (ClientKey)
                ctx.use_certificate_file(ClientCertificate)
                ctx.set_tmp_ecdh_by_curve_name(SSL.NID_X9_62_prime256v1)
                ctx.load_verify_locations(ServerCA)
                self.g_Sd = SSL.Connection(ctx, self.g_Sd)
                ciphers = self.g_Sd.get_cipher_list()
                for m in ciphers:
                    print m
                self.g_Sd.connect((self.g_DstIP0, self.g_Port))
                self.g_Sd.do_handshake()
                print self.g_DstIP0
                print self.g_Port
                self.g_Sd.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, self.g_Sd.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)


            self._setNonblocking()

        else:
            try:
                if self._need_to_bind():
                    self.g_Sd.bind((BIND_IP, self.g_Port))
                # if multicast need to bind multicaast addr
                if self._need_multicast():
                    self._configure_multicast()

                if self._need_to_accept():
                    self.g_Sd.listen(5)
                    newSd, addr, = self.g_Sd.accept()
                    newSd.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

                    if( self.g_security ):
                        if( self.g_security == 1 ):
                            self.sslprivate = ssl.wrap_socket( newSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_NONE, ca_certs = ClientCA )
                        else:
                            self.sslprivate = ssl.wrap_socket( newSd, keyfile=ServerPrivateKey, certfile=ServerCertificate, server_side = True, cert_reqs = ssl.CERT_NONE, ssl_version=TestCipher[self.g_security][3], ca_certs = ClientCA, ciphers=TestCipher[self.g_security][4] )
                        ret = self.sslprivate.cipher()
                        if ret != None:
                            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
                        else:
                            print "Not secured !!!"
                            sys.exit()
                        newSd = self.sslprivate


                    self._trace_msg(TRACE_LEVEL_ACTIVITY,"New client connected from ip " + addr[0] + " port " + str(addr[1]))
                    self.g_OldSd = self.g_Sd
                    self.g_Sd  = newSd
                elif self._need_to_connect():
                    self.g_Sd.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, self.g_Sd.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
                    if( self.g_security ):
                        if( self.g_security == 1 ):
                            self.sslprivate = ssl.wrap_socket(self.g_Sd, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ca_certs = ServerCA )
                        else:
                            self.sslprivate = ssl.wrap_socket(self.g_Sd, keyfile=ClientKey, certfile=ClientCertificate, server_side = False, ssl_version=TestCipher[self.g_security][3], ca_certs = ServerCA, ciphers=TestCipher[self.g_security][4] )
                        self.g_Sd = self.sslprivate

                    self.g_Sd.connect((self.g_DstIP0, self.g_Port))
                    self.g_Sd.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

                    if( self.g_security ):
                        ret = self.sslprivate.cipher()
                        if ret != None:
                            print  "SSL connected " + ret[0] + " " + ret[1] + " " + str(ret[2])
                        else:
                            print "Not secured !!!"
                            sys.exit()
                elif self._neet_to_set_destination():
                    self.g_DestAddr = (self.g_DstIP0, self.g_Port)
                self._setNonblocking()
            except Exception, e:
                print e
                self._LogOut()
                sys.exit()
        print "Stating"
        recv_succ = 1
        i = True
        # calculate tx delay
        if self.doTx:
           # c_data = self._prepare_tx_data()
            self.g_time_tp_1 = float(0.0) + self.g_time_stamp_1
            self._g_startStat = 1
            if self.g_Throughput != 0:
                sendPacketEvery = float((float(self.g_PacketLen *8) / float(self.g_Throughput*KILO)))
            else:
                sendPacketEvery = float(0.0)
        rxSize = self.g_PacketLen  + self.g_rawRxOffset
        while i:

            try:
                if recv_succ == 1:
                    recv_succ = 0   # will stay 0 on exception so next time it will be skipped - only one skip
                    if self.doRx:
                        s_data = ""
                        s_data = self._Rx( rxSize )

                        if len(s_data) == 0:
                            raise OSError("tcp connection closed by other side")
                        if self._g_startStat == 0:
                            self._g_startStat = 1
                        self.g_s_numBytes = self.g_s_numBytes + len(s_data)
                         # UDP check id if other side close the connection
                        self._pc_check_other_side_close_connection_less( s_data )
                recv_succ = 1 # enable recv next time

                self._pc_statistics()



                if self.doTx:
                        if( 0.0 != sendPacketEvery ):
                            # calc tx delay incase of -b option was set
                            self.g_time_tp_2 = float(time.clock())
                            deltaTP = float(self.g_time_tp_2 - self.g_time_tp_1)
                            # check if can send
                            if( sendPacketEvery <= deltaTP):
                                ret = self._Tx( self._prepare_tx_data() )
                                self.g_time_tp_1 = self.g_time_tp_2
                                if( ret > 0 ):
                                    self.g_c_numBytes = self.g_c_numBytes + ret
                            else:
                                pass
                        else:
                            ret = self._Tx( self._prepare_tx_data() )
                            if( ret > 0 ):
                                self.g_c_numBytes = self.g_c_numBytes + ret


            except KeyboardInterrupt:
                print "logout !!!"
                self._LogOut()

            except Exception, e:
                #print type(e)
                if ( type(e) == SSL.WantReadError or type(e) == SSL.WantWriteError):
                    pass
                else:
                    try:
                        # ignore if "A non-blocking socket receive return without data
                        if e.errno == 10035:
                            pass
                        elif e.errno == 2:
                            pass
                        else:
                            print e
                            self._LogOut()
                    except:
                       print e.errno
                       self._LogOut()
                       sys.exit()
            except:
               print "logout !!!"
               self._LogOut()



if __name__ == '__main__':

    cperf = cperf_t(TRACE_LEVEL_DEBUG)
    cperf.execute()
