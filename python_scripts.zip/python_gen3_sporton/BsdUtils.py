#-------------------------------------------------------------------------------
# Name:        BsdUtils
# Purpose:
#
# Author:      x0068467
#
# Created:     19/4/2011
# Copyright:
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf
import utils
import BSD_Test_configurations as slConf
import struct
import Tracer

#AF_INET     =  2  # IPV4
#AF_INET6    =  3  # IPV6
#SOCK_STREAM =  1  # TCP Socket.
#SOCK_DGRAM  =  2  # UDP Socket.
#SOCK_RAW    =  3  # RAW Socket

SL_SECURITY_ANY = 100
SL_SECURITY_STARTTLS = 101

SOCK_RX_MTR = 4

BSDTIMEOUT =  (50000)  # milli seconds
BSDINFINITY = 99999999999 # seconds
BSD_MAX_RX_SIZE  = 8000 #for Rx aggregation, was 1600
BSD_LOW_SOCKET_ID =  0
BSD_HIGH_SOCKET_ID = 15

BSD_GEBERAL_ERROR    = 0xFFFF
BSD_EINTR            =  0xFFFC
BSD_ELBIG            =  0xFFF9  # rquested length too big
BSD_INEXE            =  0xFFF8
BSD_EBADF            =  0xFFF7
BSD_ENSOCK           =  0xFFF6
BSD_EAGAIN           =  0xFFF5
BSD_EWOULDBLOCK      = BSD_EAGAIN
BSD_ENOMEM           =  0xFFF4
BSD_EACCES           =  0xFFF3
BSD_EFAULT           =  0xFFF2
BSD_EINVAL           = 0xFFEA
BSD_EDESTADDRREQ     = 0xFFA7
BSD_EPROTOTYPE       = 0xFFA5
BSD_ENOPROTOOPT      = 0xFFA4
BSD_EPROTONOSUPPORT  = 0xFFA3
BSD_ESOCKTNOSUPPORT  = 0xFFA2
BSD_EOPNOTSUPP       = 0xFFA1
BSD_EAFNOSUPPORT     = 0xFF9F
BSD_EADDRINUSE       = 0xFF9E
BSD_EADDRNOTAVAIL    = 0xFF9D
BSD_ENETUNREACH      = 0xFF9B
BSD_ENOBUFS          = 0xFF97
BSD_EOBUFF           = BSD_ENOBUFS
BSD_EISCONN          = 0xFF96
BSD_ENOTCONN         = 0xFF95
BSD_ETIMEDOUT        = 0xFF92
BSD_ECONNREFUSED     = 0xFF91
BSD_EALREADY         = 0xFF8E


BSD_ESEC_CLOSE_NOTIFY  = 0xFED4
BSD_ESEC_UNEXPECTED_MESSAGE   =  0xFECA
BSD_ESEC_BAD_RECORD_MAC       =  0xFEC0
BSD_ESEC_DECRYPTION_FAILED    =  0xFEBF
BSD_ESEC_RECORD_OVERFLOW      =  0xFEBE
BSD_ESEC_DECOMPRESSION_FAILURE = 0xFEB6
BSD_ESEC_HANDSHAKE_FAILURE    =  0xFEAC
BSD_ESEC_NO_CERTIFICATE       =  0xFEAB
BSD_ESEC_BAD_CERTIFICATE       = 0xFEAA
BSD_ESEC_UNSUPPORTED_CERTIFICATE  = 0xFEA9
BSD_ESEC_CERTIFICATE_REVOKED   =    0xFEA8
BSD_ESEC_CERTIFICATE_EXPIRED    =   0xFEA7
BSD_ESEC_CERTIFICATE_UNKNOWN   =    0xFEA6
BSD_ESEC_ILLEGAL_PARAMETER     =    0xFEA5
BSD_ESEC_UNKNOWN_CA            =    0xFEA4
BSD_ESEC_ACCESS_DENIED         =    0xFEA3
BSD_ESEC_DECODE_ERROR          =    0xFEA2
BSD_ESEC_DECRYPT_ERROR         =    0xFEA1
BSD_ESEC_EXPORT_RESTRICTION    =    0xFE98
BSD_ESEC_PROTOCOL_VERSION      =    0xFE8E
BSD_ESEC_INSUFFICIENT_SECURITY  =   0xFE8D
BSD_ESEC_INTERNAL_ERROR         =   0xFE84
BSD_ESEC_USER_CANCELLED         =   0xFE7A
BSD_ESEC_NO_RENEGOTIATION       =   0xFE70
BSD_ESEC_UNSUPPORTED_EXTENSION  =   0xFE66
BSD_ESEC_CERTIFICATE_UNOBTAINABLE = 0xFE65
BSD_ESEC_UNRECOGNIZED_NAME        = 0xFE64
BSD_ESEC_BAD_CERTIFICATE_STATUS_RESPONSE = 0xFE63
BSD_ESEC_BAD_CERTIFICATE_HASH_VALUE = 0xFE62
BSD_ESECGENERAL      = 0xFE3E
BSD_ESECDECRYPT      = 0xFE3D
BSD_ESECCLOSED       = 0xFE3C
BSD_ESECSNOVERIFY    = 0xFE3B
BSD_ESECNOCAFILE     = 0xFE3A
BSD_ESECMEMORY       = 0xFE39
BSD_ESECBADCAFILE      = 0xFE38
BSD_ESECBADCERTFILE    = 0xFE37
BSD_ESECBADPRIVATEFILE = 0xFE36
BSD_ESECBADDHFILE      = 0xFE35
BSD_ESECT00MANYSSLOPENED = 0xFE34




#set/get sockOpt  level
SOL_SOCKET  =    1   # Define the socket option category.
IPPROTO_IP  =    2   # Define the IP option category.
SOL_PHY_OPT = 3
#set / get socopt level name
SO_REUSEADDR =   2   # Enable reuse of local addresses in the time wait state
SO_TYPE      =   3   # Socket type */
SO_ERROR     =   4   # Socket error status
SO_RCVBUF    =   8   # Enable setting receive buffer size */
SO_KEEPALIVE =   9   # Connections are kept alive with periodic messages */
SO_LINGER    =   13  # Socket lingers on close pending remaining send/receive packets. */
SO_RCVTIMEO  =   20  # Enable receive timeout */
SO_NONBLOCKING = 24  # Enable . disable nonblocking mode  */
SO_SECMETHOD   = 25  # security metohd
SO_SECURE_MASK = 26   # security mask 0 and mask 1
SO_SECURE_FILES = 27  # security files
SO_CHANGE_CHANNEL = 28 #change channel in raw socket rf
SO_MAXSEG         = 29 # tcp max segment
SO_SECURE_FILES_PRIVATE_KEY_FILE_NAME = 30
SO_SECURE_FILES_CERTIFICATE_FILE_NAME = 31
SO_SECURE_FILES_CA_FILE_NAME 		  = 32
SO_SECURE_FILES_DH_KEY_FILE_NAME      = 33
SO_SECURE_STARTTLS = 35
SO_SSL_CONNECTION_PARAMS =             36
SO_KEEPALIVETIME =                     37
SO_SECURE_DISABLE_CERTIFICATE_STORE =  38
SO_PHY_SET_METRICS_ALL_BSS = 107


SO_RX_NO_IP_BOUNDARY = 39 # connection less socket don`t keep IP rx boundary
IP_MULTICAST_IF  =   60 #/* Specify outgoing multicast interface */
IP_MULTICAST_TTL =   61 #/* Specify the TTL value to use for outgoing multicast packet. */
IP_MULTICAST_LOOP =   62 #/* Whether or not receive the outgoing multicast packet, loopback mode. */
IP_BLOCK_SOURCE = 63 #/* Block multicast from certain source. */
IP_UNBLOCK_SOURCE = 64 #/* Unblock multicast from certain source. */
IP_ADD_MEMBERSHIP =  65 #/* Join IPv4 multicast membership */
IP_DROP_MEMBERSHIP = 66 #/* Leave IPv4 multicast membership */
IP_HDRINCL         = 67 # Raw socket IPv4 header included.
IP_RAW_RX_NO_HEADER = 68 # NetX proprietary socket option that does not include  IPv4/IPv6 header (and extension headers) on received raw sockets.*/
IP_RAW_IPV6_HDRINCL = 69 # Transmitted buffer over IPv6 socket contains IPv6 header.
IPV6_ADD_MEMBERSHIP =  70 #/* Join IPv6 multicast membership */
IPV6_DROP_MEMBERSHIP = 71 #/* Leave IPv6 multicast membership */
IPV6_MULTICAST_HOPS	 = 72 # Specify the hops value to use for outgoing multicast packet.


SO_SECMETHOD_SSLV3  =  str(0) # /* security metohd SSL v3*/
SO_SECMETHOD_TLSV1   = str(1) # /* security metohd TLS v1*/
SO_SECMETHOD_TLSV1_1  = str(2) #  /* security metohd TLS v1_1*/
SO_SECMETHOD_TLSV1_2  = str(3) #  /* security metohd TLS v1_2*/
SO_SECMETHOD_SSLv3_TLSV1_2 =  str(4) #  /* sUse highest possible version from SSLv3 - TLS 1.2*/
SO_SECMETHOD_DLSV1  = str(5) #  /* security metohd DTL v1  */

SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA                      =  (1 << 0)
SECURE_MASK_SSL_RSA_WITH_RC4_128_MD5                      =  (1 << 1)
SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA                  =  (1 << 2)
SECURE_MASK_TLS_DHE_RSA_WITH_AES_256_CBC_SHA              =  (1 << 3)
SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA            =  (1 << 4)
SECURE_MASK_TLS_ECDHE_RSA_WITH_RC4_128_SHA                =  (1 << 5)
SECURE_MASK_TLS_RSA_WITH_AES_128_CBC_SHA256               =  (1 << 6)
SECURE_MASK_TLS_RSA_WITH_AES_256_CBC_SHA256               =  (1 << 7)
SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256         =  (1 << 8)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256       =  (1 << 9)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA          =  (1 << 10)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA          =  (1 << 11)
SECURE_MASK_TLS_RSA_WITH_AES_128_GCM_SHA256               =  (1 << 12)
SECURE_MASK_TLS_RSA_WITH_AES_256_GCM_SHA384               =  (1 << 13)
SECURE_MASK_TLS_DHE_RSA_WITH_AES_128_GCM_SHA256           =  (1 << 14)
SECURE_MASK_TLS_DHE_RSA_WITH_AES_256_GCM_SHA384           =  (1 << 15)
SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256         =  (1 << 16)
SECURE_MASK_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384         =  (1 << 17)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256       =  (1 << 18)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384       =  (1 << 19)
SECURE_MASK_TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 =  (1 << 20)
SECURE_MASK_TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256   =  (1 << 21)
SECURE_MASK_TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256     =  (1 << 22)

SECURE_MASK_SECURE_DEFAULT                       =        ((SECURE_MASK_TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 << 1 ) - 1)




INADDR_ANY = '0.0.0.0'


MSG_DONTWAIT   = 8  # 0x00000008 recv , flag non blocking

def convertIToIpvToIPv6pv4ToIPv4MappedIPv6( ip ):
    tmp = utils.convert_to_propriety_long(utils.getIpHexNum(utils.rotate_ipv4_endian(ip)))
    x = tmp.find(":")
    tmp = tmp[0:x] + tmp[x+1:]
    tmp = tmp[::-1]
    x = tmp.find(":")
    tmp = tmp[0:x] + tmp[x+1:]
    tmp = tmp[::-1]
    tmp = tmp.lower()
    tmp = "::ffff:" + tmp

    print tmp
    return tmp
def convertToIpFormat( family, ip ):
#    print ip
    rIP = ""
    if( family == slConf.AF_INET ):
        for i in ip:
            #print i
            if( len(rIP)  ):
                rIP = rIP + "."
                #print rIP
            rIP = rIP + str(int(i.encode("hex"), 16))
        #rIP = utils.rotate_ipv4_endian( rIP )
        #print rIP
        return rIP
    if( family == slConf.AF_INET6 ):
        for i in ip:
            #print i
            if( len(rIP)  ):
                rIP = rIP + ":"
                #print rIP
            rIP = rIP + str(int(i.encode("hex"), 16))
        #rIP = utils.rotate_ipv6_endian( rIP )
        parts = rIP.split(":")
#        print parts
        i = len(parts) - 1
        nParts = [parts[i]]
        i = i - 1
        #print nParts
        zip = 0
        while i >= 0: # roatate and zip first 0.0.0... to ::
            if( parts[i] == "0" or parts[i] == "00"):
                if( zip == 0 ):
                    zip = 1
                    nParts.append("")
                if( zip == 2 ):
                    nParts.append(parts[i])
            else:
                nParts.append(parts[i])
                if( zip == 1 ):
                    zip = 2
            i = i -1
        i = len(nParts) - 1
        #print "rIP: " + rIP
        nParts = nParts[::-1]
        tmpIP = ""
        for i in nParts:
            if i == "":
                tmpIP = tmpIP + ":"
            else:
                if int(i) < 16:
                    tmpIP = tmpIP + '0'
                tmpIP = tmpIP + hex(int(i))[2:]
        print tmpIP
        j = 0
        rIP = ""
        tmp =""
        for i in tmpIP:
            if i == ":":
                j = 0
                rIP = rIP + ":"
                tmp =""
            else:
                if i == '0' and tmp == "":
                    pass
                else:
                    rIP = rIP + i
                    tmp = tmp + i
                j = j + 1
                if j == 4:
                    rIP = rIP + ":"
                    j = 0
                    tmp =""

        if rIP[len(rIP)-1:] == ":":
            rIP = rIP[:len(rIP)-1]
#
        if( rIP[0:1] == ":" and rIP[1:2] != ":" ):
            rIP = ":" + rIP
        return rIP

def IsBsdError( returnCode, ignoreList ):
    errorList = (BSD_GEBERAL_ERROR, BSD_EINTR, BSD_INEXE, BSD_EBADF, BSD_ENSOCK, BSD_EAGAIN, BSD_EALREADY, BSD_EWOULDBLOCK, BSD_ENOMEM, \
                BSD_EACCES, BSD_EFAULT, BSD_EINVAL, BSD_EDESTADDRREQ, BSD_EPROTOTYPE, BSD_ENOPROTOOPT, BSD_EPROTONOSUPPORT, BSD_ESOCKTNOSUPPORT, BSD_EOPNOTSUPP, \
                BSD_EAFNOSUPPORT, BSD_EADDRINUSE, BSD_EADDRNOTAVAIL, BSD_ENETUNREACH, BSD_ENOBUFS, BSD_EOBUFF, BSD_EISCONN, BSD_ENOTCONN, BSD_ETIMEDOUT, BSD_ECONNREFUSED, \
                BSD_ESEC_CLOSE_NOTIFY, BSD_ESEC_UNEXPECTED_MESSAGE, BSD_ESEC_BAD_RECORD_MAC, BSD_ESEC_DECRYPTION_FAILED, BSD_ESEC_RECORD_OVERFLOW, BSD_ESEC_DECOMPRESSION_FAILURE, \
                BSD_ESEC_HANDSHAKE_FAILURE, BSD_ESEC_NO_CERTIFICATE, BSD_ESEC_BAD_CERTIFICATE, BSD_ESEC_UNSUPPORTED_CERTIFICATE, BSD_ESEC_CERTIFICATE_REVOKED,BSD_ESEC_CERTIFICATE_EXPIRED, \
                BSD_ESEC_CERTIFICATE_UNKNOWN, BSD_ESEC_ILLEGAL_PARAMETER, BSD_ESEC_UNKNOWN_CA, BSD_ESEC_ACCESS_DENIED, BSD_ESEC_DECODE_ERROR, BSD_ESEC_DECRYPT_ERROR, BSD_ESEC_EXPORT_RESTRICTION, \
                BSD_ESEC_PROTOCOL_VERSION, BSD_ESEC_INSUFFICIENT_SECURITY, BSD_ESEC_INTERNAL_ERROR, BSD_ESEC_USER_CANCELLED, BSD_ESEC_NO_RENEGOTIATION, BSD_ESEC_UNSUPPORTED_EXTENSION, BSD_ESEC_CERTIFICATE_UNOBTAINABLE, \
                BSD_ESEC_UNRECOGNIZED_NAME, BSD_ESEC_BAD_CERTIFICATE_STATUS_RESPONSE, BSD_ESEC_BAD_CERTIFICATE_HASH_VALUE, \
                BSD_ESECGENERAL, BSD_ESECDECRYPT, BSD_ESECCLOSED, BSD_ESECSNOVERIFY, BSD_ESECNOCAFILE, BSD_ESECMEMORY , BSD_ESECBADCAFILE, BSD_ESECBADCERTFILE, BSD_ESECBADPRIVATEFILE, BSD_ESECBADDHFILE )



    found = False
    for i in errorList:
        if i == returnCode:
            found = True
            break
    if found == True:
        if ignoreList != []:
            for i in ignorelist:
                if i == returnCode:
                    found = False
                    break
    return found

class BsdUtils:
    def __init__(self, core , PrintEnable=True):
        self.core = core
        self.Tracer = Tracer.Tracer("BsdUtilsTrace.txt", 1, PrintEnable)

    def clearEvents(self):
        self.core.clearEvents()
    # SOCKET
    # function return A,B
    # A == found event (True) , or Not (False)
    # B == new socket id (>= 0) error == -1
    def Socket( self, Family, Type , Protocol ):
        self.core.InvokeSLCommand("BSD", "SOCKET" , BSDTIMEOUT, Family, Type, Protocol )
        return self.waitSocketEvent( BSDTIMEOUT )

    # function wait on SOCKET event
    # function return A,B
    # A == found event (True) , or Not (False)
    # B == new socket id (>= 0) error == -1
    def waitSocketEvent( self, timeOut ):
        val = self.core.waitEvent("cc_BSD_SOCKET", [], timeOut )
        if  val[0] == True:
            ret = ( True,(val[1])[4] )
        else:
            ret = ( False, -1 )
        self.Tracer.write(ret)
        return ret

    # BIND
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == bind success (0) or failure
    # C == socket id (>= 0) error == -1
    def Bind( self, sd, family, port, ip = "0.0.0.0" ):
        padding = 00
        FamilyAndFalg = str(family << 4)
        portPaddingAndAddr = utils.getPortHexStr(port, True) + ":0:0:"


        if family == slConf.AF_INET:
            if ip != None:
                portPaddingAndAddr = portPaddingAndAddr + utils.getIpHexStr(ip, False)
            else:
                portPaddingAndAddr = portPaddingAndAddr + utils.getIpHexStr(conf.LOCAL_IP_ADDR, False)
            self.core.InvokeSLCommand("BSD", "BIND"              , 1, padding, sd, FamilyAndFalg, portPaddingAndAddr )

        else:
            if ip != None:
                if ip == "0.0.0.0":
                    ip = "::"
                portPaddingAndAddr = portPaddingAndAddr + utils.ipv6ExtractToPoprietyFullAddress(ip, False)
            else:
                portPaddingAndAddr = portPaddingAndAddr + utils.ipv6ExtractToPoprietyFullAddress(conf.LOCAL_IPV6_ADDR, False)
            self.core.InvokeSLCommand("BSD", "BIND_V6"              , 1, padding, sd, FamilyAndFalg, portPaddingAndAddr )

        return self.waitBindEvent(BSDTIMEOUT)

    # function wait on BIND event
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == bind success (0) or failure
    # C == socket id (>= 0) error == -1
    def waitBindEvent( self, timeOut ):
        val = self.core.waitEvent("cc_BSD_BIND", [], timeOut )
        if  val[0] == True:
            ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            ret = ( False, -1, -1 )
        self.Tracer.write("waitBindEvent: ")
        self.Tracer.write(ret)
        return ret


    # CONNECT
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == connect success (0) or failure
    # C == socket id (>= 0) error == -1
    def Connect( self, sd, family, port, ip ):
        padding = 00
        FamilyAndFalg = str(family << 4)
        portPaddingAndAddr = utils.getPortHexStr(port, True) + ":0:0:"
        if family == slConf.AF_INET:
            portPaddingAndAddr = portPaddingAndAddr + utils.getIpHexStr(ip, False)
            self.core.InvokeSLCommand("BSD", "CONNECT"              , 1, padding, sd, FamilyAndFalg, portPaddingAndAddr )

        else:
            portPaddingAndAddr = portPaddingAndAddr + utils.ipv6ExtractToPoprietyFullAddress(ip,False)
            self.core.InvokeSLCommand("BSD", "CONNECT_V6"              , 1, padding, sd, FamilyAndFalg, portPaddingAndAddr )

        return self.waitConnectEvent( BSDTIMEOUT * 100)


    # function wait on CONNECT event
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == connect success (0) or failure
    # C == socket id (>= 0) error == -1
    def waitConnectEvent( self, timeOut ):
        val = self.core.waitEvent("cc_BSD_CONNECT", [], timeOut )
        self.Tracer.write("waitConnectEvent")
        self.Tracer.write(val)
        if val[0] == True:
            if (val[1])[4] == 0: # connect , start working , wait to async connect
                val = self.core.waitEvent("CONNECT_Async_Event", [], timeOut )
                if  val[0] == True:
                    ret = ( True, (val[1])[4], (val[1])[5] )
                else:
                    self.Tracer.write("CONNECT_Async_Event")
                    ret = ( False, -1, -1 )
            else:
                self.Tracer.write("waitConnectEvent 7")
                ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            self.Tracer.write("error cc_BSD_CONNECT")
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret

    # LISTEN
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == listen success (0) or failure
    # C == socket id (>= 0) error == -1
    def Listen( self, sd, backlog ):
        self.core.InvokeSLCommand("BSD", "LISTEN" , BSDTIMEOUT, sd, backlog, 0 )
        return self.waitListenEvent( BSDTIMEOUT )


    # function wait on LISTEN event
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == listen success (0) or failure
    # C == socket id (>= 0) error == -1
    def waitListenEvent( self, timeOut ):
        val = self.core.waitEvent("cc_BSD_LISTEN", [], timeOut )
        if  val[0] == True:
            ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret






    # RECVFROM
    # function return A -  G
    # A == found event (True) , or Not (False)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1
    # D == IP version 4 or 6
    # E == source port
    # F == source ip
    # G == Data

    def RecvFrom( self, sd, lenToRead, flag, family ):
        FamilyAndFalg = str( (family <<4) | (flag & 0xf) )
        self.core.InvokeSLCommand("BSD","RECVFROM" , BSDTIMEOUT, lenToRead, sd, FamilyAndFalg )     #timeout, socket, len to read , flag ipv6 addrlen (28)
        return self.waitRecvFromEvent( family, BSDTIMEOUT )


    # function wait on RecvFrom event
    # function return A -  G
    # A == found event (True) , or Not (False)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1
    # D == IP version 4 or 6
    # E == source port
    # F == source ip
    # G == Data
    def waitRecvFromEvent( self, family, timeOut ):
        if family == slConf.AF_INET6:
            val = self.core.waitEvent("RECVFROM_V6_Async_Event", [], timeOut )
        else:
            val = self.core.waitEvent("RECVFROM_Async_Event", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            if( (val[1])[4] > 0 and (val[1])[4] < BSD_MAX_RX_SIZE ): #data exist
                self.Tracer.write("@@@@")
                self.Tracer.write(val)
                if( (val[1])[6] == slConf.AF_INET ): #ipv4
                        ip = convertToIpFormat( slConf.AF_INET, (val[1])[9][0:4])
                        dataLen = (val[1])[4]
                        data = (val[1])[9][4:dataLen + 4]
                        #print "recvfrom ip: " + ip
                        ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], utils.swap16(int((val[1])[7])), ip , data )
                else:
                    if( (val[1])[6] == slConf.AF_INET6 ): #ipv6
                        ip = convertToIpFormat( slConf.AF_INET6, (val[1])[9][0:16])
                        dataLen = (val[1])[4]
                        data = (val[1])[9][16:dataLen + 16]
                        ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], utils.swap16(int((val[1])[7])), ip , data )
                    else:  #unknown ip
                        self.Tracer.write("incorrect family !!!")
                        ret = ( True, (val[1])[4], (val[1])[5] )
            else:
                ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret


    # RECV
    # function return A -  G
    # A == found event (True) , or Not (False)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1
    # G == Data

    def Recv( self, sd, lenToRead, flag, time0ut = BSDTIMEOUT ):
        FamilyAndFalg = str( flag & 0xf )
        self.core.InvokeSLCommand("BSD","RECV" , time0ut, lenToRead, sd, FamilyAndFalg )     #timeout, socket, len to read , flag ipv6 addrlen (28)
        return self.waitRecvEvent( time0ut )


    # function wait on Recv event
    # function return A - D
    # A == found event (True) , or Not (False)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1
    # D == Data
    def waitRecvEvent( self, timeOut ):
        val = self.core.waitEvent("RECV_Async_Event", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            if( (val[1])[4] > 0 and (val[1])[4] < BSD_MAX_RX_SIZE ): #data exist
                self.Tracer.write("@@@@")
                self.Tracer.write(val)
                dataLen = (val[1])[4]
                data = (val[1])[7][0:dataLen]
                        #print "recvfrom ip: " + ip
                ret = ( True, (val[1])[4], (val[1])[5], data )
            else:
                ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret

    # SEND
    # function return allways (no event back on recv / recvfrom)
    # A == return (True)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1

    def Send( self, sd, lenToWrite, flag, data ):
        FamilyAndFalg = str( flag & 0xf )
        self.core.InvokeSLCommand("BSD","BSDSEND", BSDTIMEOUT, lenToWrite, sd, FamilyAndFalg, data )
        ret = ( True, lenToWrite, sd )
        return ret


    # SENDTO
    # function return allways (no event back on recv / recvfrom)
    # A == return (True)
    # B == number of bytes or failure
    # C == socket id (>= 0) error == -1

    def SendTo( self, sd, lenToWrite, flag, data, family, port, ip ):
        FamilyAndFalg = str( (family <<4) | (flag & 0xf) )
        portPaddingAndAddr = utils.getPortHexStr(port, True ) + ":0:0:"
        if family == slConf.AF_INET:
            portPaddingAndAddr = portPaddingAndAddr + utils.getIpHexStr(ip, False)
            self.core.InvokeSLCommand("BSD", "BSDSENDTO"              , 1, lenToWrite, sd, FamilyAndFalg, portPaddingAndAddr, data )

        else:
            portPaddingAndAddr = portPaddingAndAddr + utils.ipv6ExtractToPoprietyFullAddress(ip, False)
            self.core.InvokeSLCommand("BSD", "BSDSENDTO_V6"              , 1, lenToWrite, sd, FamilyAndFalg, portPaddingAndAddr, data )

        ret = ( True, lenToWrite, sd )
        return ret

    # ACCEPT
    # function return A -  F
    # A == found event (True) , or Not (False)
    # B == new sd or failure
    # C == socket id (>= 0) error == -1
    # D == IP version 4 or 6
    # E == client port
    # F == client ip

    def Accept( self, sd, family, timeout = BSDTIMEOUT ):
        self.core.InvokeSLCommand("BSD", "ACCEPT" , BSDTIMEOUT, sd, family, 0, 0 )
        return self.waitAccept( sd, family, timeout )

    # function wait on Accept event
    # function return A -  F
    # A == found event (True) , or Not (False)
    # B == new sd or failure
    # C == socket id (>= 0) error == -1
    # D == IP version 4 or 6
    # E == client port
    # F == client ip
    def waitAccept( self, sd, family, timeOut ):
        val = self.core.waitEvent("cc_BSD_ACCEPT", [], timeOut )
        ret = ( False, -1, -1 )
        self.Tracer.write("waitAccepttEvent")
        self.Tracer.write(val)
        if val[0] == True:
            self.Tracer.write("waitAccepttEvent 1")
            if (val[1])[4] == 0 and (val[1])[5] == sd: # accept , start working , wait to async connect
                self.Tracer.write("waitAccepttEvent 2")
                if family == slConf.AF_INET6:
                    val = self.core.waitEvent("ACCEPT_Async_Event", [], timeOut )
                else:
                    val = self.core.waitEvent("ACCEPT_Async_Event", [], timeOut )
                if  val[0] == True:
                    if IsBsdError( (val[1])[4], [] ):
                        self.Tracer.write("waitAccepttEvent BSD_EAGAIN")
                        ret = ( True, (val[1])[4], (val[1])[5] )
                    else:
                        self.Tracer.write("waitAccepttEvent 3")
                        port = str( utils.swap16(int((val[1])[7])))
                        if( (val[1])[6] == slConf.AF_INET ): #ipv4
                            self.Tracer.write("waitAccepttEvent 4")
                            ip = convertToIpFormat( slConf.AF_INET, (val[1])[9])
                                #print "recvfrom ip: " + ip
                            ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], port, ip )
                        else:
                            if( (val[1])[6] == slConf.AF_INET6 ): #ipv6
                                self.Tracer.write("waitAccepttEvent 5")
                                ip = convertToIpFormat( slConf.AF_INET6, (val[1])[9])
                                ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], port, ip )
                            else:  #unknown ip
                                self.Tracer.write("waitAccepttEvent 6")
                                self.Tracer.write("incorrect family !!!")
                                ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], (val[1])[7], (val[1])[9])
            else:
                self.Tracer.write("waitAccepttEvent 7")
                ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            self.Tracer.write("waitAccepttEvent 8")
            self.Tracer.write("error cc_BSD_CONNECT")
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret

    # CLOSE
    # function return A -  C
    # A == found event (True) , or Not (False)
    # B == status or failure
    # C == socket id (>= 0) error == -1

    def Close( self, sd ):
        self.core.InvokeSLCommand("BSD", "CLOSE" , BSDTIMEOUT, sd, 0,0,0 )
        return self.waitClose( sd, BSDTIMEOUT )

    # function wait on Close event
    # function return A -  C
    # A == found event (True) , or Not (False)
    # B == status or failure
    # C == socket id (>= 0) error == -1
    #def waitClose( self, sd, timeOut ):
    #
    #   val = self.core.waitEvent("cc_BSD_CLOSE", [], timeOut )
    #
    #   self.Tracer.write("waitCloseEvent")
    #   self.Tracer.write(val)
    #   ret = ret = ( False, -1, -1 )
    #   if val[0] == True:
    #       if (val[1])[5] == sd: # close correct sd
    #           ret = ( True, (val[1])[4], (val[1])[5] )
    #   self.Tracer.write(ret)
    #   return ret

    def waitClose( self, sd, timeOut  ):
        val = self.core.waitEvent("cc_BSD_CLOSE", [], timeOut )
        self.Tracer.write("cc_BSD_CLOSE event")
        self.Tracer.write(val)
        if val[0] == True:
            if (val[1])[4] == 0: # close command complete recieve, wait for the close asyn event
                val = self.core.waitEvent("CLOSE_Async_Event", [], timeOut )
                if  val[0] == True:
                    if (val[1])[5] != sd: # close correct sd
                        self.Tracer.write("CLOSE_Async_Event returned with wrong sd")
                    self.Tracer.write("CLOSE_Async_Event")
                    ret = ( True, (val[1])[4], (val[1])[5] )
                else:
                    self.Tracer.write("Close_Async_Event error")
                    ret = ( False, -1, -1 )
            else:
                self.Tracer.write("cc_BSD_CLOSE event was returned with error")
                ret = ( True, (val[1])[4], (val[1])[5] )
        else:
            self.Tracer.write("error cc_BSD_CLOSE")
            ret = ( False, -1, -1 )
        self.Tracer.write(ret)
        return ret


    # SELECT
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == nfds, high sd found + 1
    # D == readCont, read count
    # E == readSet,  read set bit
    # F == writeCont, write count
    # G == writeSet,  write set bit
    # H == exceptionCont, exception count
    # I == exceptionSet,  exception set bit

    def Select( self, nfds, readCount, readSet, writeCount, writeSet, exceptionCont, exceptionSet, microTimeout, secondsTimeout, timeout = BSDTIMEOUT ):
        self.core.InvokeSLCommand("BSD", "SELECT" , BSDTIMEOUT, nfds, readCount, writeCount, 0, readSet, writeSet, microTimeout, secondsTimeout )
        return self.waitSelectEvent( timeout )


    # function wait on LISTEN event
    # function return A,B,C
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == nfds, high sd found + 1
    # D == readCont, read count
    # E == readSet,  read set bit
    # F == writeCont, write count
    # G == writeSet,  write set bit
    # H == exceptionCont, exception count
    # I == exceptionSet,  exception set bit
    def waitSelectEvent( self, timeOut ):
        ret = ( False, -1  )
        val = self.core.waitEvent("cc_BSD_SELECT", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            if (val[1])[4] == 0: #ok need to wait async event
                val = self.core.waitEvent("SELECT_Async_Event", [], timeOut )
                if val[0] == True:
                    self.Tracer.write("+++++")
                    self.Tracer.write(val)
                    ret = ( True, (val[1])[4], (val[1])[5], (val[1])[7], (val[1])[6], (val[1])[8], 0 , 0)
                    self.Tracer.write(ret)
            else:
                ret = ( True, (val[1])[4] )
        self.Tracer.write(ret)
        return ret





    # SetSockOpt
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == socket id

    def SetSockOpt( self, sd, level, optionName, optionLen, optionValue ):
        self.core.InvokeSLCommand("BSD", "SETSOCKOPT" , BSDTIMEOUT, sd, level,optionName, optionLen, optionValue)
        return self.waitSetSockOptEvent( BSDTIMEOUT )


    # function wait on SetSockOpt event
    # function return A,B,C
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == socket id
    def waitSetSockOptEvent( self, timeOut ):
        ret = ( False, -1  )
        val = self.core.waitEvent("cc_BSD_SETSOCKOPT", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            ret = ( True, (val[1])[4], (val[1])[5] )
            self.Tracer.write(ret)
        self.Tracer.write(ret)
        return ret



    # GetSockOpt
    # function return A-E
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == socket id
    # D == option len
    # E == option val

    def GetSockOpt( self, sd, level, optionName, optionLen ):
        self.core.InvokeSLCommand("BSD", "GETSOCKOPT" , BSDTIMEOUT, sd, level,optionName, optionLen )
        return self.waitGetSockOptEvent( BSDTIMEOUT )


    # function wait on GetSockOpt event
    # function return A-E
    # A == found event (True) , or Not (False)
    # B == success (0) or failure
    # C == socket id
    # D == option len
    # E == option val
    def waitGetSockOptEvent( self, timeOut ):
        ret = ( False, -1, -1  )
        val = self.core.waitEvent("cc_BSD_GETSOCKOPT", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            if  (val[1])[6] > 0:
                self.Tracer.write("waitGetSockOptEvent 1")
                ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], (val[1])[7])
            else:
                self.Tracer.write("waitGetSockOptEvent 2")
                ret = ( True, (val[1])[4], (val[1])[5], (val[1])[6], "" )

        self.Tracer.write(ret)
        return ret


    # GetHostByName
    # function return A, B, C
    # A == found event (True) , or Not (False)
    # B == IP version
    # C == IP

    def GetHostByName( self, name, family ):
        self.core.InvokeSLCommand("NETAPP", "GETHOSTBYNAME" , 2, len(name), family, 0 , name  )
        return self.waitGetHostByNametEvent( family,  100000 )


    # function wait on GetHostByName event
    # function return A-E
    # function return A, B, C
    # A == found event (True) , or Not (False)
    # B == IP version
    # C == IP
    def waitGetHostByNametEvent( self, family, timeOut ):
        ret = ( False, -1, -1  )
        val = self.core.waitEvent("cc_NETAPP_GETHOSTBYNAME", [], timeOut )
        self.Tracer.write(val)
        if  val[0] == True:
            if (val[1])[4] == 0: #ok need to wait async event
                if( family == slConf.AF_INET ):
                    val = self.core.waitEvent("GETHOSTBYNAME_Async_Event", [], timeOut )
                    self.Tracer.write(val)
                    if  val[0] == True:
                        if  (val[1])[4] == 0: # status == 0
                            ip = struct.unpack('BBBB', (val[1])[6])
                            self.Tracer.write(ip)
                            ip = ip[::-1]
                            ret = ( True, (val[1])[4], 0, ip )
                        else:
                            ret = ( True, (val[1])[4], -1, -1 )
                        self.Tracer.write("GetHostByName unknown host")
                else:
                    # ipv6 NTD
                    val = self.core.waitEvent("GETHOSTBYNAME_V6_Async_Event", [], timeOut )
                    self.Tracer.write(val)

            else:
                ret = ( False, (val[1])[4], -1  )
                self.Tracer.write("GetHostByName command error")


        self.Tracer.write(ret)
        return ret

    # GetHostByName
    # function return A, B, C
    # A == found event (True) , or Not (False)
    # B == IP version
    # C == IP

    def GetHostByService( self, name, family ):
        self.core.InvokeSLCommand("NETAPP", "GETHOSTBYSERVICE" , 2, len(name), family, 0 , name  )
        return self.waitGetHostByServiceEvent( family,  100000 )


    # function wait on GetHostByName event
    # function return A-E
    # function return A, B, C
    # A == found event (True) , or Not (False)
    # B == IP version
    # C == IP
    def waitGetHostByServiceEvent( self, family, timeOut ):
        ret = ( False, -1, 0, 0 , -1 ,""  )
        val = self.core.waitEvent("cc_NETAPP_GETHOSTBYSERVICE", [], timeOut )
        print("ronen12")
        self.Tracer.write(val)
        if  val[0] == True:
            if (val[1])[4] == 0: #ok need to wait async event
                if( family == slConf.AF_INET ):
                    val = self.core.waitEvent("GETHOSTBYSERVICE_Async_Event", [], timeOut )
                    self.Tracer.write(val)
                    if  val[0] == True:
                        if  (val[1])[4] == 0: # status == 0
                            ip = struct.unpack('BBBB', (val[1])[7])
                            self.Tracer.write(ip)
                            ip = ip[::-1]
                            ret = ( True, (val[1])[4],(val[1])[5] , (val[1])[6],ip ,(val[1])[8])
                        else:
                            ret = ( True, (val[1])[4], -1, 0, 0 , -1 ,"" )
                            self.Tracer.write("GetHostByName unknown host")
                else:
                    # ipv6 NTD
                    val = self.core.waitEvent("GETHOSTBYNAME_V6_Async_Event", [], timeOut )
                    self.Tracer.write(val)

            else:
                ret = ( False, (val[1])[4], -1  )
                self.Tracer.write("GetHostByService command error")


        self.Tracer.write(ret)
        return ret


def removeIInterfaceIdIpv6(addr ):
    length = len(addr)
    i = 1
    while i < length:
        if addr[i:i+1] == '%':
            addr = addr[:i]
            return addr
        i = i + 1
    return addr

##if __name__ == '__main__':
##    ip = '\x80\x0b\xfe?\x00\x00\xe2\x17\x00\x00\x00\x00\x05\x00\x00\x00'
##    convertToIpFormat( slConf.AF_INET6 , ip )
