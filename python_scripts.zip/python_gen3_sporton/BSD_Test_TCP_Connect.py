#-------------------------------------------------------------------------------
# Name:        test_cmd_self.bsdHandle.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import BsdUtils
import BSD_Test_configurations as slConf
import BSD_Test_base
import socket
import select

NUM_PACKETS_TO_SEND_BEFORE_EXIT = 30

class BsdTestTcpBlockingConnect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpBlockingConnect", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2)
            if udpSd in rlist:
                rdata = udpSd.recv(self.MAX_PAYLOAD)
            else: # timeout
                udpSd.close()
                self.log(self.getline(), self.failed )

            udpSd.close()
            # data recv ready to load tcp server
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            s.setblocking(0)
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            s.listen(4)
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            if privateSd == None: # client not connected yet need to wait on select
                rlist, xlist, xlist = select.select([s], [],[], self.TIMEOUT )
                if s in rlist:
                    try:
                        privateSd, addr = s.accept()
                    except Exception, e:
                        print e
                        s.close()
                        self.log(self.getline(), self.failed )
                else:
                    s.close()
                    self.log(self.getline(), self.failed )


            # now client is connected
            loop = True
            index = 0
            while loop:
                rlist, xlist, xlist = select.select([privateSd], [],[], 1 ) #timeout 1 seconds
                if privateSd in rlist:
                    rdata = privateSd.recv(self.MAX_PAYLOAD)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        loop = False
                    else:
                        privateSd.send( rdata )
                else: # timeout
                     index = index + 1
                     if index > 10: # wait to connect up to 10 seconds
                         s.close()
                         privateSd.close()
                         self.log(self.getline(), self.failed )
            s.close()
            privateSd.close()
            self.log(self.getline(), self.success )
            s.close()

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        #try to connect to non exist server - should failure after timeout
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_ECONNREFUSED:
            self.log(self.getline(), self.failed, str(ret[1]) )


        # udp for sync in order server up
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"


        loop = True
        i = 1
        while loop:
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            self.log(self.getline(), self.info, str(i) )
            i = i + 1
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[1] == 0:
                loop = False

            if i > 10:
                self.log(self.getline(),self.failed, str(sd) )

        #connected send data on tcp socket+ wait to reply
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( sd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            #print ret
            if sd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )

        #send end of test
        time.sleep(0.3)
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpNonBlockingConnect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpNonBlockingConnect", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
            if udpSd in rlist:
                rdata = udpSd.recv(self.MAX_PAYLOAD)
            else: # timeout
                udpSd.close()
                self.log(self.getline(), self.failed )

            udpSd.close()
            # data recv ready to load tcp server
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            s.setblocking(0)
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            s.listen(4)
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            if privateSd == None: # client not connected yet need to wait on select
                rlist, xlist, xlist = select.select([s], [],[], self.TIMEOUT )
                if s in rlist:
                    try:
                        privateSd, addr = s.accept()
                    except Exception, e:
                        print e
                        s.close()
                        self.log(self.getline(), self.failed )
                else:
                    s.close()
                    self.log(self.getline(), self.failed )


            # now client is connected
            loop = True
            index = 0
            while loop:
                rlist, xlist, xlist = select.select([privateSd], [],[], 1 ) #timeout 1 seconds
                if privateSd in rlist:
                    rdata = privateSd.recv(self.MAX_PAYLOAD)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        loop = False
                    else:
                        privateSd.send( rdata )
                else: # timeout
                     index = index + 1
                     if index > 10: # wait to connect up to 10 seconds
                         s.close()
                         privateSd.close()
                         self.log(self.getline(), self.failed )
            s.close()
            privateSd.close()
            self.log(self.getline(), self.success )
            s.close()


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        #try to connect to non exist server - should failure after timeout
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY:
            self.log(self.getline(), self.failed )

        # udp for sync in order server up
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"

        loop = True
        i = 1
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            #self.log(self.getline(), self.info, str(ret[1]) )
            if ret[1] == 0:
                loop = False
            if i > 15:
                self.log(self.getline(),self.failed, str(sd) )
            time.sleep(0.2)
            ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.3)


        #connected send data on tcp socket+ wait to reply
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( sd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        time.sleep(1)
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD, 0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            #print ret
            if sd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )

        #send end of test
        time.sleep(0.3)
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()




class BsdTestTcpNonBlockingConnectWithSelect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpNonBlockingConnectWithSelect", slBsdHandle, fileHandle )
    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
            self.log(self.getline(), self.start )
            # recv udp for sync
            udpSd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udpSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
            i = 0
            rlist, xlist, xlist = select.select([udpSd], [],[], self.TIMEOUT * 2 )
            if udpSd in rlist:
                rdata = udpSd.recv(self.MAX_PAYLOAD)
            else: # timeout
                udpSd.close()
                self.log(self.getline(), self.failed )

            udpSd.close()
            time.sleep(1)
            # data recv ready to load tcp server
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
            s.setblocking(0)
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
            s.listen(4)
            privateSd = None
            try:
                privateSd, addr = s.accept()
            except Exception, e:
                print e
            if privateSd == None: # client not connected yet need to wait on select
                rlist, xlist, xlist = select.select([s], [],[], self.TIMEOUT )
                if s in rlist:
                    try:
                        privateSd, addr = s.accept()
                    except Exception, e:
                        print e
                        s.close()
                        self.log(self.getline(), self.failed )
                else:
                    s.close()
                    self.log(self.getline(), self.failed )


            # now client is connected
            loop = True
            index = 0
            while loop:
                rlist, xlist, xlist = select.select([privateSd], [],[], 1 ) #timeout 1 seconds
                if privateSd in rlist:
                    rdata = privateSd.recv(self.MAX_PAYLOAD)
                    if rdata.find(self.endSyncMsg) != -1:  # find end sync string in buffer
                        self.log(self.getline(), self.info, "endSyncMsg" )
                        loop = False
                    else:
                        privateSd.send( rdata )
                else: # timeout
                     index = index + 1
                     if index > 10: # wait to connect up to 10 seconds
                         s.close()
                         privateSd.close()
                         self.log(self.getline(), self.failed )
            s.close()
            privateSd.close()
            self.log(self.getline(), self.success )
            s.close()

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        #set non blocking publick socket
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        # udp for sync in order server up
        # udp socket to transmit while polling accept
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        udpSd = ret[1]
        DATA = "send data ==>"


        #try to connect to non exist server -
        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY: # must return with try again ...
            self.log(self.getline(), self.failed )

        #No server, wait on select, select should return with sd , when pollong again should (connect) should return with ERROR

        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = ret = self.slBsdHandle.Select(sd + 1, 9,0, 1, fdset,  0, 0, 0, 3 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[5] )
            if status == 1:
                ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[1] != BsdUtils.BSD_ECONNREFUSED: # Must retunr with ERROR
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        i = 0
        #send data in order to load server
        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.7)

        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        time.sleep(0.7)

        ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EALREADY: # get pool again , server is still not up
            self.log(self.getline(), self.failed )


        #self.log(self.getline(),self.info, str(ret[1]) )
        NUM_OF_LOOP = 20
        while i < NUM_OF_LOOP:
            fdset = utils.FD_ZERO()
            fdset = utils.FD_SET( sd, fdset)
            ret = self.slBsdHandle.Select(sd + 1, 9,0, 1, fdset,  0, 0, 300, 0 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[1] > 0: # select status  > 0 means no timeout
                status = utils.FD_ISSET( sd, ret[5] )
                if status == 1:
                    # check errno  = 0
                    ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    ret = utils.unpackLONG( ret[4] )
                    print ret
                    if ret != 0:
                        self.log(self.getline(), self.failed )

                    ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    if ret[2] != sd:
                        self.log(self.getline(), self.failed )
                    if ret[1] != 0: # connected !!!
                        self.log(self.getline(), self.failed )


                    # check errno  = BSD_EISCONN
                    ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_ERROR, 4)
                    if( ret[0] == False ):
                        self.log(self.getline(), self.failed )
                    ret = utils.unpackUSHORT( ret[4][:2] )
                    print ret
                    if ret != 0:
                        self.log(self.getline(), self.failed )

                    i = (NUM_OF_LOOP * 3)

            else: # timeout
                ret = self.slBsdHandle.SendTo( udpSd, len(DATA + str(i)), 0, DATA + str(i), slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )

            i = i + 1

        if i == NUM_OF_LOOP: # not connected
            self.log(self.getline(),self.failed  )


        #connected send data on tcp socket+ wait to reply
        TEST0 = "TEST0" +  self.testName + "&&&"

        ret = self.slBsdHandle.Send( sd, len(TEST0), 0, TEST0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        time.sleep(1)
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD, 0 )

        if( ret[0] == False ):
            self.log(self.getline(),self.failed  )
        else:
            #print ret
            if sd == ret[2] and len(TEST0) == ret[1] and TEST0 == ret[3]:
                pass
            else:
                self.log(self.getline(),self.failed  )

        #send end of test
        time.sleep(0.3)
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)
        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( udpSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(udpSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )



    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



