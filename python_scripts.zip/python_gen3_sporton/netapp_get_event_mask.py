
import sys
import time
import TICore
import configurations as conf
import string
import options
import struct


def netapp_get(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: status = 0
    #            app ID: HTTP = 1, DHCP = 2
    #            configOpt = 0 (Basic)
    #            Config  Len = 0

    core.InvokeSLCommand("NETAPP", "NETAPPGET",2, 0, 4, 2, 0)


    retVal,Data = core.waitEvent("cc_NETAPP_NETAPPGETRESPONSE",[],5000)
    print("retVal: {0} ; Data: {1}".format(retVal,Data))

    print("Satus %d \n  "%( int(Data[4])))

    BufferStr = Data[8]

    Res =struct.unpack('<l', (BufferStr)[0: 4])
    #IP = IP[::-1]


    print("event mask 0x%x \n"%(Res[0]))

    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPGET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_get(Opts)