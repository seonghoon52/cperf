
NWP_version = [3,0,77,66]
MAC_version = [1,0,0,17]
PHY_version = [2,1,0,7]
NWP_PATCH_version = [2, 2, 0, 2]
MAC_PATCH_version = [1, 2, 0, 2]
PHY_PATCH_version = [1, 0, 3, 23]