
import sys
import time
import TICore
import configurations as conf
import string
import options


def netapp_set(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))




    core.InvokeSLCommand("NETAPP", "NETAPPSET_EVENT_MASK",2, 0, 4, 2, 4, sys.argv[1])


    core.waitEvent("cc_NETAPP_NETAPPSETRESPONSE",[],5000)
    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPSET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_set(Opts)