
import sys
import time
import TICore
import configurations as conf
import string
import options


def netapp_stop(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: app ID: HTTP = 1, DHCP = 2, MDNS = 4, DNS = 8
    core.InvokeSLCommand("NETAPP", "STOP_COMMAND",2, 2)


    #core.waitAndPrintAnyEvent()

    core.waitEvent("cc_NETAPP_STOP_RESPONSE",[],5000)
    #core.waitAndPrintAnyEvent()
    
    core.close()
    sys.exit("STOP")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_stop(Opts)