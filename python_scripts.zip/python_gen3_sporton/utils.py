import msvcrt
import binascii
import struct

BSD_SOCKET_ID_MASK = 0x0f

def swap16( var ):
    return struct.unpack( '>H', (struct.pack('H', var)))[0]
def swap32( var ):
    return struct.unpack( '>L', (struct.pack('L', var)))[0]


def rotate_ipv4_endian(IpString):
    parts = IpString.split(".")
    #print parts
    x = parts[3] + "." + parts[2] + "." + parts[1] + "." + parts[0]
    return x

def rotate_ipv6_endian(IpString):
    parts = IpString.split(":")
    roataeIpv6 = ""
    while parts:
        x = parts[0:4]
        roataeIpv6 = roataeIpv6 + parts[3] + ":" + parts[2] + ":" + parts[1] + ":" +  parts[0] + ":"
        parts = parts[4:]
    roataeIpv6 = roataeIpv6[:-1]

    return roataeIpv6


def getIpHexStr(IpString, swap = True ):
    if swap == True:
        IpString = rotate_ipv4_endian(IpString) #roatate endian
    else:
        pass
    parts = IpString.split(".")
    return ':'.join((hex(int(i))[2:] for i in parts))

#convert dec to hex with no 0x
def dec2cleanHex(n):
    return hex(n).replace('0x', '')

#convert string to hex
def str2HexPadded(s,pad):
    lst = []
    y = 0
    for ch in s:
        hv = hex(ord(ch)).replace('0x', '')
        if len(hv) == 1:
            hv = '0'+hv
        lst.append(hv+':')
        y = y+1

    while y < pad:
        y = y+1
        lst.append('00:')

    return reduce(lambda x,y:x+y, lst)

def str2HexStr(Str):
    binStr = binascii.a2b_hex(Str)
    s = ''
    for b in binStr:
        s += binascii.b2a_hex(b) + ':'
    s = s[:-1]
    return s

def getIpHexNum(IpString):
    parts = IpString.split(".")
    outStr = ''
    for numStr in parts:
        num = hex(int(numStr))[2:]
        outStr = outStr + num.rjust(2,'0')
    return int(outStr,16)

def waitForEscKeypress():
    print "\n\n\npress 'escape' to quit...\n\n\n"
    while 1:
        char = msvcrt.getch()
        if char == chr(27):
            break
        time.sleep(1)

def getPortHexStr(port, swap = False):
    if swap == True:
        tmp = "".join(hex(swap16(int(port))))
    else:
        tmp = "".join(hex(int(port)))
    tmp = tmp[2:]
    tmp = tmp.zfill(4)
    tmp = '0x' + tmp
    return tmp[4:] + ':' + tmp[2:4]


def ipv6GetUlong( ipv6, index ):  # ipv6 compose from ulong addresses, get ulong  according to index (0-3)
    if( index > 3 or index < 0 ):
        print 'ERROR index'
        exit()
    # convert IPV6 foramt to fulll string froamt,  32 bytes without any ':'
    ret = ''
    ipv6 = ipv6.replace('::', ':*:')
    x = ipv6.count(':')
    str = ipv6.split(':')
    for s in str:
        if s == '*':
            s = ''
            ret = ret + s.zfill( (8 - x )*4 )  # replace the number of zero that '::' means
        else:
            ret = ret + s.zfill( 4 )  # expand to 4 bytes string

    # ipv4 address according to index and return hex format
    x = '0x' + ret[(index *8):(index *8) + 8]  # convert to hex
    return hex(int(x,0))


def CheckIpv6Format( address ):  # check if address is ipv6 format
    if( address.count(':') > 1 ):
        return 1
    return 0

def ipv6ExtractToPoprietyFullAddress( ipv6, swap = True  ): # extract IPV6 format with XX:XX::XX:XX to full adrres x:x:x:x:x:x:x:x......
    tmp = ''
    ipv6 = ipv6.replace('::', ':*:')
    x = ipv6.count(':')
    str = ipv6.split(':')
    for s in str:
        if s == '*':
            s = ''
            tmp = tmp + s.zfill( (8 - x )*4 )  # replace the number of zero that '::' means

        else:
            tmp = tmp + s.zfill( 4 )  # expand to 4 bytes string
    tmp.replace(':', '')  #remove all :
    y = 0
    ipv6Propriety = ""  #add : between two char
    while  y < 32:
        ipv6Propriety = ipv6Propriety + tmp[y:y+2] + ':'

        y = y + 2
    ipv6Propriety = ipv6Propriety[:-1]  # remove last :
    if swap == True:
        ipv6Propriety =  rotate_ipv6_endian(ipv6Propriety)  # rotate endian
    else:
        pass
    return ipv6Propriety


def convert_to_propriety_long( number ):  # expand to 4 bytes, with : seperator
    s = "%"+str(8) + "X"
    s = (s % number).replace(' ', '0')
    #s = ":" + s[:2] + ":" + s[2:4] + ":" + s[4:6] + ":" + s[6:8]  BIG_ENDIAN
    s = ":" + s[6:8]  + ":" + s[4:6] + ":" + s[2:4] + ":" +  s[:2]  #LITTLE_ENDIAN
    s = s.replace(':0', ':')
    s = s[1:]
    return s

def convert_to_propriety_sort( number ):  # expand to 2 bytes, with : seperator
    s = "%"+str(4) + "X"
    s = (s % number).replace(' ', '0')
     #s = ":" + s[:2] + ":" + s[2:4]  BIG_ENDIAN
    s = ":" + s[2:4] + ":" + s[:2]  # LITTLE_ENDIAN
    s = s.replace(':0', ':')
    s = s[1:]
    return s

def unpackLONGLONG( data ):
    ret = struct.unpack("ll",data)
    return (ret[0], ret[1])


def unpackLONG( data ):
    ret = struct.unpack("l",data)
    return ret[0]

def unpackULONG( data ):
    ret = struct.unpack("L",data)
    return ret[0]

def unpackSHORT( data ):
    ret = struct.unpack("h",data)
    return ret[0]

def unpackUSHORT( data ):
    ret = struct.unpack("H",data)
    return ret[0]

def unpackBYTE( data ):
    ret = struct.unpack("b",data)
    return ret[0]

def unpackUBYTE( data ):
    ret = struct.unpack("B",data)
    return ret[0]

def unpackUBYTE_UBYTE_UBYTE_UBYTE( data ):
    ret = struct.unpack("BBBB",data)
    return (ret[0], ret[1], ret[2], ret[3])

#----  For select   -------------
def FD_ZERO():
    return 0

def FD_SET( fd, fdset):
    #fd =  fd % 32
    fdset = fdset | (1<< (fd & BSD_SOCKET_ID_MASK))
#   print hex(fdset)
    return fdset

def FD_CLR( fd, fdclr):
    #fd =  fd % 32
    fdclr = fdclr & ~(1<< fd)
#    print hex(fdclr)
    return fdclr

def FD_ISSET(fd, isset):
    #fd =  fd % 32
    if isset & (1<< (fd & BSD_SOCKET_ID_MASK) ):
    #if isset & (1<< (fd ) ):
        return 1
    return 0
#-------------------------------

def removeIpv6IntefaceSuffix(addr):
    i = 0
    x = 0
    while( i < len(addr) ):
        if addr[i:i+1] == "%":
            x = i
            return addr[0:i]
        i = i + 1
    return addr
