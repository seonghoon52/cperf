
import sys
import time
import TICore
import configurations as conf
import string
import options
import binascii
import msvcrt

def wait_for_async_event(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))
    core.waitAndPrintAnyEvent()
    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    wait_for_async_event(Opts)