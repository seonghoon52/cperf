#-------------------------------------------------------------------------------
# Name:        test_cmd_self.slBsdHandle.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import BsdUtils
import BSD_Test_configurations as slConf
import BSD_Test_base
import socket
import select
import struct



class BsdTestTcpRecv(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None , TestLinger = 0  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecv", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"
        self.TestLinger = TestLinger


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data1_1460 )
        if privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP) != self.data1_1460:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        privateSd.send( "*" )
        if privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP) != "*":
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )

        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        privateSd.send( self.data_2 )

        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP)
        if rdata.find(self.sync3) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # Third test 2 buffer from differnet source port  < payload
        privateSd.send(self.data_3_0 )
        privateSd.send(self.data_3_1)



        # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        if( self.TestLinger ):
            LINGER_ON = 1
            LINGER_TIME = 10 #seconds
            self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_LINGER, 8, utils.convert_to_propriety_long(LINGER_ON) + ":" +  utils.convert_to_propriety_long(LINGER_TIME))
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1460) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1460:
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len("*") or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != "*":
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Send( sd, ret[1], 0, ret[3] )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # second test buuffer recive < payload read 3 iteration

        # read only 2 bytes
        ret = self.slBsdHandle.Recv( sd, 2, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 2 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[0:2]:
            self.log(self.getline(), self.failed )
        # read only 3 bytes
        ret = self.slBsdHandle.Recv( sd, 3, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3 or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[2:5]:
            self.log(self.getline(), self.failed )

        # read the exactly the rest
        ret = self.slBsdHandle.Recv( sd, len(self.data_2) - 5, 0)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_2) - 5) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != self.data_2[5:]:
            self.log(self.getline(), self.failed )

        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync3), 0, self.sync3)
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        # Third test 2 buffer from differnet source port  < payload 2 reads 3

        # first packet from pc mng prot

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (len(self.data_3_0) +  len(self.data_3_1 )) or ret[2] != sd:
            self.log(self.getline(), self.failed )

        if ret[3] != (self.data_3_0 + self.data_3_1):
            self.log(self.getline(), self.failed )



        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )
        if( ret[1] < 0 ):
            self.log(self.getline(),self.failed, str(sd) )
        if( ret[2] != sd ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



class BsdTestTcpRecvNonBlocking(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecvNonBlocking", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        x = rdata.find(self.sync1)
        if rdata.find(self.sync1) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data1_1460 )


        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        x = rdata.find(self.sync2)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # second test buuffer recive < payload read 3 iteration
        # read only 2 bytes
        privateSd.send( self.data_2 )

        # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync by tcp connection
        # first test  call rev with no wait flag
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, BsdUtils.MSG_DONTWAIT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )

        # sync
        ret = self.slBsdHandle.Send( sd, len(self.sync1), 0, self.sync1 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1460) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1460:
            self.log(self.getline(), self.failed )


        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_NONBLOCKING, 4, utils.convert_to_propriety_long(1) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # test  call rev no data , should return
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )


        #sync again
        ret = self.slBsdHandle.Send( sd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()





class BsdTestTcpRecvTimeOut(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpRecvTimeOut", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "itqpUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        x = rdata.find(self.sync1)
        if rdata.find(self.sync1) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data1_1460 )


        # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVTIMEO, 8, utils.convert_to_propriety_long(1) + ":" +  utils.convert_to_propriety_long(0)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # now pc and sl are sync by tcp connection
        # first test  call rev with no wait flag
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != BsdUtils.BSD_EAGAIN or ret[2] != sd:
            self.log(self.getline(), self.failed )

        # sync
        ret = self.slBsdHandle.Send( sd, len(self.sync1), 0, self.sync1 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)

        # recv data non blocking flag, now data exist
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1460) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1460:
            self.log(self.getline(), self.failed )

        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        time.sleep(0.5)


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()


class BsdTestTcpServerClose(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpServerClose", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data_2 )
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        time.sleep(2)
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 0:
            self.log(self.getline(), self.failed )


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()




class BsdTestTcpServerCloseRST(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpServerCloseRST", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data_2 )
        l_onoff = 1
        l_ligner = 0
        privateSd.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii',l_onoff, l_ligner))
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        time.sleep(2)
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error

        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 0:
            self.log(self.getline(), self.failed )


        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()




class BsdTestTcpClientClose(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientClose", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 120:
                    print e
                    s.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(0.2)
        time.sleep(1) # let set sockopt after accept
        s.send(self.data_2)
        s.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec


        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != privateSd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error

        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 0:
            self.log(self.getline(), self.failed )


        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpClientCloseRST(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientCloseRST", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 120:
                    print e
                    s.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(0.2)
        l_onoff = 1
        l_ligner = 0
        s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii',l_onoff, l_ligner))

        s.send(self.data_2)
        s.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )

        time.sleep(3)

        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != privateSd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data_2:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error

        ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 0:
            self.log(self.getline(), self.failed )


        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()





class BsdTestTcpServerCloseWithSelect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpServerCloseWithSelect", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data_2 )
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)


        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()


class BsdTestTcpServerCloseWithSelectRST(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpServerCloseWithSelectRST", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.sync3 = "sync number 3"
        self.sync4 = "sync number 4"
        self.data1_1460 = "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1460) != 1460:
            self.log(self.getline(), self.failed )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"
        self.data_3_0 = "This is test sel.data_3_0 UUUUUU"
        self.data_3_1 = "sel.data_3_1 - !!!!!!TTT"
        self.data_4_0 = "QQ-This is test sel.data_4_0 UUUUUU"
        self.data_4_1 = "RR-sel.data_4_1 - !!!!!!TTT"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)


        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        # first test  max paylaod 1472 and buffer recv > paylaod
        privateSd.send( self.data_2 )
        l_onoff = 1
        l_ligner = 0
        privateSd.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii',l_onoff, l_ligner))
        privateSd.close()
        sd.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        time.sleep(3)
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != sd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( sd, fdset)
        ret = self.slBsdHandle.Select(sd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( sd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()





class BsdTestTcpClientCloseWithSelect(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientCloseWithSelect", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)


    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 120:
                    print e
                    s.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(0.2)
        time.sleep(1) # let set sockopt after accept
        s.send(self.data_2)
        s.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )

        # recv with non blocking by set sock opt
        ret = self.slBsdHandle.SetSockOpt( privateSd, BsdUtils.SOL_SOCKET, BsdUtils.SO_RCVBUF, 4, utils.convert_to_propriety_long(9999)) # sec , micro sec


        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != privateSd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )


        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()


class BsdTestTcpClientCloseWithSelectRST(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpClientCloseWithSelectRST", slBsdHandle, fileHandle )
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"

    def __del__(self):
        #print "BsdTestUdpConnect destructor"
        BSD_Test_base.BsdTestBase.__del__(self)


    def PC(self):
        self.log(self.getline(), self.start )

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, s.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR) | 1)
        try:
            s.bind((slConf.PC_IPV4, int(slConf.PC_PORT)))
        except Exception, e:
            print e
            s.close()
            self.log(self.getline(), self.failed )
        loop = 1
        while loop > 0:
            try:
                s.connect((slConf.SL_IPV4, int(slConf.SL_PORT)))
                loop = 0
            except Exception, e:
                if loop > 120:
                    print e
                    s.close()
                    self.log(self.getline(), self.failed )
                else:
                    #print "loop ", loop
                    loop = loop + 1
                    time.sleep(0.2)

        l_onoff = 1
        l_ligner = 0
        s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii',l_onoff, l_ligner))
        s.send(self.data_2)
        s.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET, slConf.SL_PORT )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Listen( sd, 2 )
        if( ret[0] == False ):
                 self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Accept( sd, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        else:
            privateSd = ret[1]
            if False == self.checkSocketRange( privateSd ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if ret[3] != slConf.AF_INET:
                self.log(self.getline(), self.failed )
            if ret[4] != slConf.PC_PORT:
                self.log(self.getline(), self.failed )
            if ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )

        time.sleep(2)

        # client connected , send and recv data
        # First time data should recv althouh server already close connection
        # first test  max paylaod 1460 and buffer recv > paylaod
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != len(self.data_2) or ret[2] != privateSd:
                    self.log(self.getline(), self.failed )
                if ret[3] != self.data_2:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )


        # recv again server already close the connection, recv should return with error
        fdset = utils.FD_ZERO()
        fdset = utils.FD_SET( privateSd, fdset)
        ret = self.slBsdHandle.Select(privateSd + 1, 1, fdset, 0, 0, 0, 0, 2000, 5000  ) # no timeout
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] > 0: # select status  > 0 means no timeout
            status = utils.FD_ISSET( privateSd, ret[3] )
            if status == 1:
                ret = self.slBsdHandle.Recv( privateSd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
                if( ret[0] == False ):
                    self.log(self.getline(), self.failed )
                if ret[1] != 0:
                    self.log(self.getline(), self.failed )
        else:
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( privateSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(privateSd) )

        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )


        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def run(self):
        if self.slBsdHandle != None:
            self.SL()
        else:
            self.PC()



class BsdTestTcpMss(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpMss", slBsdHandle, fileHandle)
        self.data1_1440 = "7C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L"
        if len(self.data1_1440) != 1440:
            self.log(self.getline(), self.failed )
        self.MAXSEG = 100

    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.listen(3)

        # sync between sl and by accept

        privateSd, addr = sd.accept()
        # now pc and sl are sync
        aggData = ""
        loop = True
        while loop:
            rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP)
            aggData = aggData + rdata
            if aggData == self.data1_1440:
                loop = False
            else:
               # print len(aggData)
               pass

        privateSd.send(aggData)

        rdata = privateSd.recv(self.MAX_PAYLOAD_IPV4_TCP)
        if rdata != self.endSyncMsg:
            self.log(self.getline(), self.failed )

        #close sockets
        privateSd.close()
        sd.close()

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )

    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]

        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != 0:
            self.log(self.getline(), self.failed )



        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( sd, slConf.AF_INET, slConf.PC_PORT, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != 1460:
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.SetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4, utils.convert_to_propriety_long(self.MAXSEG) )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.GetSockOpt( sd, BsdUtils.SOL_SOCKET, BsdUtils.SO_MAXSEG, 4 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        ret = utils.unpackLONG( ret[4] )
        print ret
        if ret != self.MAXSEG:
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Send( sd, len(self.data1_1440), 0, self.data1_1440 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        # test  max paylaod 1440 and buffer recv > paylaod
        ret = self.slBsdHandle.Recv( sd, self.MAX_PAYLOAD_IPV4_TCP, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data1_1440) or ret[2] != sd:
            self.log(self.getline(), self.failed )
        if ret[3] != self.data1_1440:
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( sd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #time.sleep(0.5) - not use timeout to check other size recv although immidetly close



        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()


## Aggregation tests


class BsdTestTcpAggregation(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestTcpAggregation", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.DATA_6529= "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L4D5QIZ4MEB53"
        self.DATA_6529 = self.DATA_6529+ "3h2323errrr333ed43hc3333dhff6gdffffhgfyrfff6fy9ffff8ff000040f080f0dfws8s0df9sd0f9sTestsel.data_2-checkit!@#$%%56jdsfbh237sdcvhasd werf897erf79y93yreyrf9sdfgvywe89yf789erfywer79fyh349-yfvye79rty89dfvya9wehdfwgnm238r5yqfguq9yrt97q4vhw3789fyhv34789vh34789fh3478y378fy3478vyw78vy378fy39ry29-ry9fy34789fyh34789fh3789hf34789vh5897vh3789fhv378fyh578fh34789fh34789fyh54f789h34f78h34f9739dfgvyse9rv  df -r u9dvn wsd7fy89 n98237c4 9    8w37rcqw890ey7r-12387cn 9ewyf uisdhfuy8qwefyhq93rfye9yf1239-8ua[PCKDM `478 89YDCA79WEYR `89Y489Q WYDF89Q34Y7T348 78ERYFASDUIHCV34789RY34 FYSDY129-RYE9R8YFER89YF914E4[  9U CZDFFN123789DH HCV3478FY3478 FYQCY3478FY3478 FY 9FY139 4RY QWEYFQ78934YFHIO12RGY-`-27R3479YR3478Y4789YCVYXD897FVYER789FYQ34R5Y34YRRNX CWE89Y V47R7834YR7813YR-ADAFU NQWEHBDC 238DHQW78D N784F2780RYQ0W7YD C  OAUYS F13478RH134R3478RTY2 BWEDB47RGF23 F34 -0Y FQ23481TY Q368  23T RTG346TR34RT 8334R7834YR780134YR80347YRQ78FYHB4 CF364TFG346TF 346TRF 3468TF 13468RT 348R 31478TY 13478R 13478YR Q78WEYF 3Q2C8213HD 34CG347B368R7"
        self.DATA_6529 = self.DATA_6529 +  "SADSDFSD9-FVIW939-4I9349-R CI,    WE90RI 3489034890 U 3UF890ASDUF890ASDUF890SDFUR C890QSUJDs)FUI 1 WDUA90SDJFKQ23OIRCM 340T81=348R18903478580Q34RT0134URM 34R81 08R5051394R5 13890T 3V4RT893 8934789 374R897348RT738947RT8934R7 8934YRTF 78934YRT7893T784Y5T789YT789Y54 9Y13489RY 1349RY 34789RY 3497YR 1394UYR3489 7R89-37R NE0F8D N14R908CM E09R8WQER23E802UE08237889237897WEDF6 234 `2942Y3R790234T347Y`289-7R 8234N R3417R61347890R6`2-4=23R78QBNRFY-9WE RB236 N2736E789y6r aer79fy7er79fg659t7349y7ernc89erpf 134[r'0134 ur[134r78 ane796f-123r67bp aa;A7    P2374Q0 B4R60346RB NPQN 4R  P w;R71P3274WE- B13409R6 1347RY NP;AWr;/q4thr 134-WEUG[WTMNGWNV-348=34TU [GY75489-T734-9T7QP9TN7 T7134[TP-7T7PT34BT63478B 23478R6 B0349R8734H 780346HR5 PA47 R5HQ   23479H 1349P8H 437975 B3476 178034 613478 0 R6JN34P98R57 JN134786 H37846H 1347806 782346 B08137265 B1347805 6BN 1P56 BQWEKL ILWRLTH54Y9O1239    BWER6Y3478RT3478T63478T674TG677892346T347863478T613478 13478RY 87;OADFUYF3409RT7R57 9327947809234Y667802346023967723967123657189236"
        self.DATA_6529 = self.DATA_6529 +  "das diasedfjkir90w    ir923i2390riw90ei ,sd90fiaergikg-i  2390ruj3490uj890gu890gu890gu90gui90gbui90gvuqef890u5tu90tufu890fuzsdf90rieg9054ut2=90uti590tit90vuid80fug0w49ugj3590gj3vcj34=0ru3490ui340uj80vjh489vjh50vu590fvuj5490vu50vu50u34901=cjmn v34h  4w3-eri  `4  =09W3RI34=95I92=T5I9 Q3459 ]FzsdFEDFAWERRF9054 =9T854890 T45TUTU245UTQ90WUFDFJG=034TYI82459YI88YI4905Y5UT5U54TUUAS FQ93FQ-WERT348T5=349T8RQ90 E4UMT23480TU Q384U5 01348U5 134895U 1=435U 348-5 U13458 134058U 1340=58 1349058 103485 90834905 8151349058 134=958 134=9058 134=958 1349058 1=4985 1=9034581=903458 9013458901 8345=91834 5901F90SDUI09WER8ER=9T8WER=-9T8WER9T8WER90T8W=90ERT8=WER9T8WE9R8T90WER8T90ER8T=W9E9RT8 M134805U 18345 1=94358 193485 134958 1490358 1349058 =34085 1903485 90AWE0RHWE WER  34T890FGT90  232389TRG3489VBUJHR489WGU8934U895U89FU890RTKWERJKOJKLERJIOERSJIOWERI0RG80WE5854UIODJIOEFAJIOJIOWEIOU80RRTG90JL43JKLDFKLDFSRIERIOIOEGIOGGTG89RTG89RTG89RTG89RTG8989RTG89RTG8989T789RT8989WER89WERTWERTGW54TY54Y90YR09TGI90W4TGUI9023UT945JTG8"
        self.DATA_6529 = self.DATA_6529 +  "AsDUIASDF89AERUFG890U0U QWET89U89T U3489UTU8 E90RGU890SERUG890SDFJV 090UI90DFGB890S=098U890DGU80U880U85U89UV89TVW79Y785VH578VH78FY578Y789Y78Y57Y789VY57895FY5789GY5789Y5789Y5789Y578Y378Y7Y785TY895Y5789Y5789Y5789Y59TU754 Q384QE8944TU7Q2=-8-0-8FD-GW8-ERTU789TU7895N 34 3478YR9- 134UY89-2USADUQ23[R5T-082340T8920 N34789TY 7945YT 7834YT 78934TU7892347T89T7GH8H880ERG5890GTG54U45G8945GU45G895UG895UYGGUYUYGQ2-2Q--9-8EDFYUQ7894FYU34789FUY34789FUY37894YFU78934FUY78934YF7834FY34789YF7834YR734YF78Q3Y4RF7831F09384FU3489FUY78934FUY SDIF 8R 789ASEFDYQ -R8 U134-8RU QORU891234RU-134589Q34793478RY34780RY3478FH34 34D1789 Y12379ERY 19034YR7934YR3478RY3478RY3478RY3478RYF3478FHUIFH 14789RY 78QW4YR 1342789RY 143Y7RY QW7903YER7 2Y134787813413478134780QF78FY7Y7ASE;KSDR;AW3topq34u-47r91348uy 789234ry A dq34-r7 q90348r 34789 134t78y3478rty1340t0q;awtpy-0tq-t134-tart]q34tu=t=54tg[h34f-4-13-4rfy4783y78fy78qwyer67dt b   23r 67234rg0 34yrq3489t7-t8-9erf7uqer89fgu3489tu73489qt 3478ry7834ry3478ry3478ry3478ry3478ry340r347ry3478ry3"
        self.DATA_6529 = self.DATA_6529 +  "asdfiosdfuwer890uf89  23ur    2389u   983ud89we d9    23e8923 r89q34ur=9034ufiovnlasdk fna'ASDCASKOFWEIOJ23489RU489   3U DQ89us 8UWD890   23UR=3409TIE GRTGJK[54GJK5490U5489U5T54YF78ERWHF78FH 7834HF7834YF7834YF-2R= 34RFNQE89FUER89-FU3489TYF54BHERYIFG7834RT-34789YRF-9ERFYAS7 FNA[-04TU54]=0U93T2489Y1T7934YQT78WECH dcNJQLRF7348CJQ78943R 81YRT789WT 341[-9E78FYH 9-QAHRF=-  1T4=5UYHW[THJ5454G9Q348Y784FYQER78FY7 Q-34R 8943 P8RTVJ L;34KQJTF8 NUG89UY 35T  A4EF9Y 54T9-YYQ[T8YDF 9G5 J4U6UOK7K78UOPTR054UT895TU A49TY Q34TY TY9- TU -W5TU 5T89U2-Q 34TW54UT -9E8TU 2-85UT-W95UT58 W49-TU 489-TJ54GJT558JW54GJ-W3TGU489FJ54TG54GW9P JTY-=W54T W=-5T4 =-W54T W54U W54TY9U W54UY 54U W8954U T-W95UYW-54YUW54UY W84Y4892-5UY W854UY W54U W54UTW89JKG WI[54Y IS09DTUI5689 Y03UW54 [W54Y [W54YJ UW54TY-U JW54Y89-W54 9W54T89U W54TUW89 T5U W89-TUW5 4T89U89-U R-98TGUW59 4G9SERUG W['TOP IW=456T2568 MWUT5YU8T8RHUY89-TJDTYJK-0SDTFUIG[AS 4 TAW34;T5OJ W-T5J 54TJ894JY5YJ8 DSRT3'5YJ56890UZ0RFGW98-RTUW54U T54UJ89UW54TW45TUW-45FYHJ]UYKIUYK-I9UY"
        if len(self.DATA_6529) != 6529:
            self.log(self.getline(), self.failed )

        self.data_1 = "qwerty56"
        self.data_2 = "Test sel.data_2 - check it !@#$%%^^"


    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sd.bind((slConf.PC_IPV4, int(slConf.PC_PORT) ))
        sd.connect((slConf.SL_IPV4, int(slConf.SL_PORT) ))

        # open sync socket
        syncSd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        syncSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
        syncSd.listen(3)
        # sync between sl and by accept
        privateSd, addr = syncSd.accept()
        # now pc and sl are sync
        sd = privateSd # RxAggr, use mgmt socket
        # first test  max paylaod 6529
        sd.send( self.DATA_6529 )
##        time.sleep(3.5)  # RxAggr, must be here
##        sd.send(self.data_1)
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.sync1) == -1:
            privateSd.close()
            syncSd.close()
            self.log(self.getline(), self.failed )

        sd.send( self.DATA_6529 )
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.sync2) == -1:
            privateSd.close()
            syncSd.close()
            self.log(self.getline(), self.failed )

        sd.send( self.data_2 )

         # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            syncSd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        syncSd.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        syncSd = ret[1]
        ret = self.slBsdHandle.Bind( syncSd, slConf.AF_INET,  self.mngPort )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        sd = syncSd


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( syncSd, slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != syncSd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync
        time.sleep(3)
        readData =""
        # READ DATA_6529
        ret = self.slBsdHandle.RecvFrom( sd, 3500, 0, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3500 or ret[2] != sd or ret[3] != slConf.AF_INET or ret[5] != slConf.PC_IPV4:
            print "ret[1] ", ret[1]
            print "sd ", ret[2]
            print "slConf.AF_INET ", ret[3]
            print "int(slConf.PC_PORT) ", ret[4]
            print "slConf.PC_IPV4 ", ret[5]
            self.log(self.getline(), self.failed )
        readData = readData + ret[6]
        print "\n\nreadData ", len(readData)
        while( len(readData) < len(self.DATA_6529) ):
            ret = self.slBsdHandle.RecvFrom( sd, self.MAX_PAYLOAD_IPV4_TCP, 0, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd or ret[3] != slConf.AF_INET or ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )
            readData = readData + ret[6]
            print "\n\nreadData ", len(readData)
        # Compare data
        if readData != self.DATA_6529:
            self.log(self.getline(), self.failed )

##        ret = self.slBsdHandle.RecvFrom( sd, self.MAX_PAYLOAD_IPV4_TCP, 0, slConf.AF_INET )
##        if( ret[0] == False ):
##            self.log(self.getline(), self.failed )
##        if ret[1] != len(self.data_1) or ret[2] != sd or ret[3] != slConf.AF_INET or ret[4] != int(slConf.PC_PORT) or ret[5] != slConf.PC_IPV4:
##            self.log(self.getline(), self.failed )
##        if ret[6] != self.data_1:
##            self.log(self.getline(), self.failed )


        # sync other side
        ret = self.slBsdHandle.Send( syncSd, len(self.sync1), 0, self.sync1 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )



        readData =""
        # READ DATA_6529
        ret = self.slBsdHandle.RecvFrom( sd, 21, 0, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 21 or ret[2] != sd or ret[3] != slConf.AF_INET  or ret[5] != slConf.PC_IPV4:
            self.log(self.getline(), self.failed )
        readData = readData + ret[6]
        print "\n\nreadData ", len(readData)
        # aggregation NOT expected - sincelast packet was with odd size
        ret = self.slBsdHandle.RecvFrom( sd, 3500, 0, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != (self.MAX_PAYLOAD_IPV4_TCP-21) or ret[2] != sd or ret[3] != slConf.AF_INET  or ret[5] != slConf.PC_IPV4:
            print "ret[1] ", ret[1]
            print "sd ", ret[2]
            print "slConf.AF_INET ", ret[3]
            print "int(slConf.PC_PORT) ", ret[4]
            print "slConf.PC_IPV4 ", ret[5]
            self.log(self.getline(), self.failed )
        readData = readData + ret[6]
        print "\n\nreadData ", len(readData)
        ret = self.slBsdHandle.RecvFrom( sd, 3500, 0, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != 3500 or ret[2] != sd or ret[3] != slConf.AF_INET  or ret[5] != slConf.PC_IPV4:
            self.log(self.getline(), self.failed )
        readData = readData + ret[6]
        print "\n\nreadData ", len(readData)
        while( len(readData) < len(self.DATA_6529) ):
            ret = self.slBsdHandle.RecvFrom( sd, self.MAX_PAYLOAD_IPV4_TCP, 0, slConf.AF_INET )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != sd or ret[3] != slConf.AF_INET  or ret[5] != slConf.PC_IPV4:
                self.log(self.getline(), self.failed )
            readData = readData + ret[6]
            print "\n\nreadData ", len(readData)
        if readData != self.DATA_6529:
            self.log(self.getline(), self.failed )


        # sync other side
        ret = self.slBsdHandle.Send( syncSd, len(self.sync2), 0, self.sync2 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.RecvFrom( sd, self.MAX_PAYLOAD_IPV4_TCP, 0, slConf.AF_INET )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.data_2) or ret[2] != sd or ret[3] != slConf.AF_INET  or ret[5] != slConf.PC_IPV4:
            self.log(self.getline(), self.failed )
        if ret[6] != self.data_2:
            self.log(self.getline(), self.failed )

         #exit test
        ret = self.slBsdHandle.Send( syncSd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )




        #close sockets

        ret = self.slBsdHandle.Close( syncSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(syncSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()


############################

class BsdTestBindRules(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestBindRules", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"

    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        syncSd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        syncSd.bind((slConf.PC_IPV4, int(self.mngPort) ))
        syncSd.listen(3)
        # sync between sl and by accept
        privateSd, addr = syncSd.accept()
        # now pc and sl are sync

         # wait to end of test msg
        #sync again
        rdata = privateSd.recv(self.MAX_PAYLOAD)
        if rdata.find(self.endSyncMsg) == -1:
            privateSd.close()
            syncSd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        syncSd.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()

        # open udp and tcp ipv4 bind bind any same port should suucess
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd0 = ret[1]
        ret = self.slBsdHandle.Bind( sd0, slConf.AF_INET,  5000 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != 0 ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd0 ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd1 = ret[1]
        ret = self.slBsdHandle.Bind( sd1, slConf.AF_INET,  5000 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != 0 ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd1 ):
            self.log(self.getline(), self.failed )

        # open more socket tcp ipv4 bind any anothr port should be ok

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd2 = ret[1]
        ret = self.slBsdHandle.Bind( sd2, slConf.AF_INET,  5001 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != 0 ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd2 ):
            self.log(self.getline(), self.failed )


        # open more socket udp ipv4 bind any anothr port should be ok

        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd3 = ret[1]
        ret = self.slBsdHandle.Bind( sd3, slConf.AF_INET,  5001 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != 0 ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd3 ):
            self.log(self.getline(), self.failed )


        # open more socket tcp ipv4 bind any with same port should failed
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd4 = ret[1]
        ret = self.slBsdHandle.Bind( sd4, slConf.AF_INET,  5001 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != BsdUtils.BSD_EADDRINUSE ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd4 ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Close( sd4 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd4) )

        # open more socket udp ipv4 bind any with same port should failed
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd4 = ret[1]
        ret = self.slBsdHandle.Bind( sd4, slConf.AF_INET,  5001 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != BsdUtils.BSD_EADDRINUSE ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd4 ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Close( sd4 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd4) )


        # open more socket tcp ipv6 bind any with same port should failed
        ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd4 = ret[1]
        ret = self.slBsdHandle.Bind( sd4, slConf.AF_INET6,  5001 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != BsdUtils.BSD_EADDRINUSE ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd4 ):
            self.log(self.getline(), self.failed )

        ret = self.slBsdHandle.Close( sd4 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd4) )


        # open more socket tcp ipv6 bind specific local with same port failed
        ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd4 = ret[1]
        ret = self.slBsdHandle.Bind( sd4, slConf.AF_INET6,  5001, conf.LOCAL_IPV6_ADDR )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != BsdUtils.BSD_EADDRINUSE ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd4 ):
            self.log(self.getline(), self.failed )

        # open more socket tcp ipv6 bind specific global  with same port failed
        ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd5 = ret[1]
        ret = self.slBsdHandle.Bind( sd5, slConf.AF_INET6,  5001, conf.GLOBAL_IPV6_ADDR )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if( ret[1] != BsdUtils.BSD_EADDRINUSE ):
            self.log(self.getline(), self.failed )
        if( ret[2] != sd5 ):
            self.log(self.getline(), self.failed )


        ret = self.slBsdHandle.Close( sd0 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd0) )
        ret = self.slBsdHandle.Close( sd1 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd1) )
        ret = self.slBsdHandle.Close( sd2 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd2) )
        ret = self.slBsdHandle.Close( sd3 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd3) )
        ret = self.slBsdHandle.Close( sd4 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd4) )
        ret = self.slBsdHandle.Close( sd5 )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd5) )

        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        syncSd = ret[1]
        ret = self.slBsdHandle.Bind( syncSd, slConf.AF_INET,  self.mngPort )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        sd = syncSd


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( syncSd, slConf.AF_INET, self.mngPort, slConf.PC_IPV4 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != syncSd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

         #exit test
        ret = self.slBsdHandle.Send( syncSd, len(self.endSyncMsg), 0, self.endSyncMsg )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #close sockets

        ret = self.slBsdHandle.Close( syncSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(syncSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()



class BsdTestSendAggregationIPv6(BSD_Test_base.BsdTestBase):
    def __init__(self, slBsdHandle = None, fileHandle = None  ):
        BSD_Test_base.BsdTestBase.__init__(self, "BsdTestSendAggregationIPv6", slBsdHandle, fileHandle)
        self.sync1 = "sync number 1"
        self.sync2 = "sync number 2"
        self.DATA_6529= "3GCNUYARZKE4FNGLC0747C3JMUBTQA63OXXAOK525LZY36IPW6WW5DOKRKU1P4OX70TMLWVDHDXBRLGWGCAU4I7DZJ3FBNZ2CNRT8GZ7TM7KP1KA4ZQN5BZMX9YU2ZHKKW93788YT9BSP6PZCWRJHPNNH5U6FO8D09HXGV127PYWC3PS0HZ1CDKYI81WVGKHMA5LLKGP412TCCX4GYFOTS1TR5JF2CFUU1Q78VH8GVEEENDPXV25DBBQGNQJKQ2Y8LAVT05Y70W66T8MOMZV3N838H90R3O7GM6S6CN48YZQ26D3GD25CQXGMV1ZL3U7FEAOBSFJIEI9GMBUAY9BSBUBL4JLPBWUPG69MO30N2VABFIWW0FQRHCIVFHWJ65U2MYANMDO9S27LM8TEQW9VACZX4554VBOJP512BLDQMWHCL2Z33HEU8BQB4R3IU0JUXL7PCFV6NRE4Q9GCLAQJHV0XZRGNL40BYVHJKEKBJDOJBF848MZH5QPPK7ODMMTHJ5XYSL9TW1J3R5EB1FYM8WQXUI3531V6D21FZYZKN9TUNCYMUWNK37P8B1CC87V6HPTPW6H6GD0JFBVT12CZL8JVGFEPZC1X8EMND71L2OPI01BIU1CKCXNGZV4P01P7R1NKB8GQ65P1W2JD3VR1YQMFXSI28DR3HCBM9C37EPS8BWYHXZGX94D6TZ331CLWSLPRJFS8X9F8TZKY7I5PII57MKE0FOVRKDAYZPG2XWUHPIR7KF7NA1XMPVWTO5Z0XE81YQKTXG1MHHSO0JTGUEV46XBHSPXUJPZNKZRWN858BOTR1WJTCDWINP0QRG3P1ZD1OQNH8LWQ46O4O9YJ8VARUT4TPD9TAO8RDYPJYR5PAIWTCBY0JWVXF0YHS37BO5KSSMN07OIWQE1NV1FEQ7D8ZC6HAK8HY3SVF9X84GHAORATW08R0BRNCU2NCRMZH9J1U4HKK9C8IRJSQTY3M0DPMB54XVEOUWP0T8P79C3RW75SDP401PIR02FOHI2VOPU96USGWUYYTNUT87ZXWSX1CTSF99FV04VA2HJ2616FYJYNLTTI3TJRH2MRVZD7WC8W45HB26JP9ZCD3W6F3ITS6ONH10DJC9YDYZTQW9ID2JDUH23D8JNMQ3HRVH1IXK5A1JP3V9EISQHRSQI8AZKE3C8MY64FGVF5LXJ76HDR51WNAX0CQRLMYMZZTU0QYRFK4BE7Z9VTMLUKSDUWH33S4R5QNXEMKD60F6QUFE6774MY9X56FRSEMU355DUKKMSS9YYTSEN4189QD1T14C1CTSL3F8QP7TVN3WQ6YHVP9NQ5RS7LCK5HUBV40URIAU10TZ8UHU9V0JUW4RRA64UJUY2N6DF797JLMO3P71GVVL79PR0WBU4MBDV4GEZYCLAXKHNGXMO2SD9AT7BLSJ1YWZALSFVQBMFC9MAD1SEN8XTS86L4D5QIZ4MEB53"
        self.DATA_6529 = self.DATA_6529+ "3h2323errrr333ed43hc3333dhff6gdffffhgfyrfff6fy9ffff8ff000040f080f0dfws8s0df9sd0f9sTestsel.data_2-checkit!@#$%%56jdsfbh237sdcvhasd werf897erf79y93yreyrf9sdfgvywe89yf789erfywer79fyh349-yfvye79rty89dfvya9wehdfwgnm238r5yqfguq9yrt97q4vhw3789fyhv34789vh34789fh3478y378fy3478vyw78vy378fy39ry29-ry9fy34789fyh34789fh3789hf34789vh5897vh3789fhv378fyh578fh34789fh34789fyh54f789h34f78h34f9739dfgvyse9rv  df -r u9dvn wsd7fy89 n98237c4 9    8w37rcqw890ey7r-12387cn 9ewyf uisdhfuy8qwefyhq93rfye9yf1239-8ua[PCKDM `478 89YDCA79WEYR `89Y489Q WYDF89Q34Y7T348 78ERYFASDUIHCV34789RY34 FYSDY129-RYE9R8YFER89YF914E4[  9U CZDFFN123789DH HCV3478FY3478 FYQCY3478FY3478 FY 9FY139 4RY QWEYFQ78934YFHIO12RGY-`-27R3479YR3478Y4789YCVYXD897FVYER789FYQ34R5Y34YRRNX CWE89Y V47R7834YR7813YR-ADAFU NQWEHBDC 238DHQW78D N784F2780RYQ0W7YD C  OAUYS F13478RH134R3478RTY2 BWEDB47RGF23 F34 -0Y FQ23481TY Q368  23T RTG346TR34RT 8334R7834YR780134YR80347YRQ78FYHB4 CF364TFG346TF 346TRF 3468TF 13468RT 348R 31478TY 13478R 13478YR Q78WEYF 3Q2C8213HD 34CG347B368R7"
        self.DATA_6529 = self.DATA_6529 +  "SADSDFSD9-FVIW939-4I9349-R CI,    WE90RI 3489034890 U 3UF890ASDUF890ASDUF890SDFUR C890QSUJDs)FUI 1 WDUA90SDJFKQ23OIRCM 340T81=348R18903478580Q34RT0134URM 34R81 08R5051394R5 13890T 3V4RT893 8934789 374R897348RT738947RT8934R7 8934YRTF 78934YRT7893T784Y5T789YT789Y54 9Y13489RY 1349RY 34789RY 3497YR 1394UYR3489 7R89-37R NE0F8D N14R908CM E09R8WQER23E802UE08237889237897WEDF6 234 `2942Y3R790234T347Y`289-7R 8234N R3417R61347890R6`2-4=23R78QBNRFY-9WE RB236 N2736E789y6r aer79fy7er79fg659t7349y7ernc89erpf 134[r'0134 ur[134r78 ane796f-123r67bp aa;A7    P2374Q0 B4R60346RB NPQN 4R  P w;R71P3274WE- B13409R6 1347RY NP;AWr;/q4thr 134-WEUG[WTMNGWNV-348=34TU [GY75489-T734-9T7QP9TN7 T7134[TP-7T7PT34BT63478B 23478R6 B0349R8734H 780346HR5 PA47 R5HQ   23479H 1349P8H 437975 B3476 178034 613478 0 R6JN34P98R57 JN134786 H37846H 1347806 782346 B08137265 B1347805 6BN 1P56 BQWEKL ILWRLTH54Y9O1239    BWER6Y3478RT3478T63478T674TG677892346T347863478T613478 13478RY 87;OADFUYF3409RT7R57 9327947809234Y667802346023967723967123657189236"
        self.DATA_6529 = self.DATA_6529 +  "das diasedfjkir90w    ir923i2390riw90ei ,sd90fiaergikg-i  2390ruj3490uj890gu890gu890gu90gui90gbui90gvuqef890u5tu90tufu890fuzsdf90rieg9054ut2=90uti590tit90vuid80fug0w49ugj3590gj3vcj34=0ru3490ui340uj80vjh489vjh50vu590fvuj5490vu50vu50u34901=cjmn v34h  4w3-eri  `4  =09W3RI34=95I92=T5I9 Q3459 ]FzsdFEDFAWERRF9054 =9T854890 T45TUTU245UTQ90WUFDFJG=034TYI82459YI88YI4905Y5UT5U54TUUAS FQ93FQ-WERT348T5=349T8RQ90 E4UMT23480TU Q384U5 01348U5 134895U 1=435U 348-5 U13458 134058U 1340=58 1349058 103485 90834905 8151349058 134=958 134=9058 134=958 1349058 1=4985 1=9034581=903458 9013458901 8345=91834 5901F90SDUI09WER8ER=9T8WER=-9T8WER9T8WER90T8W=90ERT8=WER9T8WE9R8T90WER8T90ER8T=W9E9RT8 M134805U 18345 1=94358 193485 134958 1490358 1349058 =34085 1903485 90AWE0RHWE WER  34T890FGT90  232389TRG3489VBUJHR489WGU8934U895U89FU890RTKWERJKOJKLERJIOERSJIOWERI0RG80WE5854UIODJIOEFAJIOJIOWEIOU80RRTG90JL43JKLDFKLDFSRIERIOIOEGIOGGTG89RTG89RTG89RTG89RTG8989RTG89RTG8989T789RT8989WER89WERTWERTGW54TY54Y90YR09TGI90W4TGUI9023UT945JTG8"
        self.DATA_6529 = self.DATA_6529 +  "AsDUIASDF89AERUFG890U0U QWET89U89T U3489UTU8 E90RGU890SERUG890SDFJV 090UI90DFGB890S=098U890DGU80U880U85U89UV89TVW79Y785VH578VH78FY578Y789Y78Y57Y789VY57895FY5789GY5789Y5789Y5789Y578Y378Y7Y785TY895Y5789Y5789Y5789Y59TU754 Q384QE8944TU7Q2=-8-0-8FD-GW8-ERTU789TU7895N 34 3478YR9- 134UY89-2USADUQ23[R5T-082340T8920 N34789TY 7945YT 7834YT 78934TU7892347T89T7GH8H880ERG5890GTG54U45G8945GU45G895UG895UYGGUYUYGQ2-2Q--9-8EDFYUQ7894FYU34789FUY34789FUY37894YFU78934FUY78934YF7834FY34789YF7834YR734YF78Q3Y4RF7831F09384FU3489FUY78934FUY SDIF 8R 789ASEFDYQ -R8 U134-8RU QORU891234RU-134589Q34793478RY34780RY3478FH34 34D1789 Y12379ERY 19034YR7934YR3478RY3478RY3478RY3478RYF3478FHUIFH 14789RY 78QW4YR 1342789RY 143Y7RY QW7903YER7 2Y134787813413478134780QF78FY7Y7ASE;KSDR;AW3topq34u-47r91348uy 789234ry A dq34-r7 q90348r 34789 134t78y3478rty1340t0q;awtpy-0tq-t134-tart]q34tu=t=54tg[h34f-4-13-4rfy4783y78fy78qwyer67dt b   23r 67234rg0 34yrq3489t7-t8-9erf7uqer89fgu3489tu73489qt 3478ry7834ry3478ry3478ry3478ry3478ry340r347ry3478ry3"
        self.DATA_6529 = self.DATA_6529 +  "asdfiosdfuwer890uf89  23ur    2389u   983ud89we d9    23e8923 r89q34ur=9034ufiovnlasdk fna'ASDCASKOFWEIOJ23489RU489   3U DQ89us 8UWD890   23UR=3409TIE GRTGJK[54GJK5490U5489U5T54YF78ERWHF78FH 7834HF7834YF7834YF-2R= 34RFNQE89FUER89-FU3489TYF54BHERYIFG7834RT-34789YRF-9ERFYAS7 FNA[-04TU54]=0U93T2489Y1T7934YQT78WECH dcNJQLRF7348CJQ78943R 81YRT789WT 341[-9E78FYH 9-QAHRF=-  1T4=5UYHW[THJ5454G9Q348Y784FYQER78FY7 Q-34R 8943 P8RTVJ L;34KQJTF8 NUG89UY 35T  A4EF9Y 54T9-YYQ[T8YDF 9G5 J4U6UOK7K78UOPTR054UT895TU A49TY Q34TY TY9- TU -W5TU 5T89U2-Q 34TW54UT -9E8TU 2-85UT-W95UT58 W49-TU 489-TJ54GJT558JW54GJ-W3TGU489FJ54TG54GW9P JTY-=W54T W=-5T4 =-W54T W54U W54TY9U W54UY 54U W8954U T-W95UYW-54YUW54UY W84Y4892-5UY W854UY W54U W54UTW89JKG WI[54Y IS09DTUI5689 Y03UW54 [W54Y [W54YJ UW54TY-U JW54Y89-W54 9W54T89U W54TUW89 T5U W89-TUW5 4T89U89-U R-98TGUW59 4G9SERUG W['TOP IW=456T2568 MWUT5YU8T8RHUY89-TJDTYJK-0SDTFUIG[AS 4 TAW34;T5OJ W-T5J 54TJ894JY5YJ8 DSRT3'5YJ56890UZ0RFGW98-RTUW54U T54UJ89UW54TW45TUW-45FYHJ]UYKIUYK-I9UY"
        if len(self.DATA_6529) != 6529:
            self.log(self.getline(), self.failed )
        self.DATA_6533 = "qw" + self.DATA_6529 + "yv"
        if len(self.DATA_6533) != 6533:
            self.log(self.getline(), self.failed )



    def __del__(self):
        BSD_Test_base.BsdTestBase.__del__(self)

    def PC(self):
        self.log(self.getline(), self.start )
        # open data socket
        sd = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        sd.bind((slConf.PC_IPV6, int(slConf.PC_PORT) ))
        sd.connect((slConf.SL_IPV6, int(slConf.SL_PORT) ))

        # open sync socket
        syncSd = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        syncSd.bind((slConf.PC_IPV6, int(self.mngPort) ))
        syncSd.listen(3)
        # sync between sl and by accept
        privateSd, addr = syncSd.accept()
        # now pc and sl are sync

        readData =""

        # first test  max paylaod 6529
        rdata = sd.recv(len(self.DATA_6529))
        if( len(rdata) < 0):
            print "recv error len (6529)",  len(rdata)
            self.log(self.getline(), self.failed )
        print "\n\nreadData ", len(rdata)
        readData = readData + rdata

        while( len(readData) < len(self.DATA_6529) ):
            rdata = sd.recv(len(self.DATA_6529))
            if( len(rdata) < 0):
                print "recv error len (6529)",  len(rdata)
                self.log(self.getline(), self.failed )
            print "\n\nreadData ", len(rdata)
            readData = readData + rdata
            print "   Total ", len(readData)
        # Compare data
        if readData != self.DATA_6529:
            self.log(self.getline(), self.failed )


        time.sleep(1)
        rdata = privateSd.recv(8000)
        if rdata != self.DATA_6533:
            privateSd.close()
            syncSd.close()
            sd.close()
            self.log(self.getline(), self.failed )


        #close sockets
        privateSd.close()
        syncSd.close()
        sd.close()
        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def SL(self):
        self.log(self.getline(), self.start )
        self.slBsdHandle.clearEvents()
        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_STREAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        syncSd = ret[1]
        ret = self.slBsdHandle.Bind( syncSd, slConf.AF_INET6,  self.mngPort )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # open data socket
        ret = self.slBsdHandle.Socket( slConf.AF_INET6, slConf.SOCK_DGRAM, 0 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        sd = ret[1]
        ret = self.slBsdHandle.Bind( sd, slConf.AF_INET6,  slConf.SL_PORT, "0.0.0.0" )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )


        # sync between sl and pc by tcp connect
        loop = True
        i = 0
        while loop:
            ret = self.slBsdHandle.Connect( syncSd, slConf.AF_INET6, self.mngPort, slConf.PC_IPV6 )
            if( ret[0] == False ):
                self.log(self.getline(), self.failed )
            if ret[2] != syncSd:
                self.log(self.getline(), self.failed )
            if False == BsdUtils.IsBsdError( ret[1], [] ):
                loop = False
            if i > 40:
                self.log(self.getline(), self.failed )
            i = i + 1
            time.sleep(0.5)

        # now pc and sl are sync
        readData =""

        # SEND DATA_6529
        ret = self.slBsdHandle.SendTo( sd, len(self.DATA_6529), 0, self.DATA_6529, slConf.AF_INET6, slConf.PC_PORT, slConf.PC_IPV6 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )
        if ret[1] != len(self.DATA_6529):
            print "ret[1] ", ret[1]
            print "sd ", ret[2]
            print "slConf.AF_INET ", ret[3]
            print "int(slConf.PC_PORT) ", ret[4]
            print "slConf.PC_IPV4 ", ret[5]
            self.log(self.getline(), self.failed )


        #exit test
        ret = self.slBsdHandle.Send( syncSd, len(self.DATA_6533), 0, self.DATA_6533 )
        if( ret[0] == False ):
            self.log(self.getline(), self.failed )

        #close sockets
        ret = self.slBsdHandle.Close( sd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(sd) )

        ret = self.slBsdHandle.Close( syncSd )
        if( ret[0] == False ):
            self.log(self.getline(),self.failed, str(syncSd) )

        # Test success (al socket closed !!!
        self.log(self.getline(),self.success  )


    def run(self):
        if self.slBsdHandle != None:
           self.SL()
        else:
            self.PC()
