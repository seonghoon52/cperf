
import sys
import time
import TICore
import configurations as conf
import string
import options
import binascii
import utils


def add_profile(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    SSID = Opts.GetVal('SSID')
    Key = Opts.GetVal('key')
    Priority = int(Opts.GetVal('Priority'))
    SecType = int(Opts.GetVal('Security'))
    KeyIndex = int(Opts.GetVal('Index'))
    if (0 == SecType):
        #                                                                          bssid-hi, bssid-low, password-len, wep-key-index, SSID
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, 0, 0, SSID)
    elif (1 == SecType):
        Key = utils.str2HexStr(Key)
        KeyLen = (len(Key) - Key.count(':')) / 2
        if (255 == KeyIndex):
            KeyIndex = 0 #In case the user doesn't enter index (-I) at the add_profile.py, the default value for key index should be 0 (== key index #1 at the AP side)
        #                                                                          bssid-hi, bssid-low, password-len, wep-key, SSID, 4xKey
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, KeyLen, KeyIndex, SSID, Key, Key, Key, Key)
    elif (2 == SecType):
        #                                                                          bssid-hi, bssid-low, password-len, wep-key, SSID, Key
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, len(Key), 0, SSID, Key)
    elif (6 == SecType):
        #P2P Profile           bssid-hi, bssid-low, password-len, wep-key, SSID, Key
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, 0, 0, SSID)
    elif (7 == SecType):
        #P2P Profile - KEYPAD           bssid-hi, bssid-low, password-len, wep-key, SSID, Key
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, len(Key), 0, SSID, Key)
    elif (8 == SecType):
        #P2P Profile - DISPLAY           bssid-hi, bssid-low, password-len, wep-key, SSID, Key
        core.InvokeSLCommand("WLAN", "ADDPROFILE" ,2, SecType, len(SSID), Priority, 0, 0, len(Key), 0, SSID, Key)


    time.sleep(5)
    core.close()
    sys.exit("add_profile Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    add_profile(Opts)