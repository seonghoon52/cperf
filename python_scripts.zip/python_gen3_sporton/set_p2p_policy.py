
import sys
import time
import TICore
import configurations as conf
import string
import options


def conn_policy(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    Intent = int(Opts.GetVal('Intent'))
    forceAutonomousGO = int(Opts.GetVal('forceAutonomousGO'))
    NegInitiator = int(Opts.GetVal('NegInitiator'))
    PolicyOption = ((0xF & (Intent))) | ((1 & (forceAutonomousGO))<<4) | ((3 & (NegInitiator))<<5)
    #core.InvokeSLCommand("WLAN", "SETCONNPOL", 1,OpenAP,Fast,AutoStart)
    core.InvokeSLCommand("WLAN", "SETCONNPOL", 1000, 0x40, 0, PolicyOption, 0, "00:00:00:00")
    time.sleep(1)
    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    conn_policy(Opts)