import configurations as conf
import options
from simple_link_api import SimpleLinkDevice
import simple_link_api
import sys
import os
import utils
import StringIO
import simple_link_api as sla
from random import randint

#write file modes:

#chosen write mode:
WRITE_MODE = sla._FS_MODE_OPEN_WRITE_CREATE_IF_NOT_EXIST

MAX_CHUNK_WRITE_SIZE        = 1408 #better performance to use number which is 16 aligned
ANY_DEVICE                  = 255
def write_file(filename,fileid, maxSize=-1, Token = 0, Mirror = 0, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, Signature="" , CertificationFileName = ""):
    fInput =  open(filename, 'rb')
    fInputSize = os.path.getsize(filename)
    if maxSize < fInputSize:
        maxSize = fInputSize
        print "  Max file size is increased to the actual file size = " + str(maxSize)
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpen(fileid, WRITE_MODE, maxSize, ANY_DEVICE, Token, Mirror, Secure, Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead)
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    Offset = 0
    if fHdl > 0:
        while Offset < fInputSize:
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, fInputSize-Offset)
            chunkSize = randint(1,Sizelimit)
            buff = fInput.read(chunkSize)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,chunkSize)
            Offset += len(buff)
        Sl.sl_NvmemClose(fHdl, Signature , CertificationFileName )
    fInput.close()
    del Sl
    return {'fHdl':fHdl, 'fToken':fToken }


def write_fileByName(filename,NWPfilename,maxSize=-1, Token = 0, Mirror = 0, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, Signature="" , CertificationFileName = "" ):
    fInput =  open(filename, 'rb')
    fInputSize = os.path.getsize(filename)
    if maxSize < fInputSize:
        maxSize = fInputSize
        print "  Max file size is increased to the actual file size = " + str(maxSize)
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName(NWPfilename, WRITE_MODE, maxSize, ANY_DEVICE, Token,  Mirror, Secure, Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead )
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    Offset = 0
    retVal = 0
    if fHdl > 0:
        while Offset < fInputSize:
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, fInputSize- Offset )
            chunkSize = randint(1,Sizelimit)
            buff = fInput.read(chunkSize)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,chunkSize )
            Offset += len(buff)
        Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)
    fInput.close()
    del Sl
    return { 'fHdl':fHdl , 'fToken':fToken }



def Debugwrite_fileByNameNoClose(filename,NWPfilename,maxSize=-1, Token = 0, Mirror = 0, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, Signature="" , CertificationFileName = "" ):
    fInput =  open(filename, 'rb')
    fInputSize = os.path.getsize(filename)
    if maxSize < fInputSize:
        maxSize = fInputSize
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName(NWPfilename, WRITE_MODE, maxSize, ANY_DEVICE, Token,  Mirror, Secure, Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead)
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    Offset = 0
    retVal = 0
    if fHdl > 0:
        while Offset < fInputSize:
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, fInputSize-Offset)
            chunkSize = randint(1,Sizelimit)
            buff = fInput.read(chunkSize)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,chunkSize)
            Offset += len(buff)
        #Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)
    fInput.close()
    del Sl
    return { 'fHdl':fHdl , 'fToken':fToken }

def Debugwrite_fileByName(filename,fHdl ):
    fInput =  open(filename, 'rb')
    fInputSize = os.path.getsize(filename)
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Offset = 0
    retVal = 0
    if fHdl > 0:
        while Offset < fInputSize:
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, fInputSize-Offset)
            chunkSize = randint(1,Sizelimit)
            buff = fInput.read(chunkSize)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,chunkSize)
            Offset += len(buff)
        #Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)
    fInput.close()
    del Sl
    return retVal


def Debugwrite_fileByNameClose(fHdl , Signature="" , CertificationFileName = "" ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)


def get_formatted_buf_real_len(inbuff):
    seperators = inbuff.count(':')
    return seperators + 1

def write_buffer(inbuff,fileid ,formatBuffer, maxSize=-1 , Token = 0, Mirror = False, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, Signature="" , CertificationFileName = ""):
    fInputSize = len(inbuff)
    if not formatBuffer:
        fInputSize = get_formatted_buf_real_len(inbuff)
    fInput = StringIO.StringIO(inbuff)
    if maxSize < fInputSize:
        maxSize = fInputSize
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpen(fileid, WRITE_MODE, maxSize, ANY_DEVICE, Token, Mirror, Secure , Vendor, Static, NoSignature,OpenForPublicWrite, OpenForPublicRead)
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    Offset = 0
    if fHdl > 0:
        while Offset < fInputSize:
            buff = fInput.read(MAX_CHUNK_WRITE_SIZE)
            if not formatBuffer:
                length = get_formatted_buf_real_len(buff)
            else:
                length = len(buff)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,length,formatBuffer)
            Offset += length
        Sl.sl_NvmemClose(fHdl, Signature, CertificationFileName )
    fInput.close()
    del Sl
    return { 'fToken':fToken}


def write_buffer_ByName(inbuff, fileName,formatBuffer, maxSize, Token = 0, Mirror = False, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, Signature="" , CertificationFileName = ""):
    fInputSize = len(inbuff)
    if not formatBuffer:
        fInputSize = get_formatted_buf_real_len(inbuff)
    fInput = StringIO.StringIO(inbuff)
    if maxSize < fInputSize:
        maxSize = fInputSize
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName(fileName, WRITE_MODE, maxSize, ANY_DEVICE,Token, Mirror, Secure , Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead)
    fHdl = Result['fHdl']
    fToken = Result['fToken']

    Offset = 0
    if fHdl > 0:
        while Offset < fInputSize:
            buff = fInput.read(MAX_CHUNK_WRITE_SIZE)
            if not formatBuffer:
                length = get_formatted_buf_real_len(buff)
            else:
                length = len(buff)
            Sl.sl_NvmemWrite(fHdl,Offset,buff,length,formatBuffer)
            Offset += length
        Sl.sl_NvmemClose(fHdl,  Signature, CertificationFileName )
    fInput.close()
    del Sl

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print "\n\nError: Wrong Number of Parameters!!!\n\nSyntax:\n"
        print "write_file_to_flash.py with the following params :"
        print "[pc file path] [file id - number | file name - surrounded by ' '] [max size]"
        print "To open file as secure+public write additional parameter "
        print "[pc file path] [file id - number | file name - surrounded by ' '] [max size] 1"
    elif (len(sys.argv) == 4):
        name = sys.argv[2]
        print "File Name: " + sys.argv[1]
        print "File Name NWP: " + sys.argv[2]
        print "Max Size: " + sys.argv[3]
        if name[0] == '\'':
            if name[len(name) - 1] != '\'':
                print "Missing Closing ' in file name"
            else:
                name = name.replace('\'','')
                name = name + '\0'
                write_fileByName(sys.argv[1],name,int(sys.argv[3]))
        else:
            print "keil"
            write_file(sys.argv[1],sys.argv[2],int(sys.argv[3]))
    else:
        print "Secure+public writw " + sys.argv[1]
        print "File Name: " + sys.argv[1]
        print "File Name NWP: " + sys.argv[2]
        print "Max Size: " + sys.argv[3]
        write_fileByName(sys.argv[1],sys.argv[2],int(sys.argv[3]),0,1,1,0,0,1,1,0,"","")
