#-------------------------------------------------------------------------------
# Name:        start_ctst.py
# Purpose:
#
# Author:      a0387680
#
# Created:     21/07/2011
# Copyright:   (c) a0387680 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf
import utils
import math
import msvcrt




def main():
    core = TICore.TICore()
    core.initialize1()

    arglen      = len(sys.argv)
    testType    = int(sys.argv[1])
    DstPort     =  int(sys.argv[2])
    SrcPort     =  int(sys.argv[3])
    DstIpAdd    = conf.REMOTE_IP_ADDR
    DstIPV6Add  = conf.REMOTE_IPV6_ADDR
    PayloadSize = int(sys.argv[4])

    #testType = 0
    #DstPort =  5001
    #SrcPort =  5001
    #DstIpAdd = conf.REMOTE_IP_ADDR_HEX

    print arglen
    print testType
    print DstPort
    print SrcPort
    if( testType >= 9 and testType <= 12 ): #BSD IPV6
        print DstIPV6Add
        print PayloadSize
        core.InvokeSLCommand("WLAN", "CTST_START"       ,2, testType, DstPort, SrcPort, utils.ipv6GetUlong(DstIPV6Add, 0), utils.ipv6GetUlong(DstIPV6Add, 1), utils.ipv6GetUlong(DstIPV6Add, 2), utils.ipv6GetUlong(DstIPV6Add, 3), PayloadSize ) #IPv6
    else:
        print DstIpAdd
        print PayloadSize
        core.InvokeSLCommand("WLAN", "CTST_START"       ,2, testType, DstPort, SrcPort, utils.getIpHexNum(conf.REMOTE_IP_ADDR), 0, 0, 0, PayloadSize ) #IPv4
    print("Press Esc to Exit and run stop_ctst_test")
    while msvcrt.getch() != chr(27):
        time.sleep(1)
        
    core.close()
    sys.exit("Start Run Test Finished")


if __name__ == '__main__':
    main()
