import sys
import time
import configurations as conf
import utils
import BsdUtils
import TICore
import BSD_Test_configurations as slConf
import inspect
import argparse
import struct
import string
import options
import binascii
import msvcrt
core = TICore.TICore()
core._logToStdout = True
core.loadSpec(conf.XML_PROTO_FILE)
slBsdHandle = BsdUtils.BsdUtils(core)

from ctypes import *
PIPE_ACCESS_DUPLEX = 0x3
PIPE_TYPE_MESSAGE = 0x4
PIPE_READMODE_MESSAGE = 0x2
PIPE_WAIT = 0
PIPE_UNLIMITED_INSTANCES = 255
BUFSIZE = 1048576
NMPWAIT_USE_DEFAULT_WAIT = 0
INVALID_HANDLE_VALUE = -1
ERROR_PIPE_CONNECTED = 535

MESSAGE = "Default answer from server\0"

# rete index for send!!!!!!!
DRV_RATE_1M         = 1
DRV_RATE_2M         = 2
DRV_RATE_5_5M       = 3
DRV_RATE_11M        = 4
DRV_RATE_6M         = 6
#///////NO INDEX 5!!!!///////////#
DRV_RATE_9M         = 7
DRV_RATE_12M        = 8
DRV_RATE_18M        = 9
DRV_RATE_24M        = 10
DRV_RATE_36M        = 11
DRV_RATE_48M        = 12
DRV_RATE_54M        = 13
DRV_RATE_MCS_0      = 14
DRV_RATE_MCS_1      = 15
DRV_RATE_MCS_2      = 16
DRV_RATE_MCS_3      = 17
DRV_RATE_MCS_4      = 18
DRV_RATE_MCS_5      = 19
DRV_RATE_MCS_6      = 20
DRV_RATE_MCS_7      = 21

#receive rate index - you will get in the air the index on the right (with the //) convert it to regular rate by taking the left side and divide it by 2.
#    2      ,    //0 
#    4      ,    //1
#    11     ,    //2 
#    22     ,    //3
#    12     ,    //4
#    18     ,    //5
#    24     ,    //6
#    36     ,    //7
#    48     ,    //8
#    72     ,    //9
#    96     ,    //10
#    108    ,    //11
#    13     ,    //12
#    26     ,    //13
#    39     ,    //14
#    52     ,    //15
#    78     ,    //16
#    104    ,    //17
#    117    ,    //18
#    144         //20

def main():

    core.initialize1()
    
    
    # sets the SimpleLink to promiscuous mode. the first two parameters sets the mode, and the last parameter is the channel you want to work in. 
    ret = slBsdHandle.Socket( slConf.AF_RF, slConf.SOCK_RAW, 1 )
    raw_input()
    sd = ret[1]
    print str(hex(1))
    ret = slBsdHandle.SetSockOpt( sd, 3, 106, 4, utils.convert_to_propriety_long(1))
    
    raw_input()
    slBsdHandle.Recv(sd,1536,0)
    raw_input()
    # those are packets for example. the first byte is the RATE. the next byte is - High nibble for the TX power (0-15) and lower nibble for Short (1) Long (0) Preamble
    data1 =  '\x01\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data2 =  '\x02\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data3 =  '\x03\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data4 =  '\x04\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data5 =  '\x06\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data6 =  '\x07\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    data7 =  '\x08\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'#data = '\x0B\x15\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    data8 =  '\x09\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'# IGMP
    data9 =  '\x0a\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'#data='\x0B\x22\x11\x88\x02\x2C\x00\x08\x00\x28\x00\x11\x13\x50\x3D\xE5\x75\xAB\xF0\x50\x3D\xE5\xF2\x16\x40\xB0\x81\x00\x00\xAA\xAA\x03\x00\x00\x00\x08\x00\x45\x00\x00\x1C\x6C\x57\x00\x00\xFF\x02\x45\x94\x0A\x02\x1F\xF1\xE0\x00\x00\x01\x11\x01\xEE\xFE\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    data10 = '\x0b\x11\xc4\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'# Action Block ack
    
    # example for ping
    ping = '\0x02\0x11\0x88\0x02\0x2C\0x00\0x00\0x23\0x75\0x55\0x55\0x55\0x00\0x22\0x75\0x55\0x55\0x55\0x08\0x00\0x28\0x19\0x02\0x85\0x80\0x42\0x00\0x00\0xAA\0xAA\0x03\0x00\0x00\0x00\0x08\0x00\0x45\0x00\0x00\0x54\0x96\0xA1\0x00\0x00\0x40\0x01\0x57\0xFA\0xc0\0xa8\0x01\0x64\0xc0\0xa8\0x01\0x02\0x08\0x00\0xA5\0x51\0x5E\0x18\0x00\0x00\0x41\0x08\0xBB\0x8D\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00\0x00'
    lsd = [data1,data2,data3,data4,data5,data6,data7,data8,data9,data10]   
   
    raw_input( "Press Enter to staring Transmiting 10 packets on channel 4")   
    
    #ret[1] is the socket descriptor we got above from opening a socket, string you want to Transmit length, flags, and the string itself
    for string in lsd:
        ret1 = slBsdHandle.Send( ret[1], len(string) , 0, string ) 
    
    
    #it is possible to change the channel in the middle, by using the command below - the last parameter is the channel number
    slBsdHandle.SetSockOpt( ret[1], BsdUtils.SOL_SOCKET, BsdUtils.SO_CHANGE_CHANNEL, 1, str(hex(4)))

    raw_input("Press Enter to start receiving 20 packets on channel 5")
    
    slBsdHandle.SetSockOpt( ret[1], BsdUtils.SOL_SOCKET, BsdUtils.SO_CHANGE_CHANNEL, 1, str(hex(5)))

    ################################
    #
    #
    # put here filters
    #
    ###############################
    
    while 1:
       #the recv command enable the raw socket for RX, the first parameter is the socket descriptor, the next parameter is the maximum bytes to recv 
       #in a single recv call, the zero in the end is flags.
       
       #ret1[3] is the data buffer, to print what you got, use print ret1[3]. 
       #in ret1[1] is the number of bytes received
       ret1 = slBsdHandle.Recv(ret[1],1536,0)   
       
       #in the received packet we have an overhead before the packet
       # 
       # | rate * 1 | channel * 1 | rssi * 1 | padding..... * 1 | time stamp * 4 | packet ..... * N |
       #
    
    
    ret1 = slBsdHandle.Close( ret[1] )

    core.close()

if __name__ == '__main__':
    main()