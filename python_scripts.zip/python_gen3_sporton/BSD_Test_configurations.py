
import configurations as conf
import utils

AF_INET     =  2  # IPV4
AF_INET6    =  3  # IPV6
AF_RF       =  6  # proporety packet generator
SOCK_STREAM =  1  # TCP Socket.
SOCK_DGRAM  =  2  # UDP Socket.
SOCK_RAW    =  3  # RAW Socket



SL_PORT = conf.LOCAL_PORT
SL_IPV4 = conf.LOCAL_IP_ADDR
SL_IPV6 = conf.LOCAL_IPV6_ADDR
SL_PORT_HEX = utils.getPortHexStr(SL_PORT)
SL_IPV4_HEX = utils.getIpHexStr(SL_IPV4)
SL_IPV6_HEX = utils.ipv6ExtractToPoprietyFullAddress(SL_IPV6)
SL_IPV6_GLOBAL = conf.GLOBAL_IPV6_ADDR
SL_IPV6_HEX_GLOBAL = utils.ipv6ExtractToPoprietyFullAddress(SL_IPV6_GLOBAL)


PC_PORT = conf.REMOTE_PORT
PC_IPV4 = conf.REMOTE_IP_ADDR
PC_IPV6 = conf.REMOTE_IPV6_ADDR_LOCAL
PC_PORT_HEX = utils.getPortHexStr(PC_PORT)
PC_IPV4_HEX = utils.getIpHexStr(PC_IPV4)
PC_IPV6_HEX = utils.ipv6ExtractToPoprietyFullAddress(PC_IPV6)
PC_IPV6_GLOBAL = conf.REMOTE_IPV6_ADDR_GLOBAL
PC_IPV6_HEX_GLOBAL = utils.ipv6ExtractToPoprietyFullAddress(PC_IPV6_GLOBAL)
