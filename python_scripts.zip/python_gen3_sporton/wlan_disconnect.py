
import sys
import time
import TICore
import configurations as conf
import string
import options


def wlan_connect(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    SSID = Opts.GetVal('SSID')
    Key = Opts.GetVal('key')
    SecType = int(Opts.GetVal('Security'))
    core.InvokeSLCommand("WLAN", "DISCONNECT",1)
    time.sleep(2)
    core.close()
    sys.exit("Disconnect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    wlan_connect(Opts)