import configurations as conf
import options
from simple_link_api import SimpleLinkDevice
import simple_link_api
import sys
import os
from random import randint
import struct





#write file modes:
simple_link_api._FS_MODE_OPEN_READ        # open for read only
simple_link_api._FS_MODE_OPEN_WRITE               # open for read & write (won't create a file if it doesn't exist)
simple_link_api._FS_MODE_OPEN_CREATE                # create file and a mirror
simple_link_api._FS_MODE_OPEN_WRITE_CREATE_IF_NOT_EXIST # create a file or open for write
simple_link_api._FS_MODE_OPEN_WRITE_READ
simple_link_api._FS_MODE_OPEN_WRITE_READ_CREATE_IF_NOT_EXIST



#FsControl_t

FILE_SYS_CTL_RET_TO_FACTORY_DEFAULT = 0
FILE_SYS_CTL_ROLLBACK_REQUEST = 1
FILE_SYS_CTL_COMMIT_REQUEST = 2
FILE_SYS_CTL_RENAME = 3
FILE_SYS_CTL_GET_FILES_COUNTERS_REQUEST = 4
FILE_SYS_CTL_GET_STORAGE_INFO_REQUEST = 5


#FsBundleControl_t
BUNDLE_CTL_ROLLBACK_REQUEST = 0
BUNDLE_COMMIT_REQUEST = 1
BUNDLE_CTL_START_REQUEST = 2
BUNDLE_CTL_TESTING_REQUEST = 3
BUNDLE_CTL_WAIT_FOR_COMMIT_REQUEST = 4
BUNDLE_CTL_GET_STATE_REQUEST = 5

#FileFilterFlags_t

FILE_SYS_CTL_FLAG_REVCLOSEDFILES                = 0x1    #REVERT/COMMIT ON FILES IN STATE PENDING COMMIT.
FILE_SYS_CTL_FLAG_REVABORTOPENEDWRITEFILES      = 0x2    #REVERT ON  FILES IN STATE  OPENED IN  COMMIT MODE , ( =OPEN FOR WRITE IN  COMMIT MODE ,)
FILE_SYS_CTL_FLAG_REVOPENEDREADFILES            = 0x4    #REVERT/COMMIT ON OPENED  FILES IN STATE  PENDING COMMIT MODE , ( =OPEN FOR READ IN   COMMIT MODE )
FILE_SYS_CTL_FLAG_ANYCLOSEDFILE                 = 0x8    #REVERT/COMMIT ON FILES WHICH ARE NOT IN  PENDING COMMIT .
FILE_SYS_CTL_FLAG_ANYABORTOPENEDWRITEFILE       = 0x10   #REVERT ON  FILES IN STATE OPEN FOR WRITE (NOT IN  COMMIT MODE )
FILE_SYS_CTL_FLAG_ANYOPENEDREADFILE             = 0x20   #REVERT/COMMIT ON  FILES IN STATE OPEN FOR READ( NOT IN  PENDING COMMIT MODE )
FILE_SYS_CTL_FLAG_BUNDLECLOSEDFILES             = 0x40   #INTERNAL USE- NOT EXPOSED TO THE HOST, REVERT/COMMIT ON CLOSED FILES IN STATE  BUNDLE PENDING COMMIT .
FILE_SYS_CTL_FLAG_BUNDLEABORTOFOPENEDWRITEFILE  = 0x80   #INTERNAL USE- NOT EXPOSED TO THE HOST ,REVERT ON  FILES IN STATE  OPENED IN  BUNDLE COMMIT MODE , ( =OPEN FOR WRITE IN  BUNDLE COMMIT MODE  )
FILE_SYS_CTL_FLAG_BUNDLEOPENEDREADFILES         = 0x100  #Internal use- not exposed to the host ,Revert/Commit on opened  files in state  Bundle Pending Commit mode , ( =open for read in  Bundle Pending Commit mode )


#Bundle BundleFilterFlags_t
BUNDLE_CTL_FLAG_FORCE_REVERT_ON_WRITE = 0x1  #Relevant only to revert operation,Revert on  files in state  opened in  Bundle Commit mode
BUNDLE_CTL_FLAG_FORCE_ON_READ  = 0x2         #Revert/Commit on opened  files in state  Bundle Pending Commit mode
BUNDLE_CTL_DEFAULT = BUNDLE_CTL_FLAG_FORCE_ON_READ



FILE_SYS_CTL_FLAG_COMMIT_ALL_REV = FILE_SYS_CTL_FLAG_REVCLOSEDFILES | FILE_SYS_CTL_FLAG_REVOPENEDREADFILES
FILE_SYS_CTL_FLAG_REVERT_ALL_REV = FILE_SYS_CTL_FLAG_REVCLOSEDFILES | FILE_SYS_CTL_FLAG_REVOPENEDREADFILES | FILE_SYS_CTL_FLAG_REVABORTOPENEDWRITEFILES

FILE_SYS_CTL_FLAG_COMMIT_ALL_ANY = FILE_SYS_CTL_FLAG_ANYCLOSEDFILE | FILE_SYS_CTL_FLAG_ANYOPENEDREADFILE
FILE_SYS_CTL_FLAG_REVERT_ALL_ANY = FILE_SYS_CTL_FLAG_ANYCLOSEDFILE | FILE_SYS_CTL_FLAG_ANYOPENEDREADFILE | FILE_SYS_CTL_FLAG_ANYABORTOPENEDWRITEFILE

FILE_SYS_CTL_FLAG_COMMIT_ALL_BUNDLE = FILE_SYS_CTL_FLAG_BUNDLECLOSEDFILES | FILE_SYS_CTL_FLAG_BUNDLEOPENEDREADFILES
FILE_SYS_CTL_FLAG_REVERT_ALL_BUNDLE = FILE_SYS_CTL_FLAG_BUNDLECLOSEDFILES | FILE_SYS_CTL_FLAG_BUNDLEOPENEDREADFILES | FILE_SYS_CTL_FLAG_BUNDLEABORTOFOPENEDWRITEFILE

FILE_SYS_CTL_ALL = FILE_SYS_CTL_FLAG_REVCLOSEDFILES|FILE_SYS_CTL_FLAG_REVABORTOPENEDWRITEFILES|FILE_SYS_CTL_FLAG_REVOPENEDREADFILES|FILE_SYS_CTL_FLAG_ANYCLOSEDFILE|FILE_SYS_CTL_FLAG_ANYABORTOPENEDWRITEFILE| FILE_SYS_CTL_FLAG_ANYOPENEDREADFILE |FILE_SYS_CTL_FLAG_BUNDLECLOSEDFILES |FILE_SYS_CTL_FLAG_BUNDLEABORTOFOPENEDWRITEFILE | FILE_SYS_CTL_FLAG_BUNDLEOPENEDREADFILES
#chosen write mode:
WRITE_MODE = simple_link_api._FS_MODE_OPEN_WRITE

MAX_CHUNK_WRITE_SIZE        = 1408 #better performance to use number which is 16 aligned
MAX_CHUNK_READ_SIZE         = 1408   #better performance to use align 16
ANY_DEVICE                  = 255



FACTORY_RET_TO_IMAGE =  0
FACTORY_RET_TO_DEFAULT_KEEP_CALIB = 1
FACTORY_RET_TO_DEFAULT = 2

def open_fileByName(AccessType , NWPfilename, maxOpenSize=0 , Token = 0, Mirror = 0, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, CommitMode =0 , BundleMode = 0):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName(NWPfilename, AccessType, maxOpenSize, ANY_DEVICE, Token,  Mirror, Secure, Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead, CommitMode, BundleMode )
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    del Sl
    return { 'fHdl':fHdl , 'fToken':fToken }

def write_HostFileToDevice( fHdl, HostFileName , maxReadSize=-1 ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    fInput =  open(HostFileName, 'rb')
    fInputSize = os.path.getsize(HostFileName)
    if maxReadSize == -1:
        maxReadSize = fInputSize
    Offset = 0
    retVal = 0
    if fHdl > 0:
        while Offset < maxReadSize:
            buff = 0
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, maxReadSize-Offset )
            chunk = randint(1,Sizelimit)
            buff = fInput.read(chunk)
            retVal = Sl.sl_NvmemWrite(fHdl,Offset,buff,chunk)
            Offset += len(buff)
    fInput.close()
    del Sl
    return { 'retVal':retVal }

def read_DeviceTohost( fHdl, HostFileName , Length, ReadOffset = 0 ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    buf = 0
    Offset = ReadOffset
    FileContent = ""
    if fHdl > 0:
        while (Offset < Length ):
            Sizelimit = min(MAX_CHUNK_WRITE_SIZE, Length - Offset )
            chunck = randint(1,Sizelimit)
            buf = Sl.sl_NvmemRead(fHdl,Offset,chunck)
            if ( buf== None ):
                fOut = open(HostFileName, 'wb')
                fOut.write(FileContent)
                fOut.close()
                return -1
            Offset += len(buf)
            FileContent += buf
    fOut = open(HostFileName, 'wb')
    fOut.seek(ReadOffset)
    fOut.write(FileContent)
    fOut.close()
    del Sl
    return 1



def Close(fHdl , Signature="" , CertificationFileName = "" ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result =Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)
    del Sl
    return Result

def Abort(fHdl ):
    Signature="A"
    CertificationFileName = ""
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result =Sl.sl_NvmemClose(fHdl,  Signature , CertificationFileName)
    del Sl
    return Result


def GetFileListChunk(Sl, Index, MaxEntryLen, BufferSize ):
    Result = Sl.sl_NvmemGetFileList(Index,  MaxEntryLen , BufferSize )
    if( Result['NumOfEntries'] > 0):
        return {'NumOfEntries':Result['NumOfEntries'], 'Index':Result['Index'] ,'FileList':Result['FileList']}
    else:
        return {'NumOfEntries':Result['NumOfEntries'], 'Index':Result['Index'] }

def GetFileList( MaxEntryLen ):
    ChunkOutputBufferSize =  1400
    Index = -1
    NumOfEntries = 0
    Index = -1
    ChunkNum = 0
    FileList = b""

    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    while  True:
        ChunkNum += 1
        Result = GetFileListChunk( Sl, Index, MaxEntryLen, ChunkOutputBufferSize )
        Index = Result['Index']
        if( Result['NumOfEntries'] > 0):
            print "Number Of files for chunk = %d is  %d " %(ChunkNum, Result['NumOfEntries'])
            NumOfEntries += Result['NumOfEntries']
            FileList += Result['FileList']
        elif(Result['NumOfEntries'] < 0)  :
            print "Error ! error number = %d"%(Result['NumOfEntries'])
            break;
        elif(Result['NumOfEntries'] == 0)  :
            break;
    del Sl
    return FileList, NumOfEntries

def FileDebug( DebugMode ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemFileDebug(DebugMode)
    del Sl
    return {'Status':Result['Status'] }


def FileRename( Token, OldFileName, NewFileName ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Data = Sl.sl_NvmemFileSystemControlRename(Token, FILE_SYS_CTL_RENAME, OldFileName, NewFileName  )
    del Sl
    return {'Status':Data['Status'] }

def FileSystemControl(Token, Operation, ControlOperationFlags, FileName="", DeviceName =""):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    if( FILE_SYS_CTL_ROLLBACK_REQUEST== Operation ) or ( FILE_SYS_CTL_COMMIT_REQUEST== Operation ) :
        Data = Sl.sl_NvmemFileSystemControl(Token, Operation, ControlOperationFlags, FileName)
        del Sl
        return { 'Status':Data['Status'] ,'Token':Data['Token'] }
    elif( FILE_SYS_CTL_GET_FILES_COUNTERS_REQUEST == Operation ) :
        Data = Sl.sl_NvmemFileSystemControlCounters( Token, Operation, ControlOperationFlags  )
        del Sl
        return { 'Status':Data['Status'] ,'Token':Data['Token'],'Write':Data['Write'],'Read':Data['Read'],'Closed':Data['Closed'] }
    if( FILE_SYS_CTL_GET_STORAGE_INFO_REQUEST == Operation ) :
        ResponseDict = Sl.sl_NvmemFileSystemControlGetInfo( Token, Operation, FileName, DeviceName  )
        del Sl
        return ResponseDict

def RetToFactory(Operation):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Data = Sl.sl_NvmemFileSystemControlRetToFactory(Operation )
    del Sl
    return {'Status':Data['Status'] }



def BundleControl(Operation, ControlOperationFlags ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Data = Sl.sl_NvmemBundleControl(Operation, ControlOperationFlags)
    del Sl
    return {'Status':Data['Status'], 'BundleState':Data['BundleState'] }

def BundleGetStateCounters():
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    BundleData = Sl.sl_NvmemBundleControl(BUNDLE_CTL_GET_STATE_REQUEST, 0)
    if BundleData['Status'] != 0:
        raise Exception("Status error")
    ControlOperationFlags =  FILE_SYS_CTL_FLAG_BUNDLECLOSEDFILES | FILE_SYS_CTL_FLAG_BUNDLEABORTOFOPENEDWRITEFILE | FILE_SYS_CTL_FLAG_BUNDLEOPENEDREADFILES
    Data = Sl.sl_NvmemFileSystemControlCounters(0, FILE_SYS_CTL_GET_FILES_COUNTERS_REQUEST, ControlOperationFlags)
    if Data['Status'] != 0:
        raise Exception("Status error")
    del Sl
    return { 'Status':Data['Status'] ,'Token':Data['Token'],'Write':Data['Write'],'Read':Data['Read'],'Closed':Data['Closed'],
             'BundleState':BundleData['BundleState']  }




def Erase(FileName, Token ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemEraseByName(FileName, Token)
    del Sl
    return {'Status':Result['Status'] }

def FsProgramming(HostFileName, KeyFileName ):
    KeySize = 0
    Key = ''
    MaxDataSize = 0
    Data =''

    ExtendedError = 0
    RetVal = 0

    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))

    if( KeyFileName != None ) and ( KeyFileName!= ""):
        fInput =  open(KeyFileName, 'r')
        Key = fInput.read(16)
        KeySize = 16
        fInput.close()

    if( HostFileName != None )and ( HostFileName!= ""):
        fInput =  open(HostFileName, 'rb')
        fInputSize = os.path.getsize(HostFileName)
        MaxDataSize = fInputSize

    if( MaxDataSize == 0 ):
        RetVal, ExtendedError  = Sl.sl_NvmemFsProgramming( KeySize, MaxDataSize, Key, Data )
    else:
        Offset = 0
        DataSize = MaxDataSize
        while Offset < MaxDataSize:
            ChunkSize = min(MAX_CHUNK_WRITE_SIZE, DataSize )
            Data = fInput.read( ChunkSize )
            print "send programming chunk ,offset = %d, chunk size= %d" %(Offset,ChunkSize)
            RetVal, ExtendedError  = Sl.sl_NvmemFsProgramming( KeySize, ChunkSize, Key, Data )
            if( (RetVal < 0) or ( RetVal == 0)):
                break;
            Offset += ChunkSize
            DataSize -= ChunkSize
    fInput.close()
    del Sl
    return { RetVal, ExtendedError }


