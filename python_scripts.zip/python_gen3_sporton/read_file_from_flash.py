import configurations as conf
import options
from simple_link_api import SimpleLinkDevice
import simple_link_api
import sys
import os
import utils
import string


MAX_CHUNK_READ_SIZE        = 1408   #better performance to use align 16
ANY_DEVICE                 = 0xFF

def read_file(NWPfilename,fileid,Length, fToken = 0):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpen(fileid, simple_link_api._FS_MODE_OPEN_READ, 0, 2, fToken )
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    Offset = 0
    FileContent = ""
    if fHdl > 0:
        while (Offset < Length):
            chunck = min(MAX_CHUNK_READ_SIZE, Length-Offset)
            buf = Sl.sl_NvmemRead(fHdl,Offset,chunck)
            Offset += len(buf)
            FileContent += buf
            if (len(buf) != chunck):
                break
        Sl.sl_NvmemClose(fHdl)

    fOut = open(NWPfilename, 'wb')
    fOut.write(FileContent)
    fOut.close()
    del Sl
    return {'fToken':fToken }


def read_fileByName(filename, NWPFileName,Length, fToken = 0 ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName( NWPFileName, simple_link_api._FS_MODE_OPEN_READ, Length, ANY_DEVICE, fToken)
    fHdl = -1
    fHdl = Result['fHdl']
    if( fHdl & 0x80000000 ):
        print "Handle = 0x%x" %( fHdl )
        return
    fToken = Result['fToken']
    Offset = 0
    FileContent = ""
    if fHdl > 0:
        while (Offset < Length):
            chunck = min(MAX_CHUNK_READ_SIZE, Length-Offset)
            buf = Sl.sl_NvmemRead(fHdl,Offset,chunck)
            Offset += len(buf)
            FileContent += buf
            if (len(buf) != chunck):
                break
        Sl.sl_NvmemClose(fHdl)

    fOut = open(filename, 'wb')
    fOut.write(FileContent)
    fOut.close()
    del Sl
    return {'fToken':fToken }

def open_read_fileByNameDebug( NWPFileName, fToken = 0 ):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemOpenByName( NWPFileName, simple_link_api._FS_MODE_OPEN_READ, 0, 2, fToken)
    fHdl = Result['fHdl']
    fToken = Result['fToken']
    del Sl
    return {'fToken':fToken ,'fHdl':fHdl }

def read_fileAnCloseDebug(filename, fHdl,Length):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Offset = 0
    FileContent = ""
    if fHdl > 0:
        while (Offset < Length):
            chunck = min(MAX_CHUNK_READ_SIZE, Length-Offset)
            buf = Sl.sl_NvmemRead(fHdl,Offset,chunck)
            Offset += len(buf)
            FileContent += buf
            if (len(buf) != chunck):
                break
        Sl.sl_NvmemClose(fHdl)

    fOut = open(filename, 'wb')
    fOut.write(FileContent)
    fOut.close()
    del Sl

def Get_fileInfoByName(filename, fToken = 0):
    Opts = options.TIOptions("")
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    Result = Sl.sl_NvmemInfoByName( filename, fToken)
    return {'Status':Result['Status'], 'Flags':Result['Flags'],'FileSize':Result['FileSize'],'FileMaxSize':Result['FileMaxSize'],'fMasterToken':Result['fMasterToken'], 'fWriteReadToken':Result['fWriteReadToken'], 'fWriteToken':Result['fWriteToken'], 'fReadToken':Result['fReadToken'],'SizeOnDevice':Result['SizeOnDevice'],'WriteCounter':Result['WriteCounter']  }
    del Sl


if __name__ == '__main__':
    if len(sys.argv)< 2:
        print "\n\nError: Wrong Number of Parameters!!!\n\nSyntax:\n"
        print "read_file_from_flash.py  [NWP file id or NWP FileName] [Host file name] [max size][Token]"
        print "Example : read_file_from_flash.py  \'file.txt\'  c:\file.txt  5000 0 "
    else:
        FileName = sys.argv[1]
        HostFileName = sys.argv[2]
        if FileName[0] == '\'':
            print "NWP File Name: " + sys.argv[1]
            print "Host File Name:" + sys.argv[2]
            print "Length: " + sys.argv[3]
            try:
                print "Token: " + sys.argv[4]
                Token = sys.argv[4]
            except :
                Token = 0
                pass


            NewFileName = FileName.replace("'", "")
            NewHostFileName = HostFileName.replace("'", "")

            print "NWP file name = " + NewFileName +", Host file name = " + NewHostFileName

            read_fileByName(NewHostFileName, NewFileName,int(sys.argv[3]), Token)
        else:
            print "File ID: " + sys.argv[1]
            print "NWP File Name: " + sys.argv[2]
            print "Length: " + sys.argv[3]
            read_file(sys.argv[2], int(FileName),int(sys.argv[3]))