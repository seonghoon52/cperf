import sys
import time
import TICore
import configurations as conf
import string
import options
import binascii
from struct import unpack, pack
import msvcrt
import utils
import Tracer
import ConfigParser
from array import array
import struct
import ctypes



SL_RET_TO_F_SET_DATA_FILE_NAME = 0x2
SL_RET_TO_F_SET_PROGRAM_FILE_NAME = 0x4
FS_GET_FILE_ATTRIBUTES = 0x1

DEFAULT_CMD_INVOKE_TIMEOUT              = 10000
DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT       = 10000

WLAN_CONNECT_SEC_TYPE_OPEN              = 0
WLAN_CONNECT_SEC_TYPE_WEP               = 1
WLAN_CONNECT_SEC_TYPE_WPA               = 2
WLAN_CONNECT_SEC_TYPE_WPS_PBC           = 3
WLAN_CONNECT_SEC_TYPE_WPS_PIN           = 4
WLAN_CONNECT_SEC_TYPE_ENTERPRISE        = 5
WLAN_CONNECT_SEC_TYPE_P2P        		= 6


_FS_MODE_OPEN_READ  = 0
_FS_MODE_OPEN_WRITE  = 1
_FS_MODE_OPEN_CREATE = 2
_FS_MODE_OPEN_WRITE_CREATE_IF_NOT_EXIST = 3
_FS_MODE_OPEN_WRITE_READ = 4
_FS_MODE_OPEN_WRITE_READ_CREATE_IF_NOT_EXIST = 5
_FS_MODE_OPEN_CREATE_READ = 6


#write file modes:



PHASE1_TLS = 0
PHASE1_TTLS = 1
PHASE1_PEAP = 2
PHASE1_FAST = 3

PHASE2_MSCHAP = 0
PHASE2_TLS = 1
PHASE2_PSK = 2

FAST_PROV_DISABLED = 0
FAST_PROV_UNAUTH = 1
FAST_PROV_AUTH = 2

FILE_SYS_CTL_RET_TO_FACTORY = 0

FileSizeGranularities ={0:256, 1:1024, 2:4096, 3:16384, 4:65536}


FsFileAccessFlags = {
   "FILE_OPEN_FLAG_FAILSAFE" : 1,
   "FILE_OPEN_FLAG_SECURE" : 2,
   "FILE_OPEN_FLAG_NO_SIGNATURE_TEST" : 4,
   "FILE_OPEN_FLAG_STATIC" : 8 ,
   "FILE_OPEN_FLAG_VENDOR": 16,
   "FILE_OPEN_FLAG_WRITE_WITHOUT_TOKEN": 32,
   "FILE_OPEN_FLAG_READ_WITHOUT_TOKEN": 64,
   "FILE_OPEN_FLAG_COMMIT_MODE": 128,
   "FILE_OPEN_FLAG_BUNDLE_COMMIT_MODE": 256,
}




class DataStream(bytearray):


    def append(self, v, fmt='>B'):
        self.extend(struct.pack(fmt, v))





def BuildEapBitmask(EapType, Phase2Type, PeapVersion, FastProvisioning, PairwiseCipher, GroupCipher):

    #init values
    Phase1 = 0
    Phase2 = 0

    if EapType == PHASE1_TLS:
        #TLS
        Phase1 = 0x1
    elif EapType == PHASE1_TTLS:
        #TTLS
        Phase1 = 0x10

    elif EapType == PHASE1_PEAP:
        #PEAP
        if PeapVersion == 0:
            #PEAP0
            Phase1 = 0x20
        elif PeapVersion == 1:
            #PEAP1
            Phase1 = 0x40
        else:
            print('invalid peap version')
            exit()
    elif EapType == PHASE1_FAST:
        #FAST
        Phase1 = 0x80
        if FastProvisioning == FAST_PROV_DISABLED:
            #Disabled
            Phase2 = 0
        elif FastProvisioning == FAST_PROV_UNAUTH:
            #unauthenticated
            Phase2 = 1
        elif FastProvisioning == FAST_PROV_AUTH:
            #authenticated
            Phase2 = 2
        else:
            print('invalid fast provisioning')
            exit()

    if EapType == PHASE1_TTLS or EapType == PHASE1_PEAP:
        #TTLS or PEAP
        if Phase2Type == PHASE2_MSCHAP:
            #MSCHAP
            Phase2 = 0
        elif Phase2Type == PHASE2_TLS:
            #TLS
            Phase2 = 1
        elif Phase2Type == PHASE2_PSK:
            #PSK
            Phase2 = 2
        else:
            print('invlaid phase 2')
            exit()

##    print "phase1: %x" % Phase1
    mask = Phase1
##    print "mask: %x" % mask
##    print "phase2: %x" % Phase2
    mask |= (Phase2 << 8)
##    print "mask: %x" % mask
##    print "PairwiseCipher: %x" % PairwiseCipher
    mask |= (PairwiseCipher << 16)
##    print "mask: %x" % mask
##    print "GroupCipher: %x" % GroupCipher
    mask |= (GroupCipher << 24)
##    print "mask: %x" % mask

    return mask

CIPHER_TKIP = 1 << 3
CIPHER_AES = 1 << 4
CIPHER_ALL = CIPHER_TKIP | CIPHER_AES

WLAN_CONNECT_ENT_TLS =                      BuildEapBitmask(PHASE1_TLS,  0,             0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_TTLS_TLS =                 BuildEapBitmask(PHASE1_TTLS, PHASE2_TLS,    0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_TTLS_MSCHAPv2 =            BuildEapBitmask(PHASE1_TTLS, PHASE2_MSCHAP, 0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_TTLS_PSK  =                BuildEapBitmask(PHASE1_TTLS, PHASE2_PSK,    0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP0_TLS =                BuildEapBitmask(PHASE1_PEAP, PHASE2_TLS,    0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP0_MSCHAPv2 =           BuildEapBitmask(PHASE1_PEAP, PHASE2_MSCHAP, 0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP0_PSK =                BuildEapBitmask(PHASE1_PEAP, PHASE2_PSK,    0, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP1_TLS =                BuildEapBitmask(PHASE1_PEAP, PHASE2_TLS,    1, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP1_MSCHAPv2 =           BuildEapBitmask(PHASE1_PEAP, PHASE2_MSCHAP, 1, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_PEAP1_PSK =                BuildEapBitmask(PHASE1_PEAP, PHASE2_PSK,    1, 0,                 CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_FAST_AUTH_PROVISIONING =   BuildEapBitmask(PHASE1_FAST, 0,             0, FAST_PROV_AUTH,    CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_FAST_UNAUTH_PROVISIONING = BuildEapBitmask(PHASE1_FAST, 0,             0, FAST_PROV_UNAUTH,  CIPHER_ALL, CIPHER_ALL)
WLAN_CONNECT_ENT_FAST_NO_PROVISIONING =     BuildEapBitmask(PHASE1_FAST, 0,             0, FAST_PROV_DISABLED,CIPHER_ALL, CIPHER_ALL)

class SimpleLinkDevice(object):
    def __init__(self,SerialPortNum, PrintEnable=False, BaudRate=conf.SERIAL_BAUD_RATE):
        self.Tracer = Tracer.Tracer("SimpleLinkAPI_Trace", 64, PrintEnable)
        self.PrintEnable = PrintEnable
        self.SL_API_LOG("Open SimpleLinkDevice [Port=%d]\n"%SerialPortNum)
        self.core = TICore.TICore(PrintEnable)
        self.core.initialize1(SerialPortNum, BaudRate)
        self.core.TracePrintToStdoutEnable = PrintEnable
        self.core._logToStdout = PrintEnable
        self.ConvertFileNameToId = ConfigParser.ConfigParser()
        self.ConvertFileNameToId.read("ConvertFileNameToId.txt")

    def SL_API_LOG(self, str):
        if (self.PrintEnable):
            print str
        self.Tracer.write(str)

    def __del__(self):
        self.core.close()
        self.SL_API_LOG("SimpleLinkDevice Closed\n")
        self.Tracer.close()
        del self.core

    def sl_Suspend(self):
        self.SL_API_LOG("sl_Suspend()\n")
        self.core.InvokeSLCommand("DEVICE", "SUSPEND", DEFAULT_CMD_INVOKE_TIMEOUT)

    def sl_Resume(self):
        self.SL_API_LOG("sl_Resume()\n")
        self.core.InvokeSLCommand("DEVICE", "RESUME", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("cc_DEVICE_RESUME",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        if retVal:
            self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
            self.SL_API_LOG("Resume Status: {0}".format(Data[4]))
            return Data[4]
        else:
            return -1

    def sl_EventMaskSet(self,EventClass,Mask):
        self.SL_API_LOG("sl_EventMaskSet(%d,%d)\n"%(EventClass,Mask))
        self.core.InvokeSLCommand("DEVICE", "EVENT_MASK_SET", DEFAULT_CMD_INVOKE_TIMEOUT, EventClass, Mask)
        retVal,Data = self.core.waitEvent("cc_DEVICE_EVENT_MASK_SET",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        if retVal:
            self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
            self.SL_API_LOG("Set Status: {0}".format(Data[4]))
            return Data[4]
        else:
            return -1

    def sl_EventMaskGet(self,EventClass):
        self.SL_API_LOG("sl_EventMaskGet(%d)\n"%(EventClass))
        self.core.InvokeSLCommand("DEVICE", "EVENT_MASK_GET", DEFAULT_CMD_INVOKE_TIMEOUT, EventClass)
        retVal,Data = self.core.waitEvent("cc_DEVICE_EVENT_MASK_GET",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        if retVal:
            self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
            self.SL_API_LOG("Mask: {0}".format(Data[4]))
            return Data[4]
        else:
            return -1

    def sl_WlanStatusGet(self):
        self.SL_API_LOG("sl_WlanStatusGet()\n")
        self.core.InvokeSLCommand("WLAN", "STATUS_GET", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("cc_WLAN_STATUS_GET",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        if retVal:
            self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
            self.SL_API_LOG("WlanStatus: {0}".format(Data[4]))
            return Data[4]
        else:
            return -1

    def sl_DebugMemRead(self,Address,Len):
        self.SL_API_LOG("sl_DebugMemRead(%d,%d)\n"%(Address,Len))
        self.core.InvokeSLCommand("RAM", "READ", DEFAULT_CMD_INVOKE_TIMEOUT, Len, 0, Address)
        retVal,Data = self.core.waitEvent("cc_RAM_READ",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if (Data != None):
            self.SL_API_LOG("Data: {:}".format(unpack(Len*"B", Data[6])))
            return Data[6]
        else:
            return None

    def sl_DebugMemWrite(self,Address,Len,WriteData):
        self.SL_API_LOG("sl_DebugMemWrite(%d,%d,"%(Address,Len))
        self.SL_API_LOG("Data: {:}".format(unpack(Len*"B", WriteData)))
        self.core.InvokeSLCommand("RAM", "WRITE", DEFAULT_CMD_INVOKE_TIMEOUT, Len, 0, Address, WriteData)
        retVal,Data = self.core.waitEvent("cc_RAM_WRITE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        self.SL_API_LOG("Writen Length: {0}".format(Data[4]))

    def sl_WlanConnect(self, SecType, Ssid, Password, User, AnonUser, CertIndex, EapBitMask, timeout = None ):
        self.SL_API_LOG("sl_WlanConnect({:}, {:}, {:})".format(SecType, Ssid, Password))
        rc = -1
        if None == timeout:
            timeout = DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT
        if (WLAN_CONNECT_SEC_TYPE_WEP == SecType):
            Password = binascii.a2b_hex(Password.rjust(10,'0'))
        if (WLAN_CONNECT_SEC_TYPE_ENTERPRISE == SecType):
            self.core.InvokeSLCommand("WLAN", "CONNECT_EAP", timeout, SecType, len(Ssid), 0, 0, len(Password), len(User), len(AnonUser), CertIndex, EapBitMask, Ssid, Password, User, AnonUser)
            retVal,Data = self.core.waitEvent("cc_WLAN_CONNECT_EAP",[],timeout)
        else:
            self.core.InvokeSLCommand("WLAN", "CONNECT", timeout, SecType, len(Ssid), 0, 0, len(Password), Ssid, Password)
            retVal,Data = self.core.waitEvent("cc_WLAN_CONNECT",[],timeout)
        if retVal:
            if 0 == Data[4]:
                retVal,Data = self.core.waitEvent("Connected_Async_Event", [], timeout )
                if retVal:
                    rc = 0
                retVal, Data = self.core.waitEvent("IPACQUIRED_Async_Event", [], timeout)
                if retVal:
                    fmt = "4B"
                    ip =        unpack(fmt, Data[4])
                    gateway =   unpack(fmt, Data[5])
                    dns =       unpack(fmt, Data[6])
                    self.SL_API_LOG("\n\n")
                    self.SL_API_LOG("IP acquired : ")
                    self.SL_API_LOG("IP={:d} {:d} {:d} {:d}"             .format(*ip[::-1]))
                    self.SL_API_LOG("Gateway={:d} {:d} {:d} {:d} "       .format(*gateway[::-1]))
                    self.SL_API_LOG("DNS={:d} {:d} {:d} {:d} "           .format(*dns[::-1]))
                    self.SL_API_LOG("\n\n")
        return rc


    def _GenerateAccessMode(self, SizeInBytes, MirrorEnable, AccessType, Secure , Vendor, Static, NoSignature,OpenForPublicWrite,OpenForPublicRead, CommitMode,BundleMode ):
        SelectedGran = None
        SelectedIndex = None
        for GranIndex in FileSizeGranularities:
            Gran = FileSizeGranularities[GranIndex]
            if (Gran*255 >= SizeInBytes):
                SelectedGran = Gran
                SelectedIndex = GranIndex
                break
        if (None == SelectedGran):
            raise Exception("Error, size out of range!")
        NumOfGrans = SizeInBytes / SelectedGran
        if ((SizeInBytes % SelectedGran) != 0):
            NumOfGrans += 1
        SizeBitmap = (SelectedIndex<<8 | NumOfGrans)

        ##########
        #AccessType = FsFileAccessTypes[InputAccessType]
        ###########
        Flags = 0
        if (MirrorEnable):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_FAILSAFE"]

        if( Secure ):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_SECURE"]

        if( Vendor ):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_VENDOR"]

        if( Static ):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_STATIC"]

        if( NoSignature ):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_NO_SIGNATURE_TEST"]

        if( OpenForPublicWrite ):
            Flags |= FsFileAccessFlags["FILE_OPEN_FLAG_WRITE_WITHOUT_TOKEN"]

        if( OpenForPublicRead ):
            Flags |= FsFileAccessFlags[ "FILE_OPEN_FLAG_READ_WITHOUT_TOKEN"]

        if( CommitMode ):
            Flags |= FsFileAccessFlags[ "FILE_OPEN_FLAG_COMMIT_MODE"]

        if( BundleMode ):
            Flags |= FsFileAccessFlags[ "FILE_OPEN_FLAG_BUNDLE_COMMIT_MODE"]


        ##########
        return ( (Flags& 0x1FF )<< 16 ) | ((AccessType & 0xF) <<12) | (SizeBitmap & 0x0FFF)

##typedef struct
#{
#    UINT32  Size:8;         //low bits
#    UINT32  SizeGran:4;      // See FsFileOpenMaxSizeGran_e
#    UINT32  AccessType:4;   // See FsFileOpenAccessType_e
#    UINT32  Flags:9;        // See FileOpenFlags_e
#    UINT32  Reserved:7;     //High bits
#}FileCreateMode_t;



    def sl_ScanResultsGet(self,index):
        self.SL_API_LOG("sl_ScanResultsGet(%d)\n"%(index))
        self.core.InvokeSLCommand("WLAN", "GETSCANRES", DEFAULT_CMD_INVOKE_TIMEOUT, index)
        retVal,Data = self.core.waitEvent("cc_WLAN_GETSCANRES",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

        self.SL_API_LOG("SSID:"+ str(Data[11]))

        bssid = ""
        for b in Data[4]:
           bssid += hex(ord(b)) + " "
        self.SL_API_LOG("BSSID:" + str(bssid))

        self.SL_API_LOG("Security type: {0}".format(Data[6]))
        self.SL_API_LOG("FrameTime: {0}".format(Data[7]))
        self.SL_API_LOG("SSID:")
        self.SL_API_LOG("{:}".format(unpack(Len*"B", Data[8])))
        self.SL_API_LOG("BSSID:")
        self.SL_API_LOG("{:}".format(unpack(Len*"B", Data[9])))
        return 0

    def sl_NvmemOpen(self, FileId, AccessType, MaxSize, DeviceId=-1, Token = 0, Mirror = False, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, CommitMode = 0, BundleMode = 0):
        self.SL_API_LOG("sl_NvmemOpen(%s,%d,%d,%d)"%(FileId,AccessType,MaxSize,DeviceId))
        filename = self.ConvertFileNameToId.get("main", str(FileId) ) + "\0"
        mode = self._GenerateAccessMode( MaxSize, Mirror, AccessType, Secure , Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead, CommitMode, BundleMode )
        self.core.InvokeSLCommand("NVMEM", "OPEN",DEFAULT_CMD_INVOKE_TIMEOUT, mode, Token, filename )
        retVal,Data = self.core.waitEvent("cc_NVMEM_OPEN",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return {'fHdl':Data[4], 'fToken':Data[5] }

    def sl_NvmemOpenByName(self, filename, AccessType, MaxSize, DeviceId=-1, Token = 0, Mirror = False, Secure = 0 , Vendor = 0, Static = 0, NoSignature = 1, OpenForPublicWrite = 0, OpenForPublicRead = 0, CommitMode = 0, BundleMode = 0):
        self.SL_API_LOG("sl_NvmemOpen(%s,%d,%d,%d)"%(filename ,AccessType,MaxSize,DeviceId))
        mode = self._GenerateAccessMode( MaxSize, Mirror, AccessType, Secure , Vendor, Static, NoSignature, OpenForPublicWrite, OpenForPublicRead, CommitMode, BundleMode )
        self.core.InvokeSLCommand("NVMEM", "OPEN",DEFAULT_CMD_INVOKE_TIMEOUT, mode, Token, filename+"\0")
        retVal,Data = self.core.waitEvent("cc_NVMEM_OPEN",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if( retVal == True ):
            if( Data[4] > 0):
                return {'fHdl':Data[4], 'fToken':Data[5] }
            else:
                print "************************** Error = ",Data[4]
                return {'fHdl':Data[4] }
        else:
            print "********************** Error = ",retVal
        #return fHndl,fToken


    def sl_NvmemClose(self, FileHdl, Signature="" , CertificationFileName = ""):
        self.SL_API_LOG("sl_NvmemClose(%d)"%(FileHdl))
        self.core.InvokeSLCommand("NVMEM", "CLOSE",DEFAULT_CMD_INVOKE_TIMEOUT, FileHdl, len(CertificationFileName), len(Signature ), CertificationFileName , Signature )
        retVal,Data = self.core.waitEvent("cc_NVMEM_CLOSE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return Data[4]

    def sl_NvmemInfo(self, FileId, fToken=0 ):
        self.SL_API_LOG("sl_NvmemInfo(%d)"%(FileId))
        filename = self.ConvertFileNameToId.get("main", str(FileId) )  + "\0"
        self.core.InvokeSLCommand("NVMEM", "GINFO",DEFAULT_CMD_INVOKE_TIMEOUT, fToken, filename )
        retVal,Data = self.core.waitEvent("cc_NVMEM_GINFO",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        return {'Status':Data[4], 'Flags':Data[5],'FileSize':Data[6],'FileMaxSize':Data[7],'fMasterToken':Data[8],'fWriteRead':Data[9],'fWrite':Data[10], 'fReadToken':Data[11],'SizeOnDevice':Data[12],'WriteCounter':Data[13]  }

    def sl_NvmemInfoByName(self, FileName, fToken=0 ):
        self.SL_API_LOG("sl_NvmemInfo(%s)"%(FileName))
        self.core.InvokeSLCommand("NVMEM", "GINFO",DEFAULT_CMD_INVOKE_TIMEOUT, fToken, FileName+ '\0' )
        retVal,Data = self.core.waitEvent("cc_NVMEM_GINFO",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        return {'Status':Data[4], 'Flags':Data[5],'FileSize':Data[6],'FileMaxSize':Data[7],'fMasterToken':Data[8],'fWriteReadToken':Data[9],'fWriteToken':Data[10], 'fReadToken':Data[11],'SizeOnDevice':Data[12],'WriteCounter':Data[13] }


    def sl_NvmemRead(self, FileHdl, Offset, Len):
        self.SL_API_LOG("sl_NvmemRead(%d,%d,%d)"%(FileHdl,Offset, Len))
        self.core.InvokeSLCommand("NVMEM", "READ",DEFAULT_CMD_INVOKE_TIMEOUT, FileHdl,Offset, Len, 0)
        retVal,Data = self.core.waitEvent("cc_NVMEM_READ",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if ( not (Data[4] & 0x8000)):
            return Data[6]
        else:
            self.SL_API_LOG("Error while reading")
            return Data[4]

    def sl_NvmemWrite(self, FileHdl, Offset, Buff, Len, FormatBuffer= True):
        self.SL_API_LOG("sl_NvmemWrite(%d,%d,%s,%d)"%(FileHdl,Len,Buff,Offset))
        if FormatBuffer:
            FormattedBuffer = "%x"%ord(Buff[0])
            for byte in Buff[1:]:
                FormattedBuffer += ":"+"%x"%ord(byte)
        else:
            FormattedBuffer = Buff
        self.core.InvokeSLCommand("NVMEM", "WRITE",DEFAULT_CMD_INVOKE_TIMEOUT, FileHdl, Offset,Len, 0, FormattedBuffer)
        retVal,Data = self.core.waitEvent("cc_NVMEM_WRITE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return retVal

#typedef enum
#{
#    FSPROGRAM_DOWNLOAD_IMAGE_FIRST_CHUNK = 1,
#    FSPROGRAM_DOWNLOAD_IMAGE_IS_ENCRYPTED = 2,
#    FSPROGRAM_DOWNLOAD_IMAGE_USE_EXISTING_FILE_SYSTEM = 4,
#    FSPROGRAM_DOWNLOAD_IMAGE_RESTART_PROGRAMMING = 8,
#}FsProgrammingFlags_t;

    def sl_NvmemFsProgramming( self, KeySize, ChunkSize, Key, CunkData ):
        self.SL_API_LOG("sl_NvmemFsProgramming")
        FLags = 0

        self.core.InvokeSLCommand("NVMEM", "FS_PROGRAMMING",DEFAULT_CMD_INVOKE_TIMEOUT,KeySize, ChunkSize, FLags, Key+CunkData)
        retVal,Data = self.core.waitEvent("cc_FS_PROGRAMMING",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT * 2 )
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if( retVal == True ):
            Status = ctypes.c_long(Data[4]).value
            if( Status == 0 ):
                print '\tStatus= %d'%(Status)
                return Status,0
            if( Status > 0 ):
                print "\tNumOfBytesRecieved = %d"%(Status)
                return Status,0
            if( Status < 0 ):
                RetVal  = (ctypes.c_short((Data[4] & 0xFFFF0000)>> 16 )).value
                ExtendedError = (ctypes.c_ushort((Data[4] & 0xFFFF) )).value
                print "\tRetVal = %d, ExtendedError = %d"%(RetVal, ExtendedError)
                return RetVal, ExtendedError
        else:
            print "Failed To send chunk"
            return retVal,0


    def sl_NvmemFormat(self):
        self.SL_API_LOG("sl_NvmemFormat()")
        self.core.InvokeSLCommand("NVMEM", "FORMAT",DEFAULT_CMD_INVOKE_TIMEOUT, 2)
        retVal,Data = self.core.waitEvent("cc_NVMEM_FORMAT",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_NvmemErase(self, FileID, fToken = 0 ):
        self.SL_API_LOG("sl_NvmemErase(%d)"%FileID)
        filename = self.ConvertFileNameToId.get("main", str(FileID) )  + "\0"
        self.core.InvokeSLCommand("NVMEM", "ERASE",DEFAULT_CMD_INVOKE_TIMEOUT, fToken, filename)
        retVal,Data = self.core.waitEvent("cc_NVMEM_ERASE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_NvmemEraseByName(self, fileName, fToken = 0 ):
        self.SL_API_LOG("sl_NvmemErase(%s)"%fileName)
        self.core.InvokeSLCommand("NVMEM", "ERASE",DEFAULT_CMD_INVOKE_TIMEOUT, fToken, fileName + '\0')
        retVal,Data = self.core.waitEvent("cc_NVMEM_ERASE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return {'Status':Data[4] }



    def sl_NvmemGetFileList(self, Index, MaxEntryLen, BufferSize ):
        self.SL_API_LOG("sl_NvmemGetFileList")
        Count = BufferSize / MaxEntryLen
        Flags = FS_GET_FILE_ATTRIBUTES
        self.core.InvokeSLCommand("NVMEM", "GETFILELIST",DEFAULT_CMD_INVOKE_TIMEOUT, Index, Count ,MaxEntryLen, Flags)
        retVal,Data = self.core.waitEvent("cc_NVMEM_GETFILELIST",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if( Data == None):
            return {'NumOfEntries':-1, 'Index':-1 ,'NumOfFilesRead':0}
        if( Data[4] > 0 ):
            return {'NumOfEntries':Data[4], 'Index':Data[5] , 'FileList':Data[7]}
        else:
            return {'NumOfEntries':Data[4], 'Index':Data[5] }


    def sl_NvmemFileSystemControl(self, Token, Operation, ControlOperationFlags, FileName):
        self.SL_API_LOG("sl_NvmemFileSystemControl(%s)"%FileName )
        Padding = '000'
        Padding2 = 0

        buf = DataStream()

        buf.append(ControlOperationFlags, "H")
        buf.append(Padding2, "H")
        FileFmt ="%ds"%(len(FileName + '\0'))
        buf.append(FileName + '\0', FileFmt)

        HexBuf = str(buf)
        self.core.InvokeSLCommand("NVMEM", "FILE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, Token, Operation, Padding, len(FileName + '\0'), 4 , HexBuf )
        retVal,Data = self.core.waitEvent("cc_NVMEM_FILE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        if(Data[6] > 0 ):
            return {'Status':Data[4],'Token':Data[5],'buferLen':Data[6],'buffer':Data[7]}
        else:
            return {'Status':Data[4],'Token':Data[5],'buferLen':Data[6]}

#typedef struct
#{
#  _u16 DeviceBlockSize;
#  _u16 DeviceBlocksCapacity;
#  _u16 NumOfAllocatedBlocks;
#  _u16 NumOfReservedBlocks;
#  _u16 NumOfReservedBlocksForSystemfiles;
#  _u16 LargestAllocatedGapInBlocks;
#  _u8  Padding[4];
#} SlFsControlDeviceUsage_t;
#
#typedef struct
#{
#  _u8  MaxFsFiles;
#  _u8  IsDevlopmentFormatType;
#  _u8  Bundlestate; /*see SlFsBundleState_e*/
#  _u8  Reserved; /*see SlM4BundleState_e*/
#  _u8  MaxFsFilesReservedForSysFiles;
#  _u8  ActualNumOfUserFiles;
#  _u8  ActualNumOfSysFiles;
#  _u8  Padding;
#  _u32 NumOfAlerts;
#}SlFsControlFilesUsage_t;

    def sl_NvmemFileSystemControlGetInfo(self, Token, Operation, FileName, DevName  ):
        self.SL_API_LOG("sl_NvmemFileSystemControl(%s)"%FileName )
        Padding = '000'
        if( DevName == "" ):
            DevLength = 0
        else:
            DevLength = len(DevName+ '\0')
        self.core.InvokeSLCommand("NVMEM", "FILE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, Token, Operation,Padding, 0, DevLength, DevName + '\0' )
        retVal,Data = self.core.waitEvent("cc_NVMEM_FILE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

        OutputBufLen = Data[6]
        Response = struct.unpack("<HHHHHHHHBBBBBBBBLLHH", Data[7])
        ResponseDict = {}
        ResponseDict["01. DeviceBlockSize"]                    = Response[0]
        ResponseDict["02. DeviceBlocksCapacity"]               = Response[1]
        ResponseDict["03. NumOfAllocatedBlocks"]               = Response[2]
        ResponseDict["04. NumOfReservedBlocks"]                = Response[3]
        ResponseDict["05. NumOfReservedBlocksForSystemfiles"]  = Response[4]
        ResponseDict["07. LargestAllocatedGapInBlocks"]        = Response[5]
        ResponseDict["06. NumOfAvailableBlocksForUserFiles"]   = Response[6]
        #ResponseDict["Padding1"]                            = Response[7]
        ResponseDict["11. MaxFsFiles"]                         = Response[8]
        ResponseDict["08. IsDevlopmentFormatType"]             = Response[9]
        ResponseDict["09. BundleState"]                        = Response[10]
        ResponseDict["10. CC3200_BundleState"]                 = Response[11]
        ResponseDict["12. MaxFsFilesReservedForSysFiles"]      = Response[12]
        ResponseDict["13. ActualNumberOfUserFiles"]            = Response[13]
        ResponseDict["14. ActualNumOfSysFiles"]                = Response[14]
        #ResponseDict["Padding2"]                           = Response[15]
        ResponseDict["16. NumberOfAlert"]                     = Response[16]
        ResponseDict["15. NumOfAlertsThreshold"]               = Response[17]
        ResponseDict["17. FATWriteCounter"]                    = Response[18]
        #ResponseDict["15. Padding"]                           = Response[19]

        return  ResponseDict


    def sl_NvmemFileSystemControlRename(self, Token, Operation, OldFileName, NewFileName ):
        Padding = "000"
        buff =  OldFileName + '\0'+ NewFileName + '\0'
        self.core.InvokeSLCommand("NVMEM", "FILE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, Token, Operation, Padding, len(OldFileName + '\0'), len(NewFileName + '\0') , buff )
        retVal,Data = self.core.waitEvent("cc_NVMEM_FILE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return {'Status':Data[4],'Token':Data[5]}


#typedef enum
#{
#    FACTORY_RET_TO_IMAGE =  0,
#    FACTORY_RET_TO_DEFAULT_KEEP_CALIB = 1,
#    FACTORY_RET_TO_DEFAULT = 2,
#}RetToFactoryOper_t;
#
    def sl_NvmemFileSystemControlRetToFactory(self, Operation  ):
        Padding = "000"
        buf = DataStream()
        buf.append(Operation, "<L")
        HexBuf = str(buf)

        self.core.InvokeSLCommand("NVMEM", "FILE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, 0, FILE_SYS_CTL_RET_TO_FACTORY, Padding, 0, len(HexBuf) , HexBuf)
        retVal,Data = self.core.waitEvent("cc_NVMEM_FILE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT * 2)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return {'Status':Data[4],'Token':Data[5]}


    def sl_NvmemFileSystemControlCounters(self, Token, Operation, ControlOperationFlags  ):
        Padding = "000"
        Padding2 = 0
        buf = DataStream()
        buf.append(ControlOperationFlags, "H")
        buf.append(Padding2, "H")
        HexBuf = str(buf)
        self.core.InvokeSLCommand("NVMEM", "FILE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, Token, Operation, Padding, 0, 4, HexBuf )
        retVal,Data = self.core.waitEvent("cc_NVMEM_FILE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

        OutputBufLen = Data[6]
        if (OutputBufLen > 0 ):

            BufferData = struct.unpack("HBBBBBB", Data[7])
            return {'Status':Data[4],'Token':Data[5],
                    'ControlFlags':BufferData[0],
                    'Write':BufferData[1],
                    'Read':BufferData[2],
                    'Closed':BufferData[3],
                    'OpenedForWriteCntWithValidMirr':BufferData[4],
                    'OpeneForReadCntWithTwoMirror':BufferData[5],
                    'ClosedFilesCntWithTwoMirror':BufferData[6]}
        else:
            return {'Status':Data[4],'Token':Data[5],'buferLen':Data[6]}





    def sl_NvmemBundleControl(self, Operation, ControlOperationFlags ):
        self.SL_API_LOG("sl_NvmemFilesOperation" )
        self.core.InvokeSLCommand("NVMEM", "BUNDLE_CONTROL",DEFAULT_CMD_INVOKE_TIMEOUT, ControlOperationFlags, Operation )
        retVal,Data = self.core.waitEvent("cc_NVMEM_BUNDLE_CONTROL",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        return {'Status':Data[4] ,'BundleState':Data[5] }



    def sl_GetProfile(self, ProfileId):
        self.SL_API_LOG("sl_GetProfile(%d)"%ProfileId)
        self.core.InvokeSLCommand("WLAN", "GETPROFILE",DEFAULT_CMD_INVOKE_TIMEOUT, ProfileId)
        retVal,Data = self.core.waitEvent("cc_WLAN_GETPROFILE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_DelProfile(self, ProfileId):
        self.SL_API_LOG("sl_DelProfile(%d)"%ProfileId)
        self.core.InvokeSLCommand("WLAN", "DELPROFILE",DEFAULT_CMD_INVOKE_TIMEOUT, ProfileId)
        retVal,Data = self.core.waitEvent("cc_WLAN_DELPROFILE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_SetPolicyNew(self, PolicyType, PolicyMask, ScanInterval):
        self.SL_API_LOG("sl_SetPolicyNew(%d,%d,%d)"%(PolicyType, PolicyMask, ScanInterval))
        self.core.InvokeSLCommand("WLAN", "SETCONNPOLNEW",DEFAULT_CMD_INVOKE_TIMEOUT, PolicyType, 0, PolicyMask, ScanInterval)
        retVal,Data = self.core.waitEvent("cc_WLAN_SETCONNPOLNEW",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_GetPolicyNew(self, PolicyType):
        self.SL_API_LOG("sl_GetPolicyNew(%d)"%(PolicyType))
        self.core.InvokeSLCommand("WLAN", "GETCONNPOLNEW",DEFAULT_CMD_INVOKE_TIMEOUT, PolicyType, 0, 0, 0)
        retVal,Data = self.core.waitEvent("cc_WLAN_GETCONNPOLNEW",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_SetScanParam(self, minDwellTime, maxDwellTime, numProbeResponse, G_Channels_mask, rssiThershold, snrThershold, defaultTXPower, intervalList):
        self.SL_API_LOG("sl_SetScanParam(%d,%d,%d,%d,%d,%d,%d,%s)"%(minDwellTime, maxDwellTime, numProbeResponse, G_Channels_mask, rssiThershold, snrThershold, defaultTXPower, intervalList))
        self.core.InvokeSLCommand("WLAN", "SETSCANPARAM",DEFAULT_CMD_INVOKE_TIMEOUT, minDwellTime, maxDwellTime, numProbeResponse, G_Channels_mask, rssiThershold, snrThershold, defaultTXPower, intervalList)
        retVal,Data = self.core.waitEvent("cc_WLAN_SETSCANPARAM",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_IpConfigGet(self):
        self.SL_API_LOG("sl_IpConfigGet()")
        self.core.InvokeSLCommand("NETAPP", "IPCONFIG", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("cc_NETAPP_IPCONFIG",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_ArpFlush(self):
        self.SL_API_LOG("sl_ArpFlush()")
        self.core.InvokeSLCommand("NETAPP", "ARPFLUSH", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("SL_OPCODE_NETAPP_ARPFLUSH",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_GetHostByName(self, family, hostName):
        self.SL_API_LOG("sl_GetHostByName(%d,%s)"%(family, hostName))
        self.core.InvokeSLCommand("NETAPP", "GETHOSTBYNAME", DEFAULT_CMD_INVOKE_TIMEOUT, len(hostName), family, 0, hostName)
        retVal,Data = self.core.waitEvent("SL_OPCODE_NETAPP_DNSGETHOSTBYNAME",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_PingStart(self, DstIP, totalNumberOfAttempts, pingRequestSize, pingRequestTimeout, pingIntervalTime):
        self.SL_API_LOG("sl_GetHostByName(%d,%d,%d,%d,%d)"%(DstIP, totalNumberOfAttempts, pingRequestSize, pingRequestTimeout, pingIntervalTime))
        self.core.InvokeSLCommand("NETAPP", "PINGSEND", 2, pingIntervalTime, pingRequestSize, pingRequestTimeout, totalNumberOfAttempts,  DstIP, 0, 0, 0)
        retVal,Data = self.core.waitEvent("SL_OPCODE_NETAPP_PINGSTART",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))


    def sl_PingReport(self):
        self.SL_API_LOG("sl_PingReport()")
        self.core.InvokeSLCommand("NETAPP", "PINGREPORT", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("SL_OPCODE_NETAPP_PINGREPORTREQUEST",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))


    def sl_PingStop(self):
        self.SL_API_LOG("sl_PingStop()")
        self.core.InvokeSLCommand("NETAPP", "PINGSTOP", DEFAULT_CMD_INVOKE_TIMEOUT)
        retVal,Data = self.core.waitEvent("SL_OPCODE_NETAPP_PINGSTOP",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_SetCliBaudRate(self, BaudRate, FlowControlEnable):
        self.SL_API_LOG("sl_SetCliBaudRate @ {:}".format(BaudRate))
        self.core.InvokeSLCommand("HOST", "SET_UART_MODE", DEFAULT_CMD_INVOKE_TIMEOUT, BaudRate, FlowControlEnable)
        retVal,Data = self.core.waitEvent("cc_SET_UART_MODE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        self.core.Reconnect(conf.SERIAL_COM_PORT-1, BaudRate)
        if (Data == None):
            self.SL_API_LOG("UART baud rate change failed!")

    def sl_Rigster_UnRegister_Service(self, pServiceName, ServiceNameLen, pText, TextLen, Port, TTL, Options):
        self.SL_API_LOG("sl_SetScanParam(%s,%d,%s,%d,%d,%d,%d)"%(pServiceName, int(ServiceNameLen), pText, int(TextLen), int(Port), int(TTL), int(Options)))
        print("sl_SetScanParam(%s,%d,%s,%d,%d,%d,%d)"%(pServiceName, int(ServiceNameLen), pText, int(TextLen), int(Port), int(TTL), int(Options)))
        self.core.InvokeSLCommand("NETAPP", "REGISTER_UNREGISTER_SERVICE" , DEFAULT_CMD_INVOKE_TIMEOUT, ServiceNameLen, TextLen, Port, TTL, Options, pServiceName ,pText )
        retVal,Data = self.core.waitEvent("cc_NETAPP_REGISTER_UNREGISTER_SERVICE",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        print("retVal: {0} ; Data: {1}".format(retVal,Data))

    def sl_get_service_list(self, indexOffset, MaxServiceCount, Flags, Reserved):
        print("get_service_list params(%d,%d,%d)"%( int(indexOffset),int(MaxServiceCount), int(Flags)))
        self.core.InvokeSLCommand("NETAPP", "GET_SERVICE_LIST" , DEFAULT_CMD_INVOKE_TIMEOUT, indexOffset, MaxServiceCount, Flags,Reserved )
        retVal,Data = self.core.waitEvent("cc_GET_SERVICE_LIST",[],DEFAULT_CMD_COMPLETE_WAIT_TIMEOUT)
        self.SL_API_LOG("retVal: {0} ; Data: {1}".format(retVal,Data))
        print("retVal: {0} ; Data: {1}".format(retVal,Data))
        ############################################################
        return Data

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    Sl = SimpleLinkDevice(int(Opts.GetVal('SerialPort')))
    #Sl.sl_NvmemFormat()
    #Sl.sl_NvmemInfo(11)
    #Sl.sl_Suspend()
    #Sl.sl_Resume()
    #Sl.sl_WlanStatusGet()
    #Sl.sl_EventMaskSet(16,1234567)
    #Sl.sl_EventMaskGet(16)
    #Sl.sl_GetProfile(0)
    #Sl.sl_GetProfile(1)
    #Sl.sl_GetProfile(2)
    #Sl.sl_DelProfile(0)
    #Sl.sl_SetPolicyNew(16,3,0)
    #Sl.sl_SetPolicyNew(32,1,1000)
    #Sl.sl_GetPolicyNew(16)
    #Sl.sl_GetPolicyNew(32)
    #Sl.sl_SetScanParam(30, 60, 3, 1025, 70, 0, 10, '13:88:27:10:4E:20:4E:20')
    #Sl.sl_DebugMemWrite(0x200427a0,4, "\x05\x06\x07\x08")
    #Sl.sl_DebugMemRead(0x200427a0,4)
    #Sl.sl_WlanConnectOpen("asaf")
    #Sl.sl_WlanConnect(1,"asaf","1234567890", "", "", 0, 0)
    #Sl.sl_WlanConnect(2,"asaf","12345678", "", "", 0, 0)
    #Sl.sl_ScanResultsGet(0)
    #Sl.sl_ScanResultsGet(1)
    #Sl.sl_IpConfigGet()
    #Sl.sl_ArpFlush()
    #Sl.sl_GetHostByName(2, "google.com")
    #Sl.sl_PingStart(0xC0A827F0, 10, 100, 0, 100)
    #Sl.sl_PingReport()
    #Sl.sl_PingStop()
    utils.waitForEscKeypress()
    del Sl
