
import sys
import time
import TICore
import configurations as conf
import string
import options


def wlan_set_mode(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: mode: 
    #ROLE_STA   =   0,
    #ROLE_AP    =   2,
    #ROLE_P2P   =   3

	
    core.InvokeSLCommand("WLAN", "WLAN_SET_MODE",1, 0)

#    core.waitAndPrintAnyEvent()
    core.waitEvent("Wlan_Set_Mode_Command_Event",[],500000)
#    core.waitEvent("Smart_Config_Stop_Command_Event",[],5000)
    
    core.close()
    sys.exit("WLAN Set Mode ended")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    wlan_set_mode(Opts)