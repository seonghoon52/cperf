
import sys
import time
import TICore
import configurations as conf
import string
import options
import binascii
import msvcrt

def wlan_connect(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    SSID = Opts.GetVal('SSID')
    Key = Opts.GetVal('key')
    SecType = int(Opts.GetVal('Security'))
    if (1 == SecType):
        if (26 == len(Key)):  ##key is configured to hex
            Key = binascii.a2b_hex(Key.rjust(26,'0'))

    print('SecType: ' + str(SecType))
    print('Key: ' + Key)
    print('SSID:' + SSID)
    core.InvokeSLCommand("WLAN", "CONNECT",1, SecType, len(SSID), 0, 0, len(Key), SSID, Key)
    print("Press Esc to Exit")
    while msvcrt.getch() != chr(27):
        time.sleep(1)

    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    wlan_connect(Opts)