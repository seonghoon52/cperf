#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      x0020132
#
# Created:     05/06/2011
# Copyright:   (c) x0020132 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import sys
import collections
import threading
import serial
from time import sleep


class Receiver(object):
    def __init__(self, transport, callback, interface):
        self._th = threading.Thread(target=self._receive)
        self._transport = transport
        self._callback = callback
        self._buff = ""
        self._stop = False
        self._Stopped = True
        self._interface = interface
    def _receive(self):
        pass

    def start(self):
        self._th.start()

    def stop(self):
        self._stop = True
        return

    def __del__(self):
        self.stop()


class SerialReceiver(Receiver):
    def _receive(self):
        while not self._stop:
            #print("rx")
            try:
                if( self._interface == "ETH"):
                        self._buff += self._transport.recv(10000)
                        if self._buff == "":
                            print "internal socket closed by other side"
                            break # other side close
                else:
                    self._buff += self._transport.read()
                    waiting = self._transport.inWaiting()
                    if waiting > 0:
                        self._buff += self._transport.read(waiting)
                self._callback(self._buff)
                self._buff = ""
            except serial.SerialException as ex:
                sys.stderr.write("{0}\n".format(ex))

            except serial.portNotOpenError:
                break
            except ValueError:
                break
            except Exception, e:
                if( self._interface == "ETH"):
                    if e.errno == 10035: # ignore if "A non-blocking socket receive return without data
                        pass
                    else:
                        #print e
                        break
                else:
                    #print e
                    break
        self._Stopped = True


class EventProtocol(object):
    def __init__(self, callbacks=None):
        self._buff = ""
        self._events = collections.deque()
        if callbacks is None:
            self._callbacks = []
        else:
            self._callbacks = callbacks

    def _callback(self, buff):
        self._buff += buff

        if self._callbacks:
            for callback in self._callbacks:
                try:
                    self._buff = callback(self._buff)
                #except:
                finally:
                    pass

    def addCallback(self, func):
        self._callbacks.append(func)

    def clearEvents(self):
        self._events.clear()

    def hasEvents(self):
        return bool(self._events)


