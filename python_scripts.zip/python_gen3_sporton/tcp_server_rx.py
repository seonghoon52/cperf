#-------------------------------------------------------------------------------
# Name:        tcp_server_rx.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf


core = TICore.TICore()
core.loadSpec("SL2_proto.xml")
core.connectSerial(16, 115200)


def main():

    core.InvokeSLCommand("BSD", "SOCKET"    , 0.1, 2, 1, 0)
    core.InvokeSLCommand("BSD", "BIND"      , 0.1, 0, 3, "02:0A:1A")
    core.InvokeSLCommand("BSD", "LISTEN"    , 0.1, 0, 0)
    core.InvokeSLCommand("BSD", "ACCEPT"    , 0.1, 0)

    max = 1000000
    i = 0
    while i < max:
        core.InvokeSLCommand("BSD", "RECV"  , 0.05, 0, 1460, 0)
        i = i+1

    core.close()
    sys.exit("TCP Server Rx test finished")


if __name__ == '__main__':
    main()