
import sys
import time
import TICore
import configurations as conf
import string
import options


def netapp_set(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))


    #Example For Event Mask
    #0xFFFF00FF in order to filter IPP than write it form the LSB to MSB
    core.InvokeSLCommand("NETAPP", "NETAPPSET_TIMING_PARAMS",2, 0, 4, 3, 24, sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6])


    core.waitEvent("cc_NETAPP_NETAPPSETRESPONSE",[],5000)
    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPSET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_set(Opts)