#-------------------------------------------------------------------------------
# Name:        udp_rx.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf


core = TICore.TICore()
core.initialize1()


def main():

    core.InvokeSLCommand("BSD", "SOCKET"    , 2, 2, 2, 0)
    core.InvokeSLCommand("BSD", "BIND"      , 2, 3, 3, "02:0A:1A")

    t0 = time.clock()
    while time.clock() - t0 < 10:
        core.InvokeSLCommand("BSD", "RECVFROM", 2, 3, 100, 0)

    core.close()
    sys.exit("UDP Rx test finished")


if __name__ == '__main__':
    main()