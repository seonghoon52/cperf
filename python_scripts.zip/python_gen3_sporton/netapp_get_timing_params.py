
import sys
import time
import TICore
import configurations as conf
import string
import options
import struct


def netapp_get(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: status = 0
    #            app ID: HTTP = 1, DHCP = 2
    #            configOpt = 0 (Basic)
    #            Config  Len = 0

    core.InvokeSLCommand("NETAPP", "NETAPPGET",2, 0, 4, 3, 0)


    #core.waitAndPrintAnyEvent()

    #core.waitEvent("cc_NETAPP_NETAPPGETRESPONSE",[],5000)
    retVal,Data = core.waitEvent("cc_NETAPP_NETAPPGETRESPONSE",[],5000)
    print("retVal: {0} ; Data: {1}".format(retVal,Data))

    print("Satus %d \n  "%( int(Data[4])))

    BufferStr = Data[8]

    Res =struct.unpack('<llllll', (BufferStr)[0: 24])
    #IP = IP[::-1]


    print("t %d \n p %d \n k %d \n RetransInterval %d \n Maxinterval 0x%x \n max_time %d \n\n"%(Res[0],Res[1],Res[2],Res[3],Res[4],Res[5]))
    #print("t %d \n p %d \n k %d \n RetransInterval %d \n Maxinterval %d \n max_time %d \n\n"%(int(Data[6][0]),int(Data[6][4]),int(Data[6][8]),int(Data[6][12]),int(Data[6][16]),int(Data[6][20])))


    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPGET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_get(Opts)