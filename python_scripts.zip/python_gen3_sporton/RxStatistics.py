#-------------------------------------------------------------------------------
# Name:        test_cmd_wlan.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf
import utils
import BsdUtils
import BSD_Test_configurations as slConf
import inspect
import argparse
import struct
import string
import options
import binascii
import msvcrt

core = TICore.TICore()
core.initialize1()
slBsdHandle = BsdUtils.BsdUtils(core)

def StartRxStatistics():
    core.InvokeSLCommand("WLAN", "START_RX_STATISTICS"  ,2)
    return
    
def StopRxStatistics():
    core.InvokeSLCommand("WLAN", "STOP_RX_STATISTICS"   ,2)
    return
    
def GetRxStatistics():
    core.InvokeSLCommand("WLAN", "GET_RX_STATISTICS"    ,2)
    retVal = core.waitEvent("cc_GET_RX_STATISTICS", [], 50000 )
    return


def main():
    #open raw socket on channel 11 and call receive once to start receiving traffic
    ret = slBsdHandle.Socket( slConf.AF_RF, slConf.SOCK_RAW, 11 )    
    ret1 = slBsdHandle.Recv(ret[1],1460,0)
       
    raw_input("Press Any key to start collecting statistics")
    StartRxStatistics()
    
    
    raw_input("Press any key to receive the collected statistics")
    retVal = GetRxStatistics()

    
    raw_input("Press any key to stop collecting statistics")
    StopRxStatistics()
       
    ret1 = slBsdHandle.Close( ret[1] )
    core.close()
    sys.exit("WLAN Commands test finished")

if __name__ == '__main__':
    main()