#-------------------------------------------------------------------------------
# Name:        print_stat.py
# Purpose:
#
# Author:      a0387680
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf
import struct


core = TICore.TICore()
core.initialize1()

def main():

    ret = core.InvokeSLCommand("DEVICE", "DEVICEGET",2,0,1,12,0)
    ret = core.waitEvent("cc_DEVICEGET", [], 100000 )
    str = struct.unpack("=IIIIIBBBBIIIIHH", (ret[1])[8])

    print "CHIP ID: %x" %str[0]
    print "Firmware Version: SL 31.%d.%d.%d.%d"  %(str[1],str[2],str[3],str[4])
    print "PHY Version: %d.%d.%d.%d"  %( str[5],str[6],str[7],str[8])
    print "SimpleLink_%d.%d.%d.%d" %( str[9],str[10],str[11],str[12])
    print "ROM Version: %d" % str[13]
    core.close()
    sys.exit("Print status finished")


if __name__ == '__main__':
    main()