
import sys
import time
import TICore
import configurations as conf
import string
import options


###########################
#     Set Parameters:     #
###########################
CountryCode = 'US'
StaTxPowerLevelBackoff = 0  # [0-15] (0 - Max Tx power, 15 - Min Tx Power)
ApTxPowerLevelBackoff  = 0  # [0-15] (0 - Max Tx power, 15 - Min Tx Power)
StaRssi = -70
StaChannelMask = 0x1FFF
###########################

# CfgId = 1 (SL_WLAN_CFG_GENERAL_PARAM_ID)    

def wlan_cfg_set(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #set Country_code
    country_len = len(CountryCode)
    #                   ( self,    groupName,   silo, status, CfgId, ConfigOpt, Configlen,    arg      )
    core.InvokeSLCommand("WLAN", "WLAN_CFG_SET", 1,     0,      1,     9,    country_len,  CountryCode )
    core.waitEvent("WLAN_CFG_SET_RESPONSE",[],500000)
    
   	#set StaTxPower
    core.InvokeSLCommand("WLAN", "WLAN_CFG_SET", 1,     0,      1,     10,         4,   StaTxPowerLevelBackoff)
    core.waitEvent("WLAN_CFG_SET_RESPONSE",[],500000)

   	#set ApTxPower
    core.InvokeSLCommand("WLAN", "WLAN_CFG_SET", 1,     0,      1,     11,         4,   ApTxPowerLevelBackoff )
    core.waitEvent("WLAN_CFG_SET_RESPONSE",[],500000)

   	#set sta scan params
    core.InvokeSLCommand("WLAN", "WLAN_CFG_SET", 1,     0,      1,     18,        8,   StaChannelMask,StaRssi)

    core.waitEvent("WLAN_CFG_SET_RESPONSE",[],500000)

    core.close()
    sys.exit("NETAPPSET ended")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    wlan_cfg_set(Opts)