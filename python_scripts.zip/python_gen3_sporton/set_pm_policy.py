
import sys
import time
import TICore
import configurations as conf
import string
import options
import struct

#  PowerMgtBitMask:
#------------------
#PM_MGT_MAC_FORCE_AWAKE_BIT	              ('1' - Disable ELP         , '0' - Enable ELP         ) = 0x01 <-- BIT_0
#PM_MGT_MAC_FORCE_ACTIVE_MODE_BIT         ('1' - ALWAYS_ACTIVE       , '0' - Auto PS            ) = 0x02 <-- BIT_1
#PM_MGT_NWP_DISABLE_LPDS_BIT              ('1' - Disable LPDS        , '0' - Enable LPDS        ) = 0x04 <-- BIT_2
#PM_MGT_NWP_DISABLE_CORTEX_GATING_BIT     ('1' - Disable CortexGating, '0' - Enable CortexGating) = 0x08 <-- BIT_3
#PM_MGT_MAC_LONG_DOZE_BIT                 ('1' - Long Doze            ,'0' - Short Doze         ) = 0x10 <-- BIT_4
#PM_MGT_MAC_MANUAL_N_DTIM_CALCULATION_BIT ('1' - Enable Manual DTIM  , '0' - Disable Manual DTIM) = 0x20 <-- BIT_5
    

#Configured Policy Types:
NORMAL_POLICY               = 0
LOW_LATENCY_POLICY          = 1
LOW_POWER_POLICY            = 2
ALWAYS_ON_POLICY            = 3
LONG_SLEEP_INTERVAL_POLICY  = 4
DEBUG_POLICY                = 5
#       ||
#       ||
#       ||
#       \/
SELECTED_POLICY  = 5



#PM Policy Possible Configured Params
PowerMgtBitMask               = "00"    #Must be UINT8  --> 2 nibbles- XY 
NwpPredictionThreshold        = "14"    #Must be UINT8  --> 2 nibbles- XY 
MacAutoPsModeThreshold        = "40:00" #Must be UINT16 --> 4 nibbles- XX:YY <== XX is the LSB and YY is the MSB
MaxDesiredSleepTimeThreshold  = "01:00" #Must be UINT16 --> 4 nibbles- XX:YY <== XX is the LSB and YY is the MSB
ExitPsTxRxFramesThreshold     = "02:01" #Must be UINT16 --> 4 nibbles- XX:YY <== XX is the LSB and YY is the MSB
#       ||
#       ||                    
#       ||
#       \/
DebugParamsBuff = PowerMgtBitMask + ":" + NwpPredictionThreshold + ":" + MacAutoPsModeThreshold + ":" + MaxDesiredSleepTimeThreshold + ":" + ExitPsTxRxFramesThreshold


def conn_policy(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    core.InvokeSLCommand("WLAN", "SETCONNPOL", 1000, 0x30, 0, SELECTED_POLICY, 8, DebugParamsBuff)
    time.sleep(1)
    core.close()
    sys.exit("Connect Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    conn_policy(Opts)