
import sys
import time
import TICore
import configurations as conf
import string
import options


def netapp_set(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: status = 0
    #            app ID: HTTP = 1, DHCP = 2
    #            configOpt = 0 (Basic)
    #            Config  Len = 12
    #            DHCP Data: lease_time, ipv4_start_addr, ipv4_stop_addr
    #
    # Note 1: to set lease time to 0x1122, ipv4_start_addr to 12.02.11.70 and ipv4_stop_addr to 12.02.11.77 use the following
    #         core.InvokeSLCommand("NETAPP", "NETAPPSET",2, 0, 2, 0, 12, "22:11:00:00:46:0B:02:0C:4C:0B:02:0C")
    #
    # Note 2: lease time must be greater than renew time and rebind time

    #core.InvokeSLCommand("NETAPP", "NETAPPSET",2, 0, 2, 0, 12, "22:11:00:00:08:08:08:08:4C:08:08:08")
    #core.InvokeSLCommand("NETAPP", "NETAPPSET",2, 0, 2, 0, 12, "22:11:00:00:33:C9:C9:C9:4C:C9:C9:C9")



    #Example For Event Mask
    #0xFFFF00FF in order to filter IPP than write it form the LSB to MSB
    core.InvokeSLCommand("NETAPP", "NETAPPSET_CONTINUOUS_QUERY",2, 0, 4, 1, len(sys.argv[1]), sys.argv[1])

    #Example For continuous query
    # - Write the name of the continouos query
    #core.InvokeSLCommand("NETAPP", "NETAPPSET",2, 0, 4, 1, 22, "birbir._ipp._tcp.local")


    #core.waitAndPrintAnyEvent()

    core.waitEvent("cc_NETAPP_NETAPPSETRESPONSE",[],5000)
    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPSET")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_set(Opts)