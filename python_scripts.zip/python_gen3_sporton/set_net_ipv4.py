
import sys
import time
import TICore
import configurations as conf
import string
import options
import socket


def SET_NET_CFG(dhcp, ipv4, mask, gw, dns):
    core = TICore.TICore()
    core.initialize1()
    print "*********************************************\n"
    val = socket.inet_aton(ipv4)
    bytes = []
    for i in reversed(range(4)):	
        bytes.append( val[i].encode("hex") )
		
    val = socket.inet_aton(mask)	
    for i in reversed(range(4)):	
        bytes.append( val[i].encode("hex") )

    val = socket.inet_aton(gw)		
    for i in reversed(range(4)):	
        bytes.append( val[i].encode("hex") )

    val = socket.inet_aton(dns)		
    for i in reversed(range(4)):	
        bytes.append( val[i].encode("hex") )
		
    if (dhcp):
        addr_mode = 2 # DHCP+LLA
    else:
        addr_mode = 4 # Static
		
    inpVal =  ':'.join(bytes)
	
    core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,7, addr_mode, 16, inpVal)
                                              #delay,status,IPV4 command,option,length,value
    res = core.waitEvent("cc_NETCFG_SET", [], 20000)
     
    core.close()
    sys.exit("GET_NET_CFG Finished")

if __name__ == '__main__':
    if (len(sys.argv) == 5):
        print "Setting IPv4 mode to static"
        dhcp = False
    ipv4 = sys.argv[1]
    mask =  sys.argv[2]
    gw =  sys.argv[3]
    dns = sys.argv[4]
    else:
        print "Setting IPv4 mode to DHCP + LLA"
        dhcp = True
        ipv4 = '0.0.0.0'
        mask = '0.0.0.0'
        gw =  '0.0.0.0'
        dns = '0.0.0.0'
    SET_NET_CFG(dhcp, ipv4, mask, gw, dns)
