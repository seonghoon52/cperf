import utils

WAIT_FOR_EVENT          = -1
USE_INTERNAL_SOCKET_INSTEAD  = 1000
SERIAL_COM_PORT         = 28 #USE_INTERNAL_SOCKET_INSTEAD #22 fpga #6
#SERIAL_COM_PORT         = 20

UART_MODE =  "Normal" # Normal / Legacy / Stellaris
# This switch forces the Python enviroment to use legacy UART configuration and format when set to True

if (UART_MODE == "Normal"):
    SERIAL_BAUD_RATE        = 115200
    SERIAL_FLOW_CTL_EN      = True
    SERIAL_RX_SYNC_PATTERN  = "\xBA\xDC\xCD\xAB"
    SERILA_TX_SYNC_PATTERN  = "\x21\x43\x34\x12"
    XML_PROTO_FILE          = "SL2_proto.xml"
elif (UART_MODE == "Legacy"):
    SERIAL_BAUD_RATE        = 115200
    SERIAL_FLOW_CTL_EN      = False
    SERIAL_RX_SYNC_PATTERN  = "\xDE\xAD\xFA\xCE"
    SERILA_TX_SYNC_PATTERN  = "\xDE\xAD\xFA\xCE"
    XML_PROTO_FILE          = "SL2_Legacy_proto.xml"
elif (UART_MODE == "Stellaris"):
    SERIAL_BAUD_RATE        = 115200
    SERIAL_FLOW_CTL_EN      = False
    SERIAL_RX_SYNC_PATTERN  = "\xBA\xDC\xCD\xAB"
    SERILA_TX_SYNC_PATTERN  = "\x21\x43\x34\x12"
    XML_PROTO_FILE          = "SL2_proto.xml"
else:
    raise Exception("UART_MODE select error!")
    
TX_POOL_LOW_THRESHOLD   = 5
    

SSI_NAME                = "isri"    # Comment  +
KEY                     = '0123456789'
MAC_ADDR                = "08:00:28:19:02:85"   # need to check endianity!



AP_LOCAL_IP_ADDR     = '10.5.9.15'
LOCAL_IP_ADDR        = '10.5.9.15' #'10.5.9.15'
REMOTE_IP_ADDR       = '10.5.9.7'
LOCAL_IPV6_ADDR      = 'fe80::22'
GLOBAL_IPV6_ADDR      = '2001:4040::3'
REMOTE_IPV6_ADDR_LOCAL   = 'fe80::1085:52d2:ce65:1f8a'
REMOTE_IPV6_ADDR_GLOBAL  = '2001:4040::5'
LOCAL_PORT           = '6666'
REMOTE_PORT          = '5000'

REMOTE_IP_ADDR_HEX   = utils.getIpHexStr(REMOTE_IP_ADDR)
LOCAL_PORT_HEX       = utils.getPortHexStr(LOCAL_PORT)
REMOTE_PORT_HEX      = utils.getPortHexStr(REMOTE_PORT)


# IP Common Configuration Parameters for STA_IP_MODE

SL_NETCFG_IF_IPV4_STA = 0x1 #enable ipv4 STA mode
SL_NETCFG_IF_IPV4_AP = 0x2 #enable ipv4 AP mode
SL_NETCFG_IF_IPV6_STA_LOCAL = 0x4  # enable ipv6 Local (default disabled)
SL_NETCFG_IF_IPV6_STA_GLOBAL = 0x8   # enable ipv6 Global (default disabled, local should be enabled first)
SL_NETCFG_IF_DISABLE_IPV4_DHCP = 0x40  # disable ipv4 dhcp
SL_NETCFG_IF_IPV6_LOCAL_STATIC = 0x80   # set ipv6 local as static
SL_NETCFG_IF_IPV6_LOCAL_STATELESS  = 0x100  # set ipv6 local as stateless
SL_NETCFG_IF_IPV6_LOCAL_STATEFUL  = 0x200  # set ipv6 local as statelefull
SL_NETCFG_IF_IPV6_GLOBAL_STATIC   = 0x400  # set ipv6 Global as static
SL_NETCFG_IF_IPV6_GLOBAL_STATEFUL = 0x800  # set ipv6 Global as statefull
SL_NETCFG_IF_DISABLE_IPV4_LLA = 0x1000  # disable LLA feature
SL_NETCFG_IF_ENABLE_DHCP_RELEASE = 0x2000 # Enables DHCP release when WLAN disconnect command is issued
SL_NETCFG_IF_IPV6_GLOBAL_STATLESS = 0x4000  # set ipv6 Global as stateless

IPCONFIG_DHCP_SERVER_ENABLE     = 0  # AP mode, enable dhsp server (default)
IPCONFIG_DHCP_SERVER_DISABLE    = 1  # AP mode, disable dhsp server

##### ############  Common  Configuration ########################################
#SL_NETCFG_IF_IPV6_STA_LOCAL | SL_NETCFG_IF_IPV6_STA_GLOBAL | SL_NETCFG_IF_IPV6_LOCAL_STATEFUL | SL_NETCFG_IF_IPV6_GLOBAL_STATEFUL |SL_NETCFG_IF_DISABLE_IPV4_DHCP
##### ############  STA/P2PCL IP  Configuration ########################################
STA_STATIC_IP                               = LOCAL_IP_ADDR
STA_SUBNET_MASK                             = '255.255.255.0'
STA_DEFAULT_GATEWAY                         = REMOTE_IP_ADDR
STA_IPV4_DNS_SERVER                         = REMOTE_IP_ADDR
STA_IP_MODE                                 = SL_NETCFG_IF_IPV4_STA #| SL_NETCFG_IF_DISABLE_IPV4_DHCP|  SL_NETCFG_IF_IPV6_STA_LOCAL | SL_NETCFG_IF_IPV6_STA_GLOBAL | SL_NETCFG_IF_IPV6_LOCAL_STATELESS | SL_NETCFG_IF_IPV6_GLOBAL_STATLESS#| SL_NETCFG_IF_DISABLE_IPV4_DHCP | SL_NETCFG_IF_IPV6_STA_LOCAL | SL_NETCFG_IF_IPV6_LOCAL_STATIC | SL_NETCFG_IF_IPV6_STA_GLOBAL | SL_NETCFG_IF_IPV6_GLOBAL_STATIC # | SL_NETCFG_IF_IPV6_STA_LOCAL | SL_NETCFG_IF_IPV6_STA_GLOBAL | SL_NETCFG_IF_IPV6_LOCAL_STATEFUL | SL_NETCFG_IF_IPV6_GLOBAL_STATEFUL  #SL_NETCFG_IF_IPV6_STA_LOCAL | SL_NETCFG_IF_IPV6_LOCAL_STATIC | SL_NETCFG_IF_IPV6_STA_GLOBAL | SL_NETCFG_IF_IPV6_GLOBAL_STATIC #
STA_DHCP_RENEW_TIME                         = 500                  # milli seconds
STA_ARP_RENEW_TIME                          = 600                  # milli seconds
STA_KEEP_ALIVE_TIME                         = 300                  # milli seconds
STA_INACTIVITY_TIME                         = 800                  # milli seconds
STA_DNS_CLIENT_TIME                         = 100                  # milli seconds
STA_STATIC_IPV6_GLOBAL_ADDRESS              = GLOBAL_IPV6_ADDR   #IPV6 global address
STA_STATIC_IPV6_LOCAL_ADDRESS               = LOCAL_IPV6_ADDR             #IPV6 local address -> 0::0 == create local addres that base on mac address  (for test 'fe80::abcd')
STA_IPV6_DNS_SERVER                         = '3ffe:b80:17e2::8'
STA_DHCP_SERVER_MODE                        = SL_NETCFG_IF_DISABLE_IPV4_DHCP
STA_DHCP_SERVER_START_IP_ADDRESS            = "192.168.1.100"
STA_DHCP_SERVER_LAST_IP_ADDRESS             = "192.168.1.109"
##### ############  AP/P2PGO IP  Configuration ########################################
AP_STATIC_IP                               = AP_LOCAL_IP_ADDR
AP_SUBNET_MASK                             = '255.255.255.0'
AP_DEFAULT_GATEWAY                         = AP_LOCAL_IP_ADDR
AP_IPV4_DNS_SERVER                         = AP_LOCAL_IP_ADDR
AP_IP_MODE                                 = SL_NETCFG_IF_IPV4_AP | SL_NETCFG_IF_DISABLE_IPV4_DHCP | SL_NETCFG_IF_IPV4_STA
AP_DHCP_RENEW_TIME                         = 500 # seconds
AP_ARP_RENEW_TIME                          = 600                    # milli seconds
AP_KEEP_ALIVE_TIME                         = 300                    # milli seconds
AP_INACTIVITY_TIME                         = 800                    # milli seconds
AP_DNS_CLIENT_TIME                         = 100                    # milli seconds
AP_STATIC_IPV6_GLOBAL_ADDRESS              = '3ffe:b80:17e2::3'     #IPV6 global address
AP_STATIC_IPV6_LOCAL_ADDRESS               = '0::0'                 #IPV6 local address -> 0::0 == create local addres that base on mac address  (for test 'fe80::abcd')
AP_IPV6_DNS_SERVER                         = '3ffe:b80:17e2::8'
AP_DHCP_SERVER_MODE                        =  IPCONFIG_DHCP_SERVER_ENABLE
AP_DHCP_SERVER_START_IP_ADDRESS            = "192.168.1.2"
AP_DHCP_SERVER_LAST_IP_ADDRESS             = "192.168.1.254"
########################################################################################
#p2p conf parameters - set from set_p2p_config_to_flash.py
P2P_DEVICE_TYPE								= "1-0050F204-1"  #"" for deafult
P2P_LISTEN_REG_CLASS						= 81 #0 for deafult
P2P_LISTEN_CHANNEL							= 1  #0 for deafult
P2P_OPER_REG_CLASS							= 81 #0 for deafult
P2P_OPER_CHANNEL							= 1  #0 for deafult
########################################################################################


COMM_TEST_PACKET_LEN = 1440 # MAX size TCP IPV6
COMM_TEST_PORT_NUM  = 5001
COMM_TEST_TIME      = 0
COMM_TEST_PROTOCOL  = 70 # for raw data
# EAP Configuration Parameters
PASSWORD = "" # Password for phase2 EAP-PSK or MSCHAPV2. Password for MSCHAPV2 is a regular string e.g 'password'. Password for EAP-PSK is a 16 byte hex string e.g '123456789abcdef123456789abcdef12'
IDENTITY = "" # User identity
ANONYMOUS_IDENTITY = "" # Anonymous user identity
SECURITY            = 0 #0-Open,1-WEP,2-WPA1,3-WPA2,4-WPS