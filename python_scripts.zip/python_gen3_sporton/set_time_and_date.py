
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf
import utils
import BsdUtils
import BSD_Test_configurations as slConf
import inspect
import argparse
import struct
import string
import options
import binascii
import msvcrt
import datetime



def SetTime():
    core = TICore.TICore()
    core.initialize1()

    dt = time.localtime()   
    tm = struct.pack("=iiiiiiiii", dt.tm_sec,dt.tm_min,dt.tm_hour,dt.tm_mday,dt.tm_mon,dt.tm_year,0,0,0)
        
    print dt
    core.InvokeSLCommand("DEVICE", "DEVICESET" ,2 ,0,1,11,len(tm),tm)
    retVal = core.waitEvent("cc_DEVICESET", [], 50000 )   
    core.close()
    
    return retVal
    


def main():
    #DeleteHtml("index.htm")
    SetTime()



if __name__ == '__main__':
    main()