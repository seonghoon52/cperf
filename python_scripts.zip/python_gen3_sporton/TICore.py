#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      x0020132
#
# Created:     05/06/2011
# Copyright:   (c) x0020132 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import sys
import TISpec4 as TISpec
import TIProtocol
import serial
import threading
import Queue
from struct import unpack

import configurations as conf
import time
import Tracer
import socket

class PacketCounter:
    def __init__(self):
        self.Lock = threading.Lock()
        self.Count = 100 # initial value is high since we do not know how many frames are free at init

    def __del__(self):
        del self.Lock

    def Get(self):
        self.Lock.acquire()
        #Value = self.Count
        # temp solution for the count 0 issue (Yaki & Michael N. , 16/7/13)
        Value = 15
        self.Lock.release()
        return Value

    def Set(self, Value):
        self.Lock.acquire()
        self.Count = Value
        self.Lock.release()

    def Decrement(self):
        self.Lock.acquire()
        self.Count -= 1
        self.Lock.release()


class TICore(object):
    def __init__(self, PrintEnable = False):
        self._logFileName = "log.txt"
        self._logToStdout = False
        self.Tracer = Tracer.Tracer("TiCore_Trace", 64, PrintEnable)
        self.TracePrintToStdoutEnable = PrintEnable
        self.ByteSpacingEnable = not conf.SERIAL_FLOW_CTL_EN

        self._event = threading.Condition()
        self._events = Queue.Queue(50)
        self._PacketCounter = PacketCounter()
        self._TxPoolLowThreshold = conf.TX_POOL_LOW_THRESHOLD

        self._wait = False
        self.ComPort = None
        #Async Events dictionary
        self._asyncEvents = {}

    def Trace(self, message):
        if (self.TracePrintToStdoutEnable):
            print message
        self.Tracer.write(message+"\n")

    def connectSerial(self, com, baud):
        print "connect via UART"

        self._conn = serial.Serial(com, baud, rtscts=conf.SERIAL_FLOW_CTL_EN)

        self._proto = TIProtocol.EventProtocol()
        self._proto.addCallback(self._callback)
        self._serialReceiver = TIProtocol.SerialReceiver(self._conn, self._proto._callback, "UART")
        self._serialReceiver.start()

    def connectInternalSocket(self):
        print "connect via internal socket"
        internal_port = 6789
        try:
            self._conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._conn.connect(("127.0.0.1", internal_port))
        except Exception, e:
            print e
            time.sleep(2)
            try:
                self._conn.connect(("127.0.0.1", internal_port))
            except Exception, e:
                print e
            sys.exit()
        print "connected to internal socket 127.0.0.1 port " , internal_port
        self._conn.setblocking(0) # set socket non blocking
        self._proto = TIProtocol.EventProtocol()
        self._proto.addCallback(self._callback)
        self._serialReceiver = TIProtocol.SerialReceiver(self._conn, self._proto._callback, "ETH")
        self._serialReceiver.start()

    def Reconnect(self, com, baud):
        self._serialReceiver.stop()
        self._conn.flushInput()
        self._conn.flushOutput()
        self._conn.close()
        for i in range(5):
            try:
                self._conn = serial.Serial(com, baud, rtscts=conf.SERIAL_FLOW_CTL_EN)
                break
            except serial.SerialException as ex:
                time.sleep(0.1)
        if (self._conn.isOpen() != True):
            raise Exception("Could not reopen serial port")
        self._serialReceiver = TIProtocol.SerialReceiver(self._conn, self._proto._callback)
        self._serialReceiver.start()

    def loadSpec(self, fileName):
        self._spec = TISpec.TISpec(fileName)

    def initialize1(self, com=None, BaudRate = conf.SERIAL_BAUD_RATE):
        if None == com:
            self.ComPort = conf.SERIAL_COM_PORT-1 #COM port in python is 0 based
        else:
            self.ComPort = com-1 #COM port in python is 0 based
        #self._logToStdout = True
        self.loadSpec(conf.XML_PROTO_FILE)
        if( self.ComPort == conf.USE_INTERNAL_SOCKET_INSTEAD -1):
            self.connectInternalSocket()
        else:
            self.connectSerial(self.ComPort, BaudRate)


        # Register Async Events[DimaM_2.0.0.40]
        self.addAsyncEvent("cc_WLAN_CONNECT", handleAsyncConncted)
        self.addAsyncEvent("Connected_Async_Event", handleAsyncConncted)
        self.addAsyncEvent("Disconnected_Async_Event", handleAsyncDisconnected)
        self.addAsyncEvent("CTST_REPORT_Async_Event", handleCtstReport)
        self.addAsyncEvent("PING_REPORT_Async_Event", handlePingReport)
        self.addAsyncEvent("CONNECTED_VALID_Async_Event", handleAsyncConnctedSuccess)
        self.addAsyncEvent("CONNECTED_INVALID_Async_Event", handleAsyncConnctedNotSuccess)
        self.addAsyncEvent("IPACQUIRED_Async_Event", handleAsyncdhcp)
        self.addAsyncEvent("IPACQUIRED_V6_Async_Event", handleAsyncdhcpIpv6)
        self.addAsyncEvent("ACCEPT_Async_Event", handleAsyncAccept)
        self.addAsyncEvent("CONNECT_Async_Event", handleAsyncConnect)
        self.addAsyncEvent("GETHOSTBYNAME_Async_Event", handleAsyncDns)
        self.addAsyncEvent("GETHOSTBYSERVICE_Async_Event", handleAsyncmDNS)
        self.addAsyncEvent("P2P_DEV_FOUND_Async_Event", handleP2PDevFound)
        self.addAsyncEvent("P2P_NEG_REQ_REC_Async_Event", handleP2PnegReqRecFound)
        self.addAsyncEvent("WLAN_CONN_FAIL_Async_Event", handleWlanConnFailure)



    def close(self):
        self._serialReceiver.stop()
        if( self.ComPort == conf.USE_INTERNAL_SOCKET_INSTEAD -1):
            time.sleep(2)
            self._conn.close()
        else:
            self._conn.flush()
            time.sleep(2)
            self._conn.rtscts=False
            self._conn.close()
        time.sleep(1)
        self.Tracer.close()
        time.sleep(1)
        del self._PacketCounter

    def InvokeSLCommand(self, groupName, command, timeout, *args):
        cmd = self._spec._getCommand(groupName, command)
        args = list(args)
        args.insert(0, cmd._opcode)
        size, data = cmd.produce(args)
        sent=0
        while(self._PacketCounter.Get() < self._TxPoolLowThreshold):
            pass # Waiting for packet pool to free
        self._PacketCounter.Decrement()
        self.Trace("\n-->Sent: {0} {1}".format(groupName, command))
        if (self.ByteSpacingEnable != True):
            # Flow control enabled, can send data at maximal rate
            if( self.ComPort == conf.USE_INTERNAL_SOCKET_INSTEAD -1):
                sent = self._conn.send(data)
            else:
                sent = self._conn.write(data)
        else:
            #Flow control disabled, insert delay between the bytes
            if( self.ComPort == conf.USE_INTERNAL_SOCKET_INSTEAD -1):
                sent = self._conn.send(data)
            else:
                for byte in data:
                    sent += self._conn.write(byte)
                    time.sleep(0.009)#timeout)

        self.Trace("Tx Dump: {0}, size={1}, sent={2}, dump={3}\n".format(command, size, sent, repr([hex(ord(x)) for x in data])))

        try:
            if (timeout == conf.WAIT_FOR_EVENT):
                timeout = None
                item = self._events.get(True, timeout)
                self.Trace( item )
        except Queue.Empty:
            pass

        ## self._conn.write(data)
        return sent

    def _logEvents(self, name, params, data):
        self.Trace("\nEvent: {0} - raw: {1}\n".format(name, data))
        for param, value in zip(params, data):
            self.Trace("{0}: {1}\n".format(param.name, value))

        if self._logToStdout:
            print("\nEvent: {0} - raw: {1}".format(name, data))
            for param, value in zip(params, data):
                print("{0}: {1}".format(param.name, repr(value)))

    def clearEvents(self):
        needToLoop = True
        while( needToLoop ):
            try:
                self._events.get(False)
            except Queue.Empty:
                needToLoop = False


    def waitEvent(self, eventName, data, timeOut):
        t = time.clock() + timeOut / 1000.0
        #print "waitEvent-enter time " + str(t1)
        needToLoop = True
        while needToLoop:
            try:
                event = self._events.get(False)
                if event[0] == eventName:
                    self.Trace("Event: {0}; data: {1}".format(event[0], event[1]))
                    failed = False
                    for item, userItem in zip(event[1], data):
                        if item != userItem and userItem is not None:
                            self.Trace("Expected: {0}; Received: {1}".format(userItem, item))
                            failed = True
                    if not failed:
                        #print "waitEvent-Found Event"
                        return True, event[1]  # found event
            except Queue.Empty:
                pass
            if (time.clock() > t):
                #print "waitEvent-exit time " + str(t2)
                needToLoop = False # timeout over
                self.Trace( "waitEvent-Timeout")
            time.sleep(0.001)

        return False, None

    def waitAndPrintAnyEvent(self):
        while True:
            try:
                event = self._events.get(True)
                self.Trace("Event: {0}; data: {1}".format(event[0], event[1]))
            except Queue.Empty:
                pass

    def _AlignAndVerify(self, buff):
        ''' This funciton will allign the buffer to the firts occurence of the
            Sync pattern (if it exists) and make sure there is at least 1 frame
            inside the buffer'''
        SyncBlock = conf.SERIAL_RX_SYNC_PATTERN
        start = buff.find(SyncBlock)
        if start == -1:
            return False, buff
        if (len(buff[start:]) < 8):
            return False, buff
        Opcode, PayloadLen = unpack("<HH", buff[start+4 : start+8])
        if (len(buff[start+8 :]) < PayloadLen):
            return False, buff
        else:
            return True, buff[start:]


    def _callback(self, buff):                           # parsing  and print event + args
            complete = False

            while True:
                Verified, myBuff = self._AlignAndVerify(buff)
                if not Verified:
                    break
                AsyncRcvEvent = self._spec._events["RECVFROM_Async_Event"]
                complete, newData, params, valuesMatched, totalSize = AsyncRcvEvent.parse(myBuff)
                if complete and valuesMatched:
                    TxPool = (newData[3] & 0xFF) # LSbyte of the devstatus field is the pool information
                    self._PacketCounter.Set(TxPool)
                    try:
                        self._events.put(("RECVFROM_Async_Event", newData), False)
                    except Queue.Full:
                        try:
                            #print "Queue full - delete old , put new"
                            self._events.get(False)
                            self._events.put(("RECVFROM_Async_Event", newData), False)
                        except Queue.Full:
                            #print "Queue full - Fail to put !!!"
                            pass

                    buff = myBuff[totalSize:]
                    break


                for name, event in self._spec._events.iteritems():
                    fail_to_parse = 0
                    #try:
                    complete, newData, params, valuesMatched, totalSize = event.parse(myBuff)
                    #except Exception as ex:
                        #fail_to_parse = fail_to_parse + 1
                        #print "shittt", ex
                        #print(ex)
                        #pass

                    if complete and valuesMatched:
                        self._logEvents(name, params, newData)
                        self.Trace( "Name:"+ repr(name))
                        self.Trace( "data:"+ repr(buff))

                        # Handle Async Events - [DimaM_2.0.0.40]
                        #func = self._asyncEvents.get([name])
                        TxPool = (newData[3] & 0xFF) # LSbyte of the devstatus field is the pool information
                        self._PacketCounter.Set(TxPool)
                        func = self._asyncEvents.get(name)
                        if func is not None:
                            func(name, params, newData)
                        try:
                            if (name != "Dummy_Async_Event"):
                                self._events.put((name, newData), False)
                        except Queue.Full:
                            try:
                                #print "Queue full - delete old , put new"
                                self._events.get(False)
                                self._events.put((name, newData), False)
                            except Queue.Full:
                                #print "Queue full - Fail to put !!!"
                                pass

                        buff = myBuff[totalSize:]
                        break
                if not complete or not valuesMatched:
                    print "Error! Legal frame failed to parse according to XML!"
                    self.Trace("Error! Legal frame failed to parse according to XML!")
                    self.Trace(str([hex(ord(x)) for x in myBuff]))
                    buff = myBuff[totalSize:]
                    break

            return buff

    #[DimaM_2.0.0.40]
    def addAsyncEvent(self, name, func):
        self._asyncEvents[name] = func

    @property
    def logFileName(self):
        return self._logFileName

    @logFileName.setter
    def logFileName(self, value):
        self._logFileName = value

    @property
    def logToStdout(self):
        return self._logToStdout

    @logToStdout.setter
    def logToStdout(self, value):
        self._logToStdout = bool(value)


# Async event callback[DimaM_2.0.0.40]
def handleAsyncConncted(name, params, data):
    print( "AsyncEvent:".format(name))


# Async event callback[DimaM_2.0.0.40]
def handleAsyncDisconnected(name, params, data):
    print( "AsyncEvent:".format(name))

# Async event callback[DimaM_2.0.0.40]
def handleCtstReport(name, params, data):
    print( "AsyncEvent:".format(name))

def handlePingReport(name, params, data):
    print( "AsyncEvent:".format(name))

def handleAsyncConnctedSuccess(name, params, data):
    print( "AsyncEvent:".format(name))

def handleAsyncConnctedNotSuccess(name, params, data):
    print( "AsyncEvent:".format(name))

def handleAsyncdhcp(name, params, data) :
    print( "AsyncEvent:".format(name))

def handleAsyncdhcpIpv6(name, params, data) :
    print( "AsyncEvent:".format(name))
def handleAsyncAccept(name, params, data):
    print( "AsyncEvent:".format(name))
def handleAsyncConnect(name, params, data):
    print("AsyncEvent:".format(name))
def handleAsyncDns(name, params, data):
    print("AsyncEvent:".format(name))
def handleAsyncmDNS(name, params, data):
    print("AsyncEvent:".format(name))
    print("AsyncEvent:".format(data))
def handleP2PDevFound(name, params, data):
    print("AsyncEvent:".format(name))
    print("AsyncEvent:".format(data))
def handleP2PnegReqRecFound(name, params, data):
    print("AsyncEvent:".format(name))
    print("AsyncEvent:".format(data))
def handleWlanConnFailure(name, params, data):
    print("AsyncEvent:".format(name))
    print("AsyncEvent:".format(data))




def main():
    pass

if __name__ == '__main__':
    #main()
    pass


#core = TICore()
#core.loadSpec("c:\\avi3.xml")
#core.logToStdout = True
#core.loadSpec("SL2_proto.xml")
#core.connectSerial(0, 115200)
#raw_input()
#d = core.waitEvent(10000, (4, 1, 2, 1, "0"))
#d = core.waitEvent("Command_Complete_Event_0001", [], 10000)
#print("DD!!: {0}".format(d))
#core.waitEvent(10000, [])
#core.close()
#core._callback("\x04\x01\x00\x03\x00a")
#core._callback("\x04\x02\x00\x02\x000\x04\x02\x00\x02\x001\x04\x02")
#c = core._spec._getCommand("Commands Complete Events", "Command_Complete_SL_NVMem_Write")
#c.parse("\xde\xad\xfa\xce\x04\x84\x02")
#core.send["WLAN Commands"].HCI_HOST_WLAN_CONNECT(0, 0, 0, 0, 0, 8, 0, 0, "test", "")

#core.close()
#a = TICommandProxy(None)
#a.a.a()

#print "testing"
#while True:
#    i = 0
#    arrived, data = core.waitEvent("cc_WLAN_CONNECT", (None, None, None), 1000)
#    if arrived:
#        print "ARRIVED"
#        if data[1] != i:
#            print "FAILED"
#            sys.exit(1)

#        print "PASSED", i
#        i += 1
