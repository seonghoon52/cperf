
import sys
import time
import TICore
import configurations as conf
import string
import options
import utils


def netapp_set(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    #parameters: status = 0
    #            app ID: HTTP = 1, DHCP = 2...
    #            configOpt = 0 (Basic)
    #            Config  Len = 12
    #            DHCP Data: lease_time, ipv4_start_addr, ipv4_stop_addr
    #
    # Note 1: ip addresses must be in the subnet of the ip address which is configured in configurations.py

    lease_time = 50000
    ip_start = utils.getIpHexStr("10.02.11.70", 1)
    ip_stop  = utils.getIpHexStr("10.02.11.79", 1)

    core.InvokeSLCommand("NETAPP", "NETAPPSET",2, 0, 2, 0, 12, lease_time, ip_start, ip_stop)

    #core.waitAndPrintAnyEvent()

    core.waitEvent("cc_NETAPP_NETAPPSETRESPONSE",[],5000)
    #core.waitAndPrintAnyEvent()

    core.close()
    sys.exit("NETAPPSET DHCP Server ended")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    netapp_set(Opts)