#-------------------------------------------------------------------------------
# Name:        stop_ctst.py
# Purpose:
#
# Author:      a0387680
#
# Created:     21/07/2011
# Copyright:   (c) a0387680 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import TICore
import configurations as conf


core = TICore.TICore()
core.initialize1()


def main():


    core.InvokeSLCommand("WLAN", "CTST_STOP"       ,2)

    core.close()
    sys.exit("Start Run Test")


if __name__ == '__main__':
    main()