#-------------------------------------------------------------------------------
# Name:        test_cmd_nvmem.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import options
import  write_file_to_flash as flash
import set_time_and_date as TM
import struct
#import bootldr
import serial

def unpackHEXULONG( data ):
    ret = struct.unpack("L",data)
    return ret[0]

def cleanHex(n):
    return hex(n).replace('0x', '')

#MiniDump configuration
#define MINIDUMP_TRIGGER_ON_NWP_ABORT       0x0001
#define MINIDUMP_TRIGGER_ON_GENERAL_ERROR   0x0002
#define MINIDUMP_DISABLE_MAC_DUMP           0x0008
#define MINIDUMP_TRIGGER_ON_TIMEOUT_EVENTS  0x0010
#define MINIDUMP_TRIGGER_ON_ONTIME_EVENTS   0x0020

#define MAX_TIMEOUT_EVENTS 4
#define MAX_ONTIME_EVENTS  4
#typedef struct
#{
#    UINT32 TriggerBitmap;
#    UINT32 Timeout_Events[MAX_TIMEOUT_EVENTS];
#    UINT32 Timeout_Values[MAX_TIMEOUT_EVENTS];
#    UINT32 Ontime_Events[MAX_ONTIME_EVENTS];
#} sl_protocol_MiniDumpConfigCommand_t;

my_config_buffer = ""

if __name__ == '__main__':
    if len(sys.argv) < 13:
        print "\n\nError: Wrong Number of Parameters!!!"
        print "Run set_mini_dump_config_to_flash.py with the following parameters :"
        print "TriggerBitmap Timeout_Event1 Timeout_Event2 Timeout_Event3 Timeout_Event4 Timeout_Value0 Timeout_Value1 Timeout_Value1 Timeout_Value3 Ontime_Event0 Ontime_Event1 Ontime_Event2 Ontime_Event3 "
        print "For example:"
        print "     Timeout events: SL_OPCODE_DEVICE_INITCOMPLETE, SL_OPCODE_NETAPP_IPACQUIRED"
        print "     Ontime  events: SL_OPCODE_DEVICE_INITCOMPLETE"
        print "  set_mini_dump_config_to_flash.py 0x33    0x0008 0x1825 0 0    0x500 0x700 0 0   0x0008 0 0 0"
        print "For init log, just set timeout on unsupported event:"
        print "     Timeout events: 0x888 unsupported"
        print "  set_mini_dump_config_to_flash.py 0x33    0x0888 0 0 0    0x1500 0 0 0   0 0 0 0"
        print "After setting mini dump configuration file, reset, and activate GetMiniDumpFile.py to get the mini dumps"
        print "     GetMiniDumpFile.py -p 15"
        print "Now it can be dumped using comOcom, open logger on on comOcom port and activate the following command on second comOcom port"
        print "     GetMiniDumpFile.py -v 4 -f MacMiniDump_0003487b.bin"
    else:
        print "TriggerBitmap:  " + sys.argv[1]
        print "Timeout_Events: " + sys.argv[2] + " " + sys.argv[3] + " " + sys.argv[4] + " " + sys.argv[5]
        print "Timeout_Valuse: " + sys.argv[6] + " " + sys.argv[7] + " " + sys.argv[8] + " " + sys.argv[9]
        print "Ontime_Events:  " + sys.argv[10] + " " + sys.argv[11] + " " + sys.argv[12] + " " + sys.argv[13]

    # Michael - convert to binary and write to PC file
	Params = sys.argv[1:]
	Params = [int(i, 16) for i in Params]
	NumOfParams = len(Params)
	Stream = struct.pack('L'*NumOfParams, *Params)

	# ---------- Write to NWP file - by NWP - remove it, NWP stuck once 
	fl = open('tmp.bin', 'wb')
	fl.write(Stream)
	fl.close()
	flash.write_fileByName('tmp.bin', '/sys/mdmpcfg.ini')
##  raw_input("")

##	# ---------- Write to NWP file by bootloader
##  Port = conf.SERIAL_COM_PORT
##  # Connect to target board
##  ldr = bootldr.BootLdr(com_port=Port ,trace_level=2)
##  ldr.connect(30000) 
##  # raw_input("")
##  print "Writing MiniDump configuration"
##  FileProperties = bootldr._FileProperties("/sys/mdmpcfg.ini"+'\0', Secure=False, NoSignature=True)
##  ldr.DownloadBufferToFile(FileProperties, Stream)

    sys.exit("Write to file commands finished")


