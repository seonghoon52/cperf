import sys
import time
import TICore
import options
import string
import configurations as conf


def stop_tx_cont(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')

    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    core.InvokeSLCommand("WLAN", "STOP_TX_CONTINUES"       ,2)

    core.close()


if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    stop_tx_cont(Opts)
    sys.exit('TX_CONT complete')



    