#-------------------------------------------------------------------------------
# Name:        set_p2p_config_to_flash.py
# Purpose:
#
# Author:      Gilboa Shveki
#
# Created:
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import options
import  write_file_to_flash as flash


my_config_file = ""

def main():

#P2P Device Type
    my_config_file = utils.str2HexPadded(conf.P2P_DEVICE_TYPE,17)
#P2P Device listen and oper channels
    my_config_file = my_config_file + utils.dec2cleanHex(conf.P2P_LISTEN_REG_CLASS) + ":" + utils.dec2cleanHex(conf.P2P_LISTEN_CHANNEL) + ":" + utils.dec2cleanHex(conf.P2P_OPER_REG_CLASS) + ":" + utils.dec2cleanHex(conf.P2P_OPER_CHANNEL)

    print my_config_file

    flash.write_buffer(my_config_file, 19,0)

    sys.exit("Write to file commands finished")


if __name__ == '__main__':
    main()
