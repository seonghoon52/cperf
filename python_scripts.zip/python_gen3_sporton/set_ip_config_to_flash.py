#-------------------------------------------------------------------------------
# Name:        test_cmd_nvmem.py
# Purpose:
#
# Author:      x0068467
#
# Created:     21/07/2011
# Copyright:   (c) x0068467 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python


import sys
import time
import configurations as conf
import utils
import options
import  write_file_to_flash as flash
import set_time_and_date as TM
import TICore
import socket

SL_NEFCFG_IF_STATE    =        (0)
SL_NETCFG_ADDR_DHCP =          (1)
SL_NETCFG_ADDR_DHCP_LLA  =     (2)
SL_NETCFG_ADDR_RELEASE_IP =    (3)
SL_NETCFG_ADDR_STATIC	  =    (4)
SL_NETCFG_ADDR_STATELESS  =    (5)
SL_NETCFG_ADDR_STATEFUL   =    (6)
SL_NETCFG_ADDR_RELEASE_IP_SET =(7)
SL_NETCFG_ADDR_RELEASE_IP_OFF = (8)

SL_NETCFG_IF		                        = 6
SL_NETCFG_IPV4_STA_ADDR_MODE			    = 7
SL_NETCFG_IPV4_AP_ADDR_MODE			        = 8
SL_NETCFG_IPV6_ADDR_LOCAL				    = 9
SL_NETCFG_IPV6_ADDR_GLOBAL				    = 10

#define SL_NETCFG_IF_IPV6_STA_LOCAL                        (0x4)    /* disable ipv6 local */
#define SL_NETCFG_IF_IPV6_STA_GLOBAL					   (0x8)    /* disable ipv6 global */
#define SL_NETCFG_IF_DISABLE_IPV4_DHCP                     (0x40)   /* disable ipv4 dhcp */
#define SL_NETCFG_IF_IPV6_LOCAL_STATIC                     (0x80)   /* enable ipv6 local static */
#define SL_NETCFG_IF_IPV6_LOCAL_STATELESS                  (0x100)  /* enable ipv6 local stateless */
#define SL_NETCFG_IF_IPV6_LOCAL_STATEFUL               	   (0x200)  /* enable ipv6 local statefull */
#define SL_NETCFG_IF_IPV6_GLOBAL_STATIC                    (0x400)  /* enable ipv6 global static */
#define SL_NETCFG_IF_IPV6_GLOBAL_STATEFUL                  (0x800)  /* enable ipv6 global statefull */
#define SL_NETCFG_IF_DISABLE_IPV4_LLA                      (0x1000) /* disable LLA feature. Relevant only in IPV4 */


my_config_file = ""

def ipv4(core, station, dhcp, ipv4, mask, gw, dns):
    print "*********************************************\n"
    val = socket.inet_aton(ipv4)
    bytes = []
    for i in reversed(range(4)):
        bytes.append( val[i].encode("hex") )

    val = socket.inet_aton(mask)
    for i in reversed(range(4)):
        bytes.append( val[i].encode("hex") )

    val = socket.inet_aton(gw)
    for i in reversed(range(4)):
        bytes.append( val[i].encode("hex") )

    val = socket.inet_aton(dns)
    for i in reversed(range(4)):
        bytes.append( val[i].encode("hex") )

    if (dhcp):
        addr_mode = SL_NETCFG_ADDR_DHCP_LLA # DHCP+LLA
    else:
        addr_mode = SL_NETCFG_ADDR_STATIC # Static

    if( station ):
        role_mode = SL_NETCFG_IPV4_STA_ADDR_MODE
    else:
        role_mode = SL_NETCFG_IPV4_AP_ADDR_MODE
    inpVal =  ':'.join(bytes)

    core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,role_mode, addr_mode, 16, inpVal)
                                              #delay,status,IPV4 command,option,length,value
    res = core.waitEvent("cc_NETCFG_SET", [], 500)


def main():


    core = TICore.TICore()
    core.initialize1()


    #set STA ipv4
    tmp =  conf.STA_IP_MODE & (conf.SL_NETCFG_IF_DISABLE_IPV4_DHCP )
    if( tmp ):
        ipv4( core, True, False, conf.STA_STATIC_IP, conf.STA_SUBNET_MASK, conf.STA_DEFAULT_GATEWAY, conf.STA_IPV4_DNS_SERVER)
    else:
        ipv4( core, True, True, conf.STA_STATIC_IP, conf.STA_SUBNET_MASK, conf.STA_DEFAULT_GATEWAY, conf.STA_IPV4_DNS_SERVER)
    #set AP ipv4
    ipv4( core, False, False, conf.AP_STATIC_IP, conf.AP_SUBNET_MASK, conf.AP_DEFAULT_GATEWAY, conf.AP_IPV4_DNS_SERVER)

    #set STA ipv6
    mode = conf.STA_IP_MODE & (conf.SL_NETCFG_IF_IPV6_STA_LOCAL | conf.SL_NETCFG_IF_IPV6_STA_GLOBAL )
    print mode
    buf = utils.convert_to_propriety_long(mode)
    print buf

    core.InvokeSLCommand("NETAPP", "NETCFG_SET",2000,0,SL_NETCFG_IF, SL_NEFCFG_IF_STATE, 4,buf)
    ret = core.waitEvent("cc_NETCFG_SET", [], 500)
    if mode:
        if conf.STA_IP_MODE & (conf.SL_NETCFG_IF_IPV6_LOCAL_STATIC ):
            print "local ipv6 static\n"
            ipv6Local  =  utils.ipv6ExtractToPoprietyFullAddress(conf.STA_STATIC_IPV6_LOCAL_ADDRESS)
           #print ipv6Local
            core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_LOCAL, SL_NETCFG_ADDR_STATIC, 16, ipv6Local)
            ret = core.waitEvent("cc_NETCFG_SET", [], 500)
            pass
        elif conf.STA_IP_MODE & (conf.SL_NETCFG_IF_IPV6_LOCAL_STATELESS ):
            print "local ipv6 stateless\n"
            core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_LOCAL, SL_NETCFG_ADDR_STATELESS, 0)
            ret = core.waitEvent("cc_NETCFG_SET", [], 500)
        else:
            print "local ipv6 by dhcp\n"
            core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_LOCAL, SL_NETCFG_ADDR_STATEFUL, 0)
            ret = core.waitEvent("cc_NETCFG_SET", [], 500)

        if conf.STA_IP_MODE & (conf.SL_NETCFG_IF_IPV6_STA_GLOBAL ):
            if conf.STA_IP_MODE & (conf.SL_NETCFG_IF_IPV6_GLOBAL_STATIC ):
                print "global ipv6 static\n"
                ipv6Global =  utils.ipv6ExtractToPoprietyFullAddress(conf.STA_STATIC_IPV6_GLOBAL_ADDRESS) + ":" +  utils.ipv6ExtractToPoprietyFullAddress(conf.STA_IPV6_DNS_SERVER)
                #rint ipv6Global
                core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_GLOBAL, SL_NETCFG_ADDR_STATIC, 32, ipv6Global)
                ret = core.waitEvent("cc_NETCFG_SET", [], 500)
                pass
            elif conf.STA_IP_MODE & conf.SL_NETCFG_IF_IPV6_GLOBAL_STATEFUL:
                print "global ipv6 by dhcp\n"
                core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_GLOBAL, SL_NETCFG_ADDR_STATEFUL, 0)
                core.waitEvent("cc_NETCFG_SET", [], 500)
            else:
                print "global ipv6 by statless"
                core.InvokeSLCommand("NETAPP", "NETCFG_SET",20000,0,SL_NETCFG_IPV6_ADDR_GLOBAL, SL_NETCFG_ADDR_STATELESS, 0)
                core.waitEvent("cc_NETCFG_SET", [], 500)


    #set mode sta
    core.InvokeSLCommand("WLAN", "WLAN_SET_MODE",1, 0)

    core.close()

    print "Setting Time"
    TM.SetTime()
    sys.exit("")


if __name__ == '__main__':
    main()
