import os
from threading import Lock
from time import asctime

class Tracer():
    def __init__(self, TraceName, MaxSizeMB=8, PrintEnable=True):
        self.TraceFileName = TraceName + ".txt"
        self.TraceFileNameOld = TraceName + "_Old.txt"
        self.TraceFileMaxSize = MaxSizeMB*1024*1024
        self.TraceFileHandle = open(self.TraceFileName, "a")
        self.PrintEnable = PrintEnable
        self.Lock = Lock()
        
    def write(self, ObjectToWrite):
        self.Lock.acquire()
        if (os.path.getsize(self.TraceFileName) > self.TraceFileMaxSize):
            self.TraceFileHandle.close()
            try:
                os.remove(self.TraceFileNameOld)
            except:
                pass
            try:
                os.rename(self.TraceFileName, self.TraceFileNameOld)
                self.TraceFileHandle = open(self.TraceFileName, "w")
            except(WindowsError):
                print "Error changing trace file for {:}".format(self.TraceFileName)
        StringToWrite = asctime() + " :: " + str(ObjectToWrite)
        self.TraceFileHandle.write(StringToWrite+"\n")
        self.Lock.release()
        if (self.PrintEnable == True):
            print StringToWrite
        
    def close(self):
        self.Lock.acquire()
        try:
            self.TraceFileHandle.close()
        except:
            pass
        self.Lock.release()
            