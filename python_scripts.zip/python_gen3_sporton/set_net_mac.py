
import sys
import time
import TICore
import configurations as conf
import string
import options

def SET_NET_CFG(new_mac_address):
    core = TICore.TICore()
    core.initialize1()

    print "*********************************************\n"
    core.InvokeSLCommand("NETAPP", "NETCFG_SET",10000,0,1, 0, 6,str(new_mac_address))
                                              #delay,status,MAC_SET command,option,length,value
    core.waitEvent("cc_NETCFG_SET", [], 10000 )
    #core.waitAndPrintAnyEvent()
    time.sleep(1)
    sys.exit("SET_NET_CFG Finished")

if __name__ == '__main__':
    macAddress = sys.argv[1]
    SET_NET_CFG(macAddress)
	
# Usage: set_net_mac.py 11:22:33:44:55 
