
import sys
import time
import TICore
import configurations as conf
import string
import options


def delete_profile(Opts=None):
    if (None == Opts):
        Opts = TIOptions('')
    core = TICore.TICore()
    core.initialize1(int(Opts.GetVal('SerialPort')))

    Index = int(Opts.GetVal('Index'))
    core.InvokeSLCommand("WLAN", "DELPROFILE", 2, Index)
    time.sleep(5)
    core.close()
    sys.exit("delete_profile Finished")

if __name__ == '__main__':
    OptsStr = string.join(sys.argv[1:])
    Opts = options.TIOptions(OptsStr)
    delete_profile(Opts)