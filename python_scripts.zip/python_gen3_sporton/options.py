import sys
import string
import configurations as conf
import utils

class OptionsDictionary(object):
    def __init__(self):
        self.Values = dict()
        self.Desc = dict()
        self.Names = dict()
        self.EmptyValues= dict()

    def AddVal(self,Opt,Name,Description,InitVal,EmptyVal=None):
        self.Values[Opt] = InitVal
        self.Names[Name.lower()] = Opt
        self.Desc[Name.lower()] = Description;
        if (None == EmptyVal):
            self.EmptyValues[Opt] = ''
        else:
            self.EmptyValues[Opt] = EmptyVal


    def GetVal(self,Name):
        Opt = self.Names[Name.lower()]
        return self.Values[Opt]

    def SetVal(self,Opt,Val):
        if self.Values.has_key(Opt):
            self.Values[Opt] = Val
        else:
           raise Exception()

    def SetOptions(self,OptionsString):
        # clear white spaces all over the string
        options = OptionsString.strip()
        while options.find('  ')>0:
        	options=options.replace('  ',' ')

        # update the values accroding to the options string
        optsArr = options.split('-')
        prevOptStr=''
        prevOptVal=''
        Opt = ''
        Val = ''

        for optStr in optsArr:
            optStr = optStr.strip()
            if len(optStr)>1:
                Opt = optStr[0]
                if ' ' == optStr[1]:
                    Val = optStr[2:]
                else:
                    # impossible unless it is a continuation of previos option
                    Val = optStr[1:]
                    Val = prevOptVal + '-' + optStr
                    Opt = prevOptStr
                try:
                    self.SetVal(Opt,Val)
                    prevOptStr=Opt
                    prevOptVal=Val
                except:
                    print('Got exception on long option. prev opt '+  prevOptVal+'-'+optStr + ' prev value ' + prevOptVal)

            else:
                if 1==len(optStr):
                    Opt = optStr
                    try:
                        Val = self.EmptyValues[optStr]
                        self.SetVal(Opt,Val)
                        prevOptStr=Opt
                        prevOptVal=Val
                    except:
                        # Concatenate a previous and current options into 1 value - probably - was for
						# value
                        Val=prevOptVal+'-'+Opt
                        self.SetVal(prevOptStr,Val)
                        prevOptVal=Val

    def PrintOptions(self):
        names = self.Names.keys()
        names.sort()
        print('\n\n')
        print type(self).__name__,':'
        for name in names:
            opt = self.Names[name]
            desc = self.Desc[name]
            print('-'+ opt + ' = ' + (name+':').ljust(13).upper() + desc.ljust(47) +'[' + self.Values[opt] + ']')
        print('\n\n')


class TIOptions(OptionsDictionary):
    def __init__(self,OptionsString):

        OptionsDictionary.__init__(self)

        # set default values
        self.AddVal('a',    'LocalIP',          'The CC3100 Local IP Address',              conf.LOCAL_IP_ADDR)
        self.AddVal('b',    'RemoteIP',         'The PC IP address',                        conf.REMOTE_IP_ADDR)
        self.AddVal('d',    'SerialPort',       'The serial port number',                   str(conf.SERIAL_COM_PORT))
        self.AddVal('c',    'CTstThroughput',   'The CTst Target Throughput (0=Max)',       '0')
        self.AddVal('i',    'Interval',         'The interval in seconds',                  '1')
        self.AddVal('k',    'key',              'The security key or WPS connection method', conf.KEY)
        self.AddVal('g',    'checkSumEnable',         'Ctst enable checksum', '0' )
        self.AddVal('l',    'Len',              'The length of a packet',                   str(conf.COMM_TEST_PACKET_LEN))
        self.AddVal('m',    'Misc',             'Miscellaneous Parameter',                  '')
        self.AddVal('n',    'SSID',             'SSID',                                     conf.SSI_NAME)
        self.AddVal('p',    'Port',             'The port number',                          str(conf.COMM_TEST_PORT_NUM))
        self.AddVal('r',    'Protocol',         'The protocol id for raw data test',       str(conf.COMM_TEST_PROTOCOL))
        self.AddVal('t',    'Time',             'The duration of the test',                 str(conf.COMM_TEST_TIME))
        self.AddVal('x',    'Security',         'Set Security Level(0-Open,1-WEP,2-WPA1/WPA2,4-WPS,6-P2P)',str(conf.SECURITY))
        self.AddVal('F',    'FastConnect',      'Enable Fast Connect on Connection Policy', '0','1')
        self.AddVal('z',    'AutoSmartConfig',  'Enable Auto Smart Config',                 '0','1')
        self.AddVal('A',    'AutoStart',        'Enable Auto Start on Connection Policy',   '1','1')
        self.AddVal('O',    'OpenAP',           'Enable Open AP on Connection Policy',      '0','1')
        self.AddVal('D',    'AnyP2P',           'Enable Any P2P Device Connection Policy',      '0','1')
        self.AddVal('P',    'Priority',         'Profile Priority on Connection Policy',    '0')
        self.AddVal('I',    'Index',            'Zero Based Index Parameter',               '255')
        self.AddVal('N',    'NumberOfPing',     'Number Ping Send',                         '4')
        self.AddVal('s',    'pingRequestSize',  'Size of Ping Data',                        '100')
        self.AddVal('S',    'pingSize',         'Kind of Ping [4-IPV4,16-IPV6,0-Domain]',   '4')
        self.AddVal('w',    'PingWaitReply',    'Suspension option',                        '400')
        self.AddVal('i',    'PingIntervalTime', 'IntervalPingTime[msec]',                   '0')
        self.AddVal('C',    'ConnectionPolicyType', '16 - Coonection; 32 - Scan',      '32')
        self.AddVal('M',    'Mask', 'Coonection[OFA]; Scan[E]',                        '1')
        self.AddVal('e',    'Intent',        'P2P Intent Value',   '3','15')
        self.AddVal('R',    'forceAutonomousGO',    'force Autonomous GO',   '0','1')
        self.AddVal('f',    'NegInitiator', 'Negotiation Initiator (0-Active, 1-Passive, 2-Random Backoff',   '2','2')
        self.AddVal('Z',    'ApplicationScanPeriod', 'ApplicationScanPeriod',        '10000')
        self.AddVal('T',    'TestType',         'CTST Test Number:\n\t\t\t\t0-UDP_TX\n\t\t\t\t1-UDP_RX\n\t\t\t\t2-TCP_TX\n\t\t\t\t3-TCP_RX\n\t\t\t\t4-UDP_RX_TCP_TX\n\t\t\t\t5-TCP_RX_UDP_TX\n\t\t\t\t6-UDP_RX_TX\n\t\t\t\t7-TCP_FULL_DUPLEX\n\t\t\t\t8-UDP_FULL_DUPLEX\n\t\t\t\t9-UDP_TX_IPV6\n\t\t\t\t10-UDP_RX_IPV6\n\t\t\t\t11-TCP_TX_IPV6\n\t\t\t\
        12-TCP_RX_IPV6\n\t\t\t\t13-TCP_FULL_DUPLEX_IPV6\n\t\t\t\t14-UDP_FULL_DUPLEX_IPV6\n\t\t\t\t15-RAW_TX_IPV6\n\t\t\t\t16-RAW_RX_IPV6\n\t\t\t\t17-RAW_TX\n\t\t\t\t18-RAW_RX\n\t\t\t\
        100-BSD_TEST_IPV4\n\t\t\t\t101-BSD_TEST_IPV6\t\t\t ',   '0')



        self.SetOptions(OptionsString)

class EAPOptions(OptionsDictionary):
    def __init__(self,OptionsString):

        OptionsDictionary.__init__(self)

        # set default values
        self.AddVal('t',    'EapType',          'The EAP type(0-TLS,1-TTLS,2-PEAP,3-FAST)',                             '0')
        self.AddVal('z',    'Phase2Type',       'The Phase 2 type(0-MSCHAPV2,1-TLS,2-PSK)',                         '0')
        self.AddVal('d',    'SerialPort',       'The serial port number',                   str(conf.SERIAL_COM_PORT))
        self.AddVal('k',    'Password',         'The password for Phase2 PSK or MSCHAPV2',  conf.PASSWORD)
        self.AddVal('n',    'SSID',             'SSID',                                     conf.SSI_NAME)
        self.AddVal('x',    'Security',         'Set Security Level(2-WPA1,3-WPA2)',        '2')
        self.AddVal('i',    'identity',         'The user identity',                        conf.IDENTITY)
        self.AddVal('a',    'AnonymousIdentity', 'Anonymous Identity for tunneling methods',      conf.ANONYMOUS_IDENTITY)
        self.AddVal('v',    'PeapVersion',      'The PEAP version',                         '0')
        self.AddVal('p',    'FastProvisioning', 'Fast provisioning for EAP-Fast(0-Disabled,1-Unauthenticated,2-Authenticated)',    '1')
        self.AddVal('P',    'Priority',         'EAP Profile Priority on Connection Policy',    '0')
        self.SetOptions(OptionsString)

class StellarisSsiOptions(OptionsDictionary):
    def __init__(self,OptionsString):

        OptionsDictionary.__init__(self)

        # set default values. Note: 'SerialPort' is needed since TIOptions are note used by set_ssi_size.py script.
        self.AddVal('s',    'SizeInBytes',      'SSI size in bytes',                                         '1')
        self.AddVal('d',    'SerialPort',       'The serial port number',                                   str(conf.SERIAL_COM_PORT))
        self.SetOptions(OptionsString)

class RxFilterOptions(OptionsDictionary):
    def __init__(self,OptionsString):

        OptionsDictionary.__init__(self)

        # set default values
        self.AddVal ( 't', 'TestNumber',  '0-9', '0')
        self.SetOptions(OptionsString)

if __name__ == '__main__':
    if len(sys.argv) <= 1:
        TIOpts = TIOptions('')
        EAPOpts = EAPOptions('')
        SSIOpts = StellarisSsiOptions('')
        RXFilterOpts = RxFilterOptions('')
    else:
        TIOpts = TIOptions(string.join(sys.argv[1:]))
        EAPOpts = EAPOptions(string.join(sys.argv[1:]))
        SSIOpts = StellarisSsiOptions(string.join(sys.argv[1:]))
        RXFilterOpts = RxFilterOptions(string.join(sys.argv[1:]))
    #print 'TI Options:'
    TIOpts.PrintOptions()
    #print 'EAP Options:'
    EAPOpts.PrintOptions()
    SSIOpts.PrintOptions()
    RXFilterOpts.PrintOptions()






